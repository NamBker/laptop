<h2>Viewing <span class='muted'><?php echo $product->id; ?></span></h2>
<?php echo Html::anchor('product/edit/'.$product->id, 'Edit'); ?> |
<?php echo Html::anchor('product', 'Back'); ?>