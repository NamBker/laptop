<h2>New <span class='muted'>Sanpham</span></h2>
<br>
<?php echo render('product/_form'); ?>
<p><?php echo Html::anchor('product', 'Back'); ?></p>
