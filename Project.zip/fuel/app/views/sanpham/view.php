<h2>Viewing <span class='muted'><?php echo $sanpham->id; ?></span></h2>



<?php echo Html::anchor('sanpham/edit/'.$sanpham->id, 'Edit'); ?> |
<?php echo Html::anchor('sanpham', 'Back'); ?>