<h2>New <span class='muted'>Sanpham</span></h2>
<br>

<?php echo render('sanpham/_form'); ?>


<p><?php echo Html::anchor('sanpham', 'Back'); ?></p>
