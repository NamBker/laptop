<ul class="nav nav-pills">
	<li class='<?php echo Arr::get($subnav, "dienthoai" ); ?>'><?php echo Html::anchor('sanpham/dienthoai','Dienthoai');?></li>
	<li class='<?php echo Arr::get($subnav, "phukien" ); ?>'><?php echo Html::anchor('sanpham/phukien','Phukien');?></li>
	<li class='<?php echo Arr::get($subnav, "dichvu" ); ?>'><?php echo Html::anchor('sanpham/dichvu','Dichvu');?></li>

</ul>
<p>Dichvu</p>