 <div class="brands-area">
    <div class="zigzag-bottom"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="brand-wrapper">
                    <div class="brand-list">
                        <?php echo Asset::img('brand1.png') ?>
                        <?php echo Asset::img('brand2.png') ?>
                        <?php echo Asset::img('brand3.png') ?>
                        <?php echo Asset::img('brand4.png') ?>
                        <?php echo Asset::img('brand5.png') ?>
                        <?php echo Asset::img('brand6.png') ?>
                        <?php echo Asset::img('brand1.png') ?>
                        <?php echo Asset::img('brand2.png') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <!-- End brands area -->