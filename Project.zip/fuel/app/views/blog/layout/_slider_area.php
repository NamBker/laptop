 <div class="slider-area">
 	<div class="block-slider block-slider4">
 		<ul class="" id="bxslider-home4">
 			<li>
 				<?php echo Asset::img('h4-slide.png') ?>
 				<div class="caption-group">
 					<h2 class="caption title">
 						iPhone <span class="primary">6 <strong>Plus</strong></span>
 					</h2>
 					<h4 class="caption subtitle">Dual SIM</h4>
 					<a class="caption button-radius" href="#"><span class="icon"></span>Shop now</a>
 				</div>
 			</li>
 			<li>
 				<?php echo Asset::img('h4-slide2.png') ?>
 				<div class="caption-group">
 					<h2 class="caption title">
 						by one, get one <span class="primary">50% <strong>off</strong></span>
 					</h2>
 					<h4 class="caption subtitle">school supplies & backpacks.*</h4>
 					<a class="caption button-radius" href="#"><span class="icon"></span>Shop now</a>
 				</div>
 			</li>
 			<li>
 				<?php echo Asset::img('h4-slide3.png') ?>
 				<div class="caption-group">
 					<h2 class="caption title">
 						Apple <span class="primary">Store <strong>Ipod</strong></span>
 					</h2>
 					<h4 class="caption subtitle">Select Item</h4>
 					<a class="caption button-radius" href="#"><span class="icon"></span>Shop now</a>
 				</div>
 			</li>
 			<li>
 				<?php echo Asset::img('h4-slide4.png') ?>
 				<div class="caption-group">
 					<h2 class="caption title">
 						Apple <span class="primary">Store <strong>Ipod</strong></span>
 					</h2>
 					<h4 class="caption subtitle">& Phone</h4>
 					<a class="caption button-radius" href="#"><span class="icon"></span>Shop now</a>
 				</div>
 			</li>
 		</ul>
 	</div>
</div> <!-- End slider area -->