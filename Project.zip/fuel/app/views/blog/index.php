<?php include("layout/_slider_area.php"); ?>
<?php include("layout/_promo_area.php"); ?>
<?php include("layout/_maincontent_area.php"); ?>
<?php include("layout/_brands_area.php"); ?>
<?php include("layout/_product_widget_area.php"); ?>