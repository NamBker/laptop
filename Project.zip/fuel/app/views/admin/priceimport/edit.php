<h2>Editing Priceimport</h2>
<br>

<?php echo render('admin/priceimport/_form'); ?>
<p>
	<?php echo Html::anchor('admin/priceimport/view/'.$priceimport->id, 'View'); ?> |
	<?php echo Html::anchor('admin/priceimport', 'Back'); ?></p>
