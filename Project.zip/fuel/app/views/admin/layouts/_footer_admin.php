    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <b>Version</b> 2.3.7
      </div>
      <strong>Copyright &copy; 2014-2016 <a href="https://www.facebook.com/nambker">NamBker</a>.</strong> All rights
      <reserved class=""></reserved>
    </footer>