<h2>Editing Sanpham</h2>
<br>

<?php echo render('admin/sanpham/_form_edit'); ?>
<p>
	<?php echo Html::anchor('admin/sanpham', 'Back'); ?></p>
