<?php 

echo "ID: ".$current_user->id;
echo "<br>";
echo "User name: ".$current_user->username;



 ?>