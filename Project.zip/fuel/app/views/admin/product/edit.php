<h2>Editing Sanpham</h2>
<br>

<?php echo render('admin/product/_form_edit'); ?>
<p>
	<?php echo Html::anchor('admin/product', 'Back'); ?></p>
