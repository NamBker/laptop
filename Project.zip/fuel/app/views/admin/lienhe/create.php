<h2>Thêm cơ sở</h2>
<br>

<?php echo render('admin/lienhe/_form'); ?>


<p><?php echo Html::anchor('admin/lienhe', 'Back'); ?></p>
