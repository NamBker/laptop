<h2>Editing Lienhe</h2>
<br>

<?php echo render('admin/lienhe/_form'); ?>
<p>
	<?php echo Html::anchor('admin/lienhe/view/'.$lienhe->id, 'View'); ?> |
	<?php echo Html::anchor('admin/lienhe', 'Back'); ?></p>
