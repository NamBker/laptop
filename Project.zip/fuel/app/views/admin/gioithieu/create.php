<h2>New Gioithieu</h2>
<br>

<?php echo render('admin/gioithieu/_form'); ?>


<p><?php echo Html::anchor('admin/gioithieu', 'Back'); ?></p>
