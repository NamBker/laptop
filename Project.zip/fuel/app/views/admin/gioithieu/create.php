<h2>New Store</h2>
<br>

<?php echo render('admin/gioithieu/_form'); ?>


<p><?php echo Html::anchor('admin/gioithieu', 'Back'); ?></p>
