<h2>Editing Gioithieu</h2>
<br>

<?php echo render('admin/gioithieu/_form'); ?>
<p>
	<?php echo Html::anchor('admin/gioithieu/view/'.$gioithieu->id, 'View'); ?> |
	<?php echo Html::anchor('admin/gioithieu', 'Back'); ?></p>
