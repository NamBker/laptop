<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-12-07 09:29:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:30:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:31:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:31:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:54:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:55:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:55:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:55:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:55:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:55:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:55:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:56:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:56:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:56:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:56:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 09:56:20 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.price' in 'field list' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`price` AS `t0_c21`, `t0`.`created_at` AS `t0_c22`, `t0`.`updated_at` AS `t0_c23` FROM `sanphams` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 09:56:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:56:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:57:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:57:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:57:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:57:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 09:57:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:00:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:00:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:00:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:01:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:02:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 10:02:03 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481101323, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 10:02:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 10:02:22 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481101342, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 10:02:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 10:02:28 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481101348, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 10:02:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:02:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:02:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:02:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:03:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:03:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:03:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 10:03:11 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481101391, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 10:03:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 10:03:22 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481101402, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 10:04:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:04:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:04:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:04:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:04:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 10:04:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 10:04:39 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481101479, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 17:06:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:06:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:06:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:06:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:06:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:06:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:06:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:06:43 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481126803, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 17:06:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:06:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:08:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:08:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:08:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:08:31 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481126911, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 17:09:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:09:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:09:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:09:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:09:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:09:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:09:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:09:45 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481126985, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 17:10:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:10:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:10:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:10:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:10:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:10:52 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481127052, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 17:12:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:12:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:12:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:12:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:12:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:12:47 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'tensanpham' cannot be null with query: "INSERT INTO `sanphams` (`tensanpham`, `slug`, `kichthuoc`, `bangtan`, `cpu`, `gpu`, `bonhotrong`, `ram`, `cambien`, `bluetooth`, `amthanh`, `wlan`, `gps`, `pin`, `manhinh`, `camera_truoc`, `camera_sau`, `quayphim`, `category`, `quantity`, `created_at`, `updated_at`) VALUES (null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', 1481127167, null)" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 17:13:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:14:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:14:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:15:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:15:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:16:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:17:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:17:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:17:25 --> Notice - Undefined variable: user in C:\xampp\htdocs\Project\fuel\app\views\admin\user\index.php on line 3
WARNING - 2016-12-07 17:18:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:18:19 --> Notice - Undefined variable: user in C:\xampp\htdocs\Project\fuel\app\views\admin\user\index.php on line 3
WARNING - 2016-12-07 17:18:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:18:20 --> Notice - Undefined variable: user in C:\xampp\htdocs\Project\fuel\app\views\admin\user\index.php on line 3
WARNING - 2016-12-07 17:18:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:18:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:18:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:18:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:19:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:19:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:19:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:19:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:19:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:19:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:19:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:21:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:22:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:25:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:28:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:28:47 --> Error - Argument 1 passed to Orm\Model::count() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin.php on line 97 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 629
WARNING - 2016-12-07 17:28:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:28:48 --> Error - Argument 1 passed to Orm\Model::count() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin.php on line 97 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 629
WARNING - 2016-12-07 17:29:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:35:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:36:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:36:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:36:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:37:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:40:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:40:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:40:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:40:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:41:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:42:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:42:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:42:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:42:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:43:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:43:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:43:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:43:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:43:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:44:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:44:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:44:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:44:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:45:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:51:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:51:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:51:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:51:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:51:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:51:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:55:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:55:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:55:45 --> Notice - Undefined variable: user in C:\xampp\htdocs\Project\fuel\app\views\admin\user\show.php on line 1
WARNING - 2016-12-07 17:56:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:56:01 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\admin\user\show.php on line 1
WARNING - 2016-12-07 17:56:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:56:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:56:15 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\admin\user\show.php on line 1
WARNING - 2016-12-07 17:57:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:57:31 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-12-07 17:57:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:57:43 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-12-07 17:57:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:57:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:57:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 17:58:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:58:04 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-12-07 17:58:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:58:41 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\admin\user\show.php on line 1
WARNING - 2016-12-07 17:59:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 17:59:04 --> Error - Property "title" not found for Model_User. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 1188
WARNING - 2016-12-07 18:00:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 18:00:01 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.1' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`group` AS `t0_c3`, `t0`.`email` AS `t0_c4`, `t0`.`address` AS `t0_c5`, `t0`.`phone` AS `t0_c6`, `t0`.`image` AS `t0_c7`, `t0`.`last_login` AS `t0_c8`, `t0`.`login_hash` AS `t0_c9`, `t0`.`profile_fields` AS `t0_c10`, `t0`.`created_at` AS `t0_c11`, `t0`.`updated_at` AS `t0_c12` FROM `users` AS `t0` WHERE `t0`.`1` IS null" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 18:00:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-07 18:00:32 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.1' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`username` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`group` AS `t0_c3`, `t0`.`email` AS `t0_c4`, `t0`.`address` AS `t0_c5`, `t0`.`phone` AS `t0_c6`, `t0`.`image` AS `t0_c7`, `t0`.`last_login` AS `t0_c8`, `t0`.`login_hash` AS `t0_c9`, `t0`.`profile_fields` AS `t0_c10`, `t0`.`created_at` AS `t0_c11`, `t0`.`updated_at` AS `t0_c12` FROM `users` AS `t0` WHERE `t0`.`1` IS null" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-07 18:00:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 18:01:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-07 18:01:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
