<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-12-09 03:35:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:36:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:37:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:37:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:37:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:38:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:38:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:38:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:38:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:39:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:39:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:39:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:46:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:47:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:49:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:50:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:51:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:51:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:52:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:52:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:52:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:52:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 03:52:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:19:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:19:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:20:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:20:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:20:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:20:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:20:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:21:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:21:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:21:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:21:39 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:22:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:22:01 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:22:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:22:03 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:22:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:22:03 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:22:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:22:04 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:22:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:22:04 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:22:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:22:04 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:22:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:22:11 --> Notice - Use of undefined constant id - assumed 'id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:22:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:22:18 --> Notice - Undefined index: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:23:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:23:50 --> Notice - Undefined index: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 55
WARNING - 2016-12-09 04:26:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:26:42 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 57
WARNING - 2016-12-09 04:26:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:26:54 --> Notice - Undefined variable: name in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 67
ERROR - 2016-12-09 04:26:54 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in C:\xampp\htdocs\Project\fuel\core\classes\session\driver.php on 476
WARNING - 2016-12-09 04:27:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:27:31 --> Error - Unsupported operand types in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 67
ERROR - 2016-12-09 04:27:31 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in C:\xampp\htdocs\Project\fuel\core\classes\session\driver.php on 476
WARNING - 2016-12-09 04:27:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:27:31 --> Error - Unsupported operand types in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 67
ERROR - 2016-12-09 04:27:31 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in C:\xampp\htdocs\Project\fuel\core\classes\session\driver.php on 476
WARNING - 2016-12-09 04:28:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:28:15 --> Error - Number of values in to_assoc must be even. in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 315
ERROR - 2016-12-09 04:28:15 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in C:\xampp\htdocs\Project\fuel\core\classes\session\driver.php on 476
WARNING - 2016-12-09 04:31:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:31:14 --> Error - Number of values in to_assoc must be even. in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 315
WARNING - 2016-12-09 04:31:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:31:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:32:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:32:01 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\cart\index.php on line 77
WARNING - 2016-12-09 04:32:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:32:12 --> Notice - Undefined variable: data in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 15
WARNING - 2016-12-09 04:32:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:32:24 --> Notice - Undefined variable: cart in C:\xampp\htdocs\Project\fuel\app\views\cart\index.php on line 73
WARNING - 2016-12-09 04:32:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:32:38 --> Notice - Undefined variable: cart in C:\xampp\htdocs\Project\fuel\app\views\cart\index.php on line 73
WARNING - 2016-12-09 04:32:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:32:39 --> Notice - Undefined variable: cart in C:\xampp\htdocs\Project\fuel\app\views\cart\index.php on line 73
WARNING - 2016-12-09 04:33:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:33:03 --> Notice - Undefined variable: cart in C:\xampp\htdocs\Project\fuel\app\views\cart\index.php on line 73
WARNING - 2016-12-09 04:33:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:33:04 --> Notice - Undefined variable: cart in C:\xampp\htdocs\Project\fuel\app\views\cart\index.php on line 73
WARNING - 2016-12-09 04:33:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:33:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:34:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:37:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:37:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:37:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:37:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:37:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:37:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:37:43 --> Error - Call to undefined function Session() in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 54
WARNING - 2016-12-09 04:37:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:37:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:37:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:38:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:39:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:39:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:39:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:39:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:39:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:39:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:39:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:39:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:43:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:43:00 --> Notice - Undefined index: cart in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 9
WARNING - 2016-12-09 04:43:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:43:12 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 12
WARNING - 2016-12-09 04:43:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:43:40 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 12
WARNING - 2016-12-09 04:44:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:44:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:44:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:44:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:44:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:44:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:44:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:46:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:46:54 --> 21000 - SQLSTATE[21000]: Cardinality violation: 1241 Operand should contain 1 column(s) with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`created_at` AS `t0_c21`, `t0`.`updated_at` AS `t0_c22` FROM `sanphams` AS `t0` WHERE `t0`.`slug` = ('sam-sung-galaxy-s7-eage', ('sam-sung-galaxy-s7-eage'))" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-09 04:48:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:48:42 --> 21000 - SQLSTATE[21000]: Cardinality violation: 1241 Operand should contain 1 column(s) with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`created_at` AS `t0_c21`, `t0`.`updated_at` AS `t0_c22` FROM `sanphams` AS `t0` WHERE `t0`.`slug` = ('sam-sung-galaxy-s7-eage', ('sam-sung-galaxy-s7-eage'))" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-12-09 04:48:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 04:48:56 --> Notice - Undefined variable: product_type in C:\xampp\htdocs\Project\fuel\app\classes\controller\cart.php on line 16
WARNING - 2016-12-09 04:48:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:49:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:49:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:49:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:49:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:49:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:50:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:51:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:51:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:51:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:51:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:51:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:51:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:51:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:54:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:54:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:54:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:54:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:54:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:54:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:54:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:55:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:55:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:55:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:55:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:55:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:57:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:58:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 04:59:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:03:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:04:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:05:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:05:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:05:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:05:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:05:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:05:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:05:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:06:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:06:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:06:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:06:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:06:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:07:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:07:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:07:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:07:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:07:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:08:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:09:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:09:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:09:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:09:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:09:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-09 05:09:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-12-09 05:09:46 --> Warning - Invalid argument supplied for foreach() in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 478
