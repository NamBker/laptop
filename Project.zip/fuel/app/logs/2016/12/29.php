<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-12-29 03:18:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-12-29 03:19:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
