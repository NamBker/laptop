<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-11-16 23:45:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-16 23:49:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-16 23:49:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-16 23:49:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-16 23:59:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-16 23:59:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-16 23:59:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
