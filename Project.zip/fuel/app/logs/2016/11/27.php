<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-11-27 19:49:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:49:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:50:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-27 19:50:11 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.quantity' in 'field list' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`kichthuoc` AS `t0_c2`, `t0`.`bangtan` AS `t0_c3`, `t0`.`cpu` AS `t0_c4`, `t0`.`gpu` AS `t0_c5`, `t0`.`bonhotrong` AS `t0_c6`, `t0`.`ram` AS `t0_c7`, `t0`.`cambien` AS `t0_c8`, `t0`.`bluetooth` AS `t0_c9`, `t0`.`amthanh` AS `t0_c10`, `t0`.`wlan` AS `t0_c11`, `t0`.`gps` AS `t0_c12`, `t0`.`pin` AS `t0_c13`, `t0`.`manhinh` AS `t0_c14`, `t0`.`camera_truoc` AS `t0_c15`, `t0`.`camera_sau` AS `t0_c16`, `t0`.`quayphim` AS `t0_c17`, `t0`.`category` AS `t0_c18`, `t0`.`quantity` AS `t0_c19`, `t0`.`created_at` AS `t0_c20`, `t0`.`updated_at` AS `t0_c21` FROM `sanphams` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-11-27 19:50:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:50:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-27 19:50:53 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.quantity' in 'field list' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`kichthuoc` AS `t0_c2`, `t0`.`bangtan` AS `t0_c3`, `t0`.`cpu` AS `t0_c4`, `t0`.`gpu` AS `t0_c5`, `t0`.`bonhotrong` AS `t0_c6`, `t0`.`ram` AS `t0_c7`, `t0`.`cambien` AS `t0_c8`, `t0`.`bluetooth` AS `t0_c9`, `t0`.`amthanh` AS `t0_c10`, `t0`.`wlan` AS `t0_c11`, `t0`.`gps` AS `t0_c12`, `t0`.`pin` AS `t0_c13`, `t0`.`manhinh` AS `t0_c14`, `t0`.`camera_truoc` AS `t0_c15`, `t0`.`camera_sau` AS `t0_c16`, `t0`.`quayphim` AS `t0_c17`, `t0`.`category` AS `t0_c18`, `t0`.`quantity` AS `t0_c19`, `t0`.`created_at` AS `t0_c20`, `t0`.`updated_at` AS `t0_c21` FROM `sanphams` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-11-27 19:50:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 19:51:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:50:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:50:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:50:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:50:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:50:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:50:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:50:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:51:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:52:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:52:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:52:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-27 20:58:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-27 20:58:14 --> Error - syntax error, unexpected ''admin/price/index'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' in C:\xampp\htdocs\Project\fuel\app\config\routes.php on line 22
WARNING - 2016-11-27 20:58:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-27 20:58:24 --> Error - syntax error, unexpected ''admin/price/index'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' in C:\xampp\htdocs\Project\fuel\app\config\routes.php on line 22
WARNING - 2016-11-27 20:58:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
