<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-11-17 18:45:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
