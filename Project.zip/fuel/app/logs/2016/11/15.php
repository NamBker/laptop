<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-11-15 09:36:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 09:37:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 09:37:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 09:37:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-15 09:37:05 --> 1146 - SQLSTATE[42S02]: Base table or view not found: 1146 Table 'fantastic.gioithieus' doesn't exist with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`title` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`summary` AS `t0_c3`, `t0`.`body` AS `t0_c4`, `t0`.`user_id` AS `t0_c5`, `t0`.`created_at` AS `t0_c6`, `t0`.`updated_at` AS `t0_c7` FROM `gioithieus` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-11-15 09:37:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 09:37:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 09:38:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 09:38:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 09:38:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 09:38:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:01:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:02:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:02:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:02:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:02:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:02:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:15:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:15:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:15:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:15:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:15:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:15:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:15:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:15:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:16:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:16:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:16:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:17:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-15 10:17:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
