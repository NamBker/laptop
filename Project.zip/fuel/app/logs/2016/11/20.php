<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-11-20 07:09:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:09:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:09:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:09:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:09:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:09:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:09:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:09:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:22:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:22:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:23:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:23:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 07:23:06 --> 1146 - SQLSTATE[42S02]: Base table or view not found: 1146 Table 'fantastic.categories' doesn't exist with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`type` AS `t0_c1`, `t0`.`product_id` AS `t0_c2`, `t0`.`created_at` AS `t0_c3`, `t0`.`updated_at` AS `t0_c4` FROM `categories` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-11-20 07:24:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:24:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:24:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:24:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:24:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:24:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:24:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:24:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:24:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:25:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:26:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:26:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:26:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:26:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:26:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:27:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:29:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:30:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:31:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:31:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:31:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:31:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:32:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 07:32:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:31:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 10:31:23 --> 2002 - SQLSTATE[HY000] [2002] No connection could be made because the target machine actively refused it.
 in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 112
WARNING - 2016-11-20 10:31:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:31:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:31:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:32:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:39:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:40:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:44:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:45:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:49:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:49:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:50:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:55:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:55:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:55:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:56:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 10:59:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:01:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:01:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:03:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:03:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:05:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:07:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:07:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:09:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:10:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:11:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:13:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:13:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:13:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:13:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:13:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:13:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:14:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:14:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:14:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:14:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:14:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:14:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:15:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:20:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 11:21:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:18:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:18:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:19:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:19:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:19:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:20:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:20:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:20:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:20:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:20:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:20:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:22:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:23:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:24:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:24:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:24:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:24:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:25:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:25:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:25:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:25:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:25:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:28:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:28:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:28:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:29:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:30:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:30:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:30:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:30:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:30:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:32:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:32:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:32:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 12:32:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:02:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:03:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:03:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:03:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:03:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:11:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:12:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:12:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:12:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:12:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:12:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:12:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:13:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:13:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:13:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:13:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:27:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:27:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:27:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:27:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:28:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:28:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:30:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:30:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:30:12 --> Notice - Undefined variable: data in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 160
WARNING - 2016-11-20 13:30:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:30:25 --> Notice - Undefined variable: data in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 160
WARNING - 2016-11-20 13:30:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:30:27 --> Notice - Undefined variable: data in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 160
WARNING - 2016-11-20 13:30:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:30:38 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\view.php on line 1
WARNING - 2016-11-20 13:30:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:30:40 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\view.php on line 1
WARNING - 2016-11-20 13:30:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:30:41 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\view.php on line 1
WARNING - 2016-11-20 13:30:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:30:59 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 3
WARNING - 2016-11-20 13:31:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:31:36 --> Error - syntax error, unexpected '$this' (T_VARIABLE) in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 159
WARNING - 2016-11-20 13:31:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:31:47 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 3
WARNING - 2016-11-20 13:32:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:32:14 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 29
WARNING - 2016-11-20 13:32:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:32:29 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 3
WARNING - 2016-11-20 13:32:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:32:56 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 29
WARNING - 2016-11-20 13:33:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:34:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:34:25 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:34:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:34:48 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:35:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:35:41 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:35:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:35:41 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:35:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:35:41 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:35:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:35:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:35:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:35:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:35:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:35:48 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:36:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:36:00 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:36:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:36:02 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:36:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:36:33 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:36:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:36:36 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:53:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:53:31 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:56:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:56:10 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:56:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 13:56:51 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\sanpham\view.php on line 1
WARNING - 2016-11-20 13:57:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:57:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:57:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 13:57:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:04:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:04:22 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 3
WARNING - 2016-11-20 14:05:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:05:33 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 27
WARNING - 2016-11-20 14:05:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:05:47 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 3
WARNING - 2016-11-20 14:08:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:09:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:09:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:09:37 --> Error - Property "anh" not found for Model_Sanpham. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 1188
WARNING - 2016-11-20 14:27:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:27:20 --> Error - Property "anh" not found for Model_Sanpham. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 1188
WARNING - 2016-11-20 14:37:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:37:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:37:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:37:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:37:52 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:40:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:40:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:40:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:40:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:40:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:40:28 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:41:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:41:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:41:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:41:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:41:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:41:07 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:45:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:45:32 --> Error - syntax error, unexpected end of file, expecting function (T_FUNCTION) in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 198
WARNING - 2016-11-20 14:45:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:45:48 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:46:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:46:18 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:48:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:48:33 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:48:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:48:35 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:52:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:52:12 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:53:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:53:59 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:54:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:54:01 --> Error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2016-11-20 14:55:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:55:31 --> Error - syntax error, unexpected '}', expecting end of file in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 178
WARNING - 2016-11-20 14:55:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:55:32 --> Error - syntax error, unexpected '}', expecting end of file in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 178
WARNING - 2016-11-20 14:55:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:55:32 --> Error - syntax error, unexpected '}', expecting end of file in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 178
WARNING - 2016-11-20 14:55:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:55:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:56:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:56:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:56:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:56:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:56:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:57:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:57:01 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\index.php on line 15
WARNING - 2016-11-20 14:57:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:57:14 --> Error - Cannot access empty property in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 166
WARNING - 2016-11-20 14:57:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 14:57:46 --> Error - syntax error, unexpected '}', expecting end of file in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 178
WARNING - 2016-11-20 14:57:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:58:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 14:58:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:00:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:00:02 --> 21000 - SQLSTATE[21000]: Cardinality violation: 1241 Operand should contain 1 column(s) with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`kichthuoc` AS `t0_c2`, `t0`.`bangtan` AS `t0_c3`, `t0`.`cpu` AS `t0_c4`, `t0`.`gpu` AS `t0_c5`, `t0`.`bonhotrong` AS `t0_c6`, `t0`.`ram` AS `t0_c7`, `t0`.`cambien` AS `t0_c8`, `t0`.`bluetooth` AS `t0_c9`, `t0`.`amthanh` AS `t0_c10`, `t0`.`wlan` AS `t0_c11`, `t0`.`gps` AS `t0_c12`, `t0`.`pin` AS `t0_c13`, `t0`.`manhinh` AS `t0_c14`, `t0`.`camera_truoc` AS `t0_c15`, `t0`.`camera_sau` AS `t0_c16`, `t0`.`quayphim` AS `t0_c17`, `t0`.`category` AS `t0_c18`, `t0`.`created_at` AS `t0_c19`, `t0`.`updated_at` AS `t0_c20` FROM `sanphams` AS `t0` WHERE `t0`.`id` = ('category', 'iphone') LIMIT 1" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-11-20 15:00:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:00:05 --> 21000 - SQLSTATE[21000]: Cardinality violation: 1241 Operand should contain 1 column(s) with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`kichthuoc` AS `t0_c2`, `t0`.`bangtan` AS `t0_c3`, `t0`.`cpu` AS `t0_c4`, `t0`.`gpu` AS `t0_c5`, `t0`.`bonhotrong` AS `t0_c6`, `t0`.`ram` AS `t0_c7`, `t0`.`cambien` AS `t0_c8`, `t0`.`bluetooth` AS `t0_c9`, `t0`.`amthanh` AS `t0_c10`, `t0`.`wlan` AS `t0_c11`, `t0`.`gps` AS `t0_c12`, `t0`.`pin` AS `t0_c13`, `t0`.`manhinh` AS `t0_c14`, `t0`.`camera_truoc` AS `t0_c15`, `t0`.`camera_sau` AS `t0_c16`, `t0`.`quayphim` AS `t0_c17`, `t0`.`category` AS `t0_c18`, `t0`.`created_at` AS `t0_c19`, `t0`.`updated_at` AS `t0_c20` FROM `sanphams` AS `t0` WHERE `t0`.`id` = ('category', 'iphone') LIMIT 1" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-11-20 15:00:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:00:07 --> 21000 - SQLSTATE[21000]: Cardinality violation: 1241 Operand should contain 1 column(s) with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`kichthuoc` AS `t0_c2`, `t0`.`bangtan` AS `t0_c3`, `t0`.`cpu` AS `t0_c4`, `t0`.`gpu` AS `t0_c5`, `t0`.`bonhotrong` AS `t0_c6`, `t0`.`ram` AS `t0_c7`, `t0`.`cambien` AS `t0_c8`, `t0`.`bluetooth` AS `t0_c9`, `t0`.`amthanh` AS `t0_c10`, `t0`.`wlan` AS `t0_c11`, `t0`.`gps` AS `t0_c12`, `t0`.`pin` AS `t0_c13`, `t0`.`manhinh` AS `t0_c14`, `t0`.`camera_truoc` AS `t0_c15`, `t0`.`camera_sau` AS `t0_c16`, `t0`.`quayphim` AS `t0_c17`, `t0`.`category` AS `t0_c18`, `t0`.`created_at` AS `t0_c19`, `t0`.`updated_at` AS `t0_c20` FROM `sanphams` AS `t0` WHERE `t0`.`id` = ('category', 'iphone') LIMIT 1" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2016-11-20 15:03:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:03:09 --> Notice - Undefined variable: data in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 174
WARNING - 2016-11-20 15:03:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:03:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:03:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:03:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:03:57 --> Error - Class 'Messages' not found in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 168
WARNING - 2016-11-20 15:04:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:04:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:04:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:04:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:04:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:09:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:09:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:09:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:09:48 --> Error - Property "anh" not found for Model_Sanpham. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 1188
WARNING - 2016-11-20 15:10:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:10:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:10:24 --> Error - Invalid method call.  Method validate does not exist. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 685
WARNING - 2016-11-20 15:16:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:16:03 --> Notice - Undefined variable: val in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 106
WARNING - 2016-11-20 15:16:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:16:40 --> Notice - Undefined variable: views in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 109
WARNING - 2016-11-20 15:16:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:16:49 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:17:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:17:32 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:17:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:17:34 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:17:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:17:48 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:18:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:18:34 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:19:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:19:00 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:19:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:19:07 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:19:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:19:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:19:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:19:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:19:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:19:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:19:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:19:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:19:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:21:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:21:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:21:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:22:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:22:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:22:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:22:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:22:16 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:22:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:22:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:22:21 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:22:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:22:24 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:22:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:22:33 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:23:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:05 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:23:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:07 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:23:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:09 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:23:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:17 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:23:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:19 --> Error - View variable is not set: template in C:\xampp\htdocs\Project\fuel\core\classes\view.php on line 526
WARNING - 2016-11-20 15:23:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:24 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:23:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:35 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:23:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:37 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:23:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:23:53 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:24:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:25:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:25:47 --> Notice - Undefined variable: sanpham in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:26:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:26:30 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:26:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:27:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:27:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:27:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:27:23 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:27:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:27:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:27:40 --> Notice - Undefined variable: sanphams in C:\xampp\htdocs\Project\fuel\app\views\admin\sanpham\edit.php on line 6
WARNING - 2016-11-20 15:27:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:28:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:28:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:28:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:30:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:31:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:31:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:31:02 --> Error - Invalid method call.  Method validate does not exist. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 685
WARNING - 2016-11-20 15:32:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:32:48 --> Error - Invalid method call.  Method validate does not exist. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 685
WARNING - 2016-11-20 15:32:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:32:56 --> Error - Property "anh" not found for Model_Sanpham. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 1188
WARNING - 2016-11-20 15:33:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:33:02 --> Error - Property "anh" not found for Model_Sanpham. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 1188
WARNING - 2016-11-20 15:33:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:33:04 --> Error - Property "anh" not found for Model_Sanpham. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 1188
WARNING - 2016-11-20 15:33:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:33:08 --> Error - Property "anh" not found for Model_Sanpham. in C:\xampp\htdocs\Project\fuel\packages\orm\classes\model.php on line 1188
WARNING - 2016-11-20 15:33:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:34:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:34:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:35:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:35:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:35:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:35:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:35:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:35:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:35:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-11-20 15:35:40 --> Error - Class 'Messages' not found in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\sanpham.php on line 142
WARNING - 2016-11-20 15:36:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:36:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:37:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:37:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:37:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:37:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:37:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:37:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:38:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:38:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:38:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:38:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:39:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:40:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:40:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:40:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:40:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:40:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:41:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:41:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:41:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:41:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:41:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:42:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:43:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:44:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:47:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:48:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:48:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:48:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:48:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:48:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:48:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:48:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:49:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:50:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:50:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:50:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:50:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:50:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:50:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:51:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:52:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:53:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:53:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:53:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:53:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:53:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:53:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:53:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:53:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:54:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:54:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:54:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:55:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:55:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:55:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:55:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:56:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:57:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:59:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:59:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:59:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:59:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:59:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:59:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 15:59:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:00:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:01:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:32:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:32:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:38:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:38:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:38:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:38:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:38:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:39:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:39:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-11-20 16:39:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
