<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2017-01-04 13:34:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:34:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:34:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:34:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:34:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:34:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:34:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:34:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 13:34:57 --> Parsing Error - syntax error, unexpected 's' (T_STRING) in C:\xampp\htdocs\Project\fuel\app\classes\controller\register.php on line 35
WARNING - 2017-01-04 13:35:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 13:35:10 --> Parsing Error - syntax error, unexpected 's' (T_STRING) in C:\xampp\htdocs\Project\fuel\app\classes\controller\register.php on line 36
WARNING - 2017-01-04 13:35:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 13:35:19 --> Compile Error - Cannot redeclare class Email\AttachmentNotFoundException in C:\xampp\htdocs\Project\fuel\app\config\email.php on line 17
WARNING - 2017-01-04 13:37:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:37:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:37:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:38:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:38:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:38:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:38:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:38:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:38:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:55:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:55:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:55:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:55:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:55:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:55:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:55:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:56:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:56:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:56:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:56:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:56:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:56:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:56:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:57:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:58:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:58:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:58:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:58:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:58:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:58:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:58:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:59:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:59:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:59:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:59:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:59:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:59:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 13:59:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:00:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:00:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:00:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:10:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:11:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:11:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:12:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:12:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:12:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:12:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:12:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:12:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:12:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:14:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:14:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:15:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:16:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:18:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:18:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:18:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:19:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:19:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:23:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:23:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:23:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:24:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 14:24:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:05:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:06:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:06:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:15:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:15:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:16:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:16:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:16:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:16:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:18:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:18:55 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.publish' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`image` AS `t0_c21`, `t0`.`price` AS `t0_c22`, `t0`.`created_at` AS `t0_c23`, `t0`.`updated_at` AS `t0_c24` FROM `products` AS `t0` WHERE `t0`.`created_at` = '<' AND `t0`.`publish` < 1483539535" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:18:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:18:59 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.publish' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`image` AS `t0_c21`, `t0`.`price` AS `t0_c22`, `t0`.`created_at` AS `t0_c23`, `t0`.`updated_at` AS `t0_c24` FROM `products` AS `t0` WHERE `t0`.`created_at` = '<' AND `t0`.`publish` < 1483539539" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:19:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:19:00 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.publish' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`image` AS `t0_c21`, `t0`.`price` AS `t0_c22`, `t0`.`created_at` AS `t0_c23`, `t0`.`updated_at` AS `t0_c24` FROM `products` AS `t0` WHERE `t0`.`created_at` = '<' AND `t0`.`publish` < 1483539540" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:19:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:19:01 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.publish' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`image` AS `t0_c21`, `t0`.`price` AS `t0_c22`, `t0`.`created_at` AS `t0_c23`, `t0`.`updated_at` AS `t0_c24` FROM `products` AS `t0` WHERE `t0`.`created_at` = '<' AND `t0`.`publish` < 1483539541" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:19:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:19:02 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.publish' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`image` AS `t0_c21`, `t0`.`price` AS `t0_c22`, `t0`.`created_at` AS `t0_c23`, `t0`.`updated_at` AS `t0_c24` FROM `products` AS `t0` WHERE `t0`.`created_at` = '<' AND `t0`.`publish` < 1483539542" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:19:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:19:02 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.publish' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`tensanpham` AS `t0_c1`, `t0`.`slug` AS `t0_c2`, `t0`.`kichthuoc` AS `t0_c3`, `t0`.`bangtan` AS `t0_c4`, `t0`.`cpu` AS `t0_c5`, `t0`.`gpu` AS `t0_c6`, `t0`.`bonhotrong` AS `t0_c7`, `t0`.`ram` AS `t0_c8`, `t0`.`cambien` AS `t0_c9`, `t0`.`bluetooth` AS `t0_c10`, `t0`.`amthanh` AS `t0_c11`, `t0`.`wlan` AS `t0_c12`, `t0`.`gps` AS `t0_c13`, `t0`.`pin` AS `t0_c14`, `t0`.`manhinh` AS `t0_c15`, `t0`.`camera_truoc` AS `t0_c16`, `t0`.`camera_sau` AS `t0_c17`, `t0`.`quayphim` AS `t0_c18`, `t0`.`category` AS `t0_c19`, `t0`.`quantity` AS `t0_c20`, `t0`.`image` AS `t0_c21`, `t0`.`price` AS `t0_c22`, `t0`.`created_at` AS `t0_c23`, `t0`.`updated_at` AS `t0_c24` FROM `products` AS `t0` WHERE `t0`.`created_at` = '<' AND `t0`.`publish` < 1483539542" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:19:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:19:28 --> Fatal Error - Call to a member function limit() on array in C:\xampp\htdocs\Project\fuel\app\classes\controller\blog.php on line 32
WARNING - 2017-01-04 15:19:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:19:40 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:22:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:22:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:27:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:04 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:55 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:55 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:56 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:56 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:56 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:56 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:56 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:57 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:58 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:58 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:59 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:59 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:59 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:59 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:27:59 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:27:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:28:00 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:31:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:31:23 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:31:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:31:24 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:31:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:31:24 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:31:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:31:31 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:32:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:32:59 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:33:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:33:07 --> Runtime Recoverable error - Argument 1 passed to Orm\Query::_parse_where_array() must be of the type array, string given, called in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 634 and defined in C:\xampp\htdocs\Project\fuel\packages\orm\classes\query.php on line 621
WARNING - 2017-01-04 15:33:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:33:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:33:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:33:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:34:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:35:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:35:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:38:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:38:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:38:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:38:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:38:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:38:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:39:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:39:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:41:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:41:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:43:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:43:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:43:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:43:50 --> Fatal Error - Call to a member function limit() on array in C:\xampp\htdocs\Project\fuel\app\classes\controller\blog.php on line 35
WARNING - 2017-01-04 15:44:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:44:45 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283485` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:45:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:45:10 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283510` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:45:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:45:11 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283511` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:45:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:45:12 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283512` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:45:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:45:12 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283512` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:45:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:45:12 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283512` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:45:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:45:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:46:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:46:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:46:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:46:17 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283577` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:46:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:46:19 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283579` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:46:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:46:23 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283583` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:46:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 15:46:25 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.>' in 'field list' with query: "SELECT `t0`.`created_at` AS `t0_c0`, `t0`.`>` AS `t0_c1`, `t0`.`1476283585` AS `t0_c2`, `t0`.`id` AS `t0_c3` FROM `products` AS `t0`" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-04 15:46:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:46:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:49:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:49:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:49:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:49:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:49:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:49:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:50:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:52:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:52:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:52:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:52:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:52:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:55:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 15:59:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:00:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 16:00:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\product.php on line 19
WARNING - 2017-01-04 16:00:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 16:00:39 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\product.php on line 19
WARNING - 2017-01-04 16:01:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 16:01:10 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\admin\product\view.php on line 27
WARNING - 2017-01-04 16:02:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:02:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:02:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:03:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:05:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:05:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:05:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 16:05:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:06:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:06:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:06:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:06:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:06:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:06:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:06:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:06:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:07:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:08:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:09:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:09:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:23:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:25:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:25:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:47:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:47:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:47:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:47:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:48:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:48:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:49:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:49:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:51:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:51:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:54:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:55:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:56:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:56:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:56:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:56:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:57:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:57:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:57:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:57:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:57:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:57:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:57:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:57:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:59:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 18:59:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:01:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:01:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:01:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:01:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:02:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:03:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:03:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:03:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:03:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:04:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:04:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:04:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:05:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:06:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:07:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:08:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:08:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:08:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:08:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:08:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:09:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:09:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:10:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:10:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:10:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:10:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:10:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:11:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:11:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:11:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:12:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:12:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:14:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:14:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:14:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:14:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:15:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:15:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:16:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:16:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:16:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:17:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:17:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:17:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:17:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:17:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:17:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:36:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:36:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:36:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:36:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:37:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:37:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:37:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:37:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:38:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:38:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:38:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:38:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:38:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:38:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:39:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:39:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:39:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:39:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:39:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:39:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:39:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:39:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:41:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:41:52 --> Parsing Error - syntax error, unexpected ',' in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\product.php on line 158
WARNING - 2017-01-04 19:41:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:42:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:43:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:43:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:43:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:43:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:44:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:44:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:46:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:46:09 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:46:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:46:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:46:21 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:46:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:46:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:46:34 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 19:47:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:47:41 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 19:47:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:47:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:47:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:47:50 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 19:48:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:48:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:48:45 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 19:50:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:50:12 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 19:50:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:50:14 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:50:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:50:16 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:51:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:51:45 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:51:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:51:48 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:51:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:51:49 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:51:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:51:53 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:51:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:51:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:51:58 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:52:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:52:33 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:52:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:52:34 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:52:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:52:48 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:52:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:52:49 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:52:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:52:50 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:52:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:52:51 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:53:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:53:37 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:53:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:53:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:53:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:53:43 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:54:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:54:16 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:54:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:54:17 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:54:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:54:19 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:54:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:54:26 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 19:55:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:55:33 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\edit.php on line 6
WARNING - 2017-01-04 19:56:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:56:45 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\edit.php on line 6
WARNING - 2017-01-04 19:56:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:56:46 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\edit.php on line 6
WARNING - 2017-01-04 19:58:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:58:28 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\edit.php on line 18
WARNING - 2017-01-04 19:58:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:58:40 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\edit.php on line 6
WARNING - 2017-01-04 19:58:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 19:58:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:58:55 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\edit.php on line 6
WARNING - 2017-01-04 19:59:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 19:59:50 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:00:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:00:45 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:00:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:00:47 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:02:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:02:02 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:02:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:02:03 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:02:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:02:14 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:04:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:04:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:04:20 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:06:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:06:23 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:06:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:06:38 --> Notice - Undefined variable: products in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\product.php on line 89
WARNING - 2017-01-04 20:07:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:07:09 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:07:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:07:42 --> Notice - Undefined variable: view in C:\xampp\htdocs\Project\fuel\app\classes\controller\admin\product.php on line 141
WARNING - 2017-01-04 20:08:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:08:05 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:08:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:08:07 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:08:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:08:07 --> Notice - Undefined variable: product in C:\xampp\htdocs\Project\fuel\app\views\admin\product\_form_edit.php on line 3
WARNING - 2017-01-04 20:08:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:09:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:09:19 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 20:10:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:10:40 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 20:10:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:10:50 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 20:11:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:11:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:11:36 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 20:12:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:12:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:12:42 --> Error - No uploaded files were found. Did you specify "enctype" in your &lt;form&gt; tag? in C:\xampp\htdocs\Project\fuel\vendor\fuelphp\upload\src\Upload.php on line 92
WARNING - 2017-01-04 20:14:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:14:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:15:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:17:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:17:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:18:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:18:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:18:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:18:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:19:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:19:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:20:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:20:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:22:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:24:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:24:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:24:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:24:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:24:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:24:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:24:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:25:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:25:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:25:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:25:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:25:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:25:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:25:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:26:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:27:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:27:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:27:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:27:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:28:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:28:19 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 79
WARNING - 2017-01-04 20:28:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:28:55 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 68
WARNING - 2017-01-04 20:28:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:28:56 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 68
WARNING - 2017-01-04 20:28:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:28:56 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 68
WARNING - 2017-01-04 20:28:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:28:56 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 68
WARNING - 2017-01-04 20:28:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:28:57 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 68
WARNING - 2017-01-04 20:29:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:29:03 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 67
WARNING - 2017-01-04 20:29:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:29:16 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 64
WARNING - 2017-01-04 20:29:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:29:20 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 64
WARNING - 2017-01-04 20:29:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:29:20 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 64
WARNING - 2017-01-04 20:29:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:29:50 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 65
WARNING - 2017-01-04 20:29:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-04 20:29:51 --> Parsing Error - syntax error, unexpected end of file in C:\xampp\htdocs\Project\fuel\app\views\user\header\service\gioithieu.php on line 65
WARNING - 2017-01-04 20:30:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:30:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:30:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:30:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:31:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:31:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:31:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:31:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:31:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:31:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:32:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:32:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:32:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:32:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:32:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:32:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:33:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:34:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:34:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:34:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:34:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:34:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:34:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:35:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:36:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:36:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:36:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:36:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:40:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:40:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:40:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:40:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:42:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:42:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:42:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:42:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:47:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:47:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:47:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:47:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:50:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:50:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:50:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:50:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:51:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:51:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:54:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:54:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:54:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:54:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:55:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:55:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:55:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:55:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:55:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:55:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:55:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:55:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:56:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-04 20:56:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
