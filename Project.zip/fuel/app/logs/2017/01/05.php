<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2017-01-05 04:04:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:04:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:04:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:04:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:04:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:04:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:04:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:04:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:05:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:05:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:05:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:05:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:06:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:06:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:06:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:06:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:06:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:06:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:06:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:07:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:08:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:08:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:08:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:08:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:08:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:08:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:08:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:09:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:09:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:09:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:09:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:10:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:10:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:10:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:10:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:10:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:10:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:10:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:10:53 --> Fatal Error - Class 'Model_Sanpham' not found in C:\xampp\htdocs\Project\fuel\app\classes\controller\comment.php on line 7
WARNING - 2017-01-05 04:11:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:11:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:12:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:13:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:15:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:15:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:15:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:17:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:18:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:18:17 --> Parsing Error - syntax error, unexpected '=', expecting ')' in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:18:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:18:56 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.slug' in 'where clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`name` AS `t0_c1`, `t0`.`email` AS `t0_c2`, `t0`.`message` AS `t0_c3`, `t0`.`product_id` AS `t0_c4`, `t0`.`created_at` AS `t0_c5`, `t0`.`updated_at` AS `t0_c6` FROM `comments` AS `t0` WHERE `t0`.`slug` = 'samsung-s7'" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-05 04:19:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:19:37 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:20:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:20:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:20:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:20:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:20:39 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:20:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:20:47 --> Notice - Undefined index: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:20:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:20:56 --> Notice - Undefined offset: 0 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:21:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:21:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:21:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:21:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:21:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:21:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:22:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:22:32 --> Notice - Undefined index: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:22:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:22:39 --> Parsing Error - syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:23:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:23:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:23:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:23:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:23:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:23:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:24:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:24:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:06 --> Notice - Undefined offset: 3 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:24:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:06 --> Notice - Undefined offset: 3 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:24:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:24:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:19 --> Notice - Undefined offset: 3 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:24:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:20 --> Notice - Undefined offset: 3 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:24:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:27 --> Notice - Undefined offset: 2 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:24:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:24:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:34 --> Notice - Undefined offset: 3 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:24:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:35 --> Notice - Undefined offset: 3 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:24:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:24:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:24:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:24:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:41 --> Notice - Undefined offset: 3 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:24:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:24:41 --> Notice - Undefined offset: 3 in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:27:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:27:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:28:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:28:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:28:09 --> Notice - Undefined variable: Debug in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 49
WARNING - 2017-01-05 04:28:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:28:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:28:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:30:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:30:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:30:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:32:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:32:44 --> 42000 - SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`name` AS `t0_c1`, `t0`.`email` AS `t0_c2`, `t0`.`message` AS `t0_c3`, `t0`.`product_id` AS `t0_c4`, `t0`.`created_at` AS `t0_c5`, `t0`.`updated_at` AS `t0_c6` FROM `comments` AS `t0` WHERE `t0`.`product_id` = ()" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-05 04:33:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:33:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:33:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:34:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:34:26 --> Notice - Array to string conversion in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:35:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:03 --> Notice - Array to string conversion in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:35:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:04 --> Notice - Array to string conversion in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:35:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:04 --> Notice - Array to string conversion in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:35:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:04 --> Notice - Array to string conversion in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 48
WARNING - 2017-01-05 04:35:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:13 --> Warning - array_search() expects parameter 2 to be array, object given in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 1025
WARNING - 2017-01-05 04:35:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:13 --> Warning - array_search() expects parameter 2 to be array, object given in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 1025
WARNING - 2017-01-05 04:35:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:19 --> Warning - array_search() expects parameter 2 to be array, object given in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 1025
WARNING - 2017-01-05 04:35:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:20 --> Warning - array_search() expects parameter 2 to be array, object given in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 1025
WARNING - 2017-01-05 04:35:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:45 --> Warning - Illegal string offset 'id' in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 139
WARNING - 2017-01-05 04:35:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:35:47 --> Warning - Illegal string offset 'id' in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 139
WARNING - 2017-01-05 04:36:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:36:02 --> Warning - Illegal string offset 'id' in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 139
WARNING - 2017-01-05 04:36:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:36:03 --> Warning - Illegal string offset 'id' in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 139
WARNING - 2017-01-05 04:36:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:36:03 --> Warning - Illegal string offset 'id' in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 139
WARNING - 2017-01-05 04:36:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:36:03 --> Warning - Illegal string offset 'id' in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 139
WARNING - 2017-01-05 04:36:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:36:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:36:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:36:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:37:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:37:25 --> Warning - array_search() expects parameter 2 to be array, object given in C:\xampp\htdocs\Project\fuel\core\classes\arr.php on line 1025
WARNING - 2017-01-05 04:37:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:37:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:37:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:37:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:37:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:38:02 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 53
WARNING - 2017-01-05 04:38:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:38:03 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 53
WARNING - 2017-01-05 04:38:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:38:09 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 53
WARNING - 2017-01-05 04:38:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:38:09 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 53
WARNING - 2017-01-05 04:38:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:38:21 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 04:38:21 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:38:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:38:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:38:30 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:38:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:38:30 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:40:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:01 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:01 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:40:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:27 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:27 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:40:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:40:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 04:40:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:40:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:40:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:50 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:50 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:40:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:40:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:40:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:41:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:41:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:41:01 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:41:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:41:02 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:42:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:42:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:42:21 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:42:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:42:21 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:42:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:42:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:42:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:42:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:42:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:42:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:42:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:42:42 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\product\chitiet.php on line 240
WARNING - 2017-01-05 04:43:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:43:30 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\views\product\chitiet.php on line 242
WARNING - 2017-01-05 04:43:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:43:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:43:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:43:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:43:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:43:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:43:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:43:52 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:43:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:43:53 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:43:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:43:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:43:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:43:53 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 04:43:53 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:44:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:44:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:44:11 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:44:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:44:11 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:45:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:45:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:45:13 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:45:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:45:13 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:45:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:45:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:45:34 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:45:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:45:35 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:46:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:46:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:46:21 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:46:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:46:21 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:46:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:46:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:46:27 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:46:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:46:27 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:51:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:51:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:51:46 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:51:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:51:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:51:47 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 04:51:47 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:51:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:51:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:51:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:51:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:52:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:52:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:52:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:52:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:52:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:52:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:52:10 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:52:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:52:10 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:52:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:52:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:52:28 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:52:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:52:28 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:52:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:52:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:52:38 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:52:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:52:38 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:54:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:54:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:54:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:54:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:54:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:54:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:54:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:54:52 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:54:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:54:52 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:55:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:55:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:55:00 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:55:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:55:00 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 04:55:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:55:06 --> Error - File "C:/xampp/htdocs/Project/fuel/app/classes/controller/user/comment.php" does not contain class "Controller_User_Comment" in C:\xampp\htdocs\Project\fuel\core\classes\autoloader.php on line 397
WARNING - 2017-01-05 04:56:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:56:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 04:56:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 04:56:55 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 04:56:55 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:00:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:00:19 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:00:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:00:22 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:00:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:00:26 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:01:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:01:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:01:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:01:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:01:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:02:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:02:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:02:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:02:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:02:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:04:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:04:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:04:16 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:04:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:04:16 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:04:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:04:20 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:04:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:04:56 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:04:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:04:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:04:58 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:04:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:04:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:04:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:04:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:04:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:04:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:04:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:05:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:05:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:05:00 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:05:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:05:00 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:05:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:05:03 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:05:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:05:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:05:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:05:15 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 05:05:15 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:05:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:05:18 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:05:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:05:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:05:48 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:05:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:05:48 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:06:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:06:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:06:28 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:06:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:06:28 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:06:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:06:31 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:06:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:06:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:07:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:07:25 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:07:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:07:38 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:07:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:07:40 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:07:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:07:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:07:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:07:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:07:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:09:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:09:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:09:53 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:09:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:09:54 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:09:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:09:55 --> Error - File "C:/xampp/htdocs/Project/fuel/app/classes/controller/user/comment.php" does not contain class "Controller_User_Comment" in C:\xampp\htdocs\Project\fuel\core\classes\autoloader.php on line 397
WARNING - 2017-01-05 05:13:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:18 --> Error - File "C:/xampp/htdocs/Project/fuel/app/classes/controller/user/comment.php" does not contain class "Controller_User_Comment" in C:\xampp\htdocs\Project\fuel\core\classes\autoloader.php on line 397
WARNING - 2017-01-05 05:13:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:13:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:22 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:22 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:24 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:46 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:47 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:13:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:48 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:48 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:51 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:13:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:57 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:13:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:13:57 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:14:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:14:00 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:14:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:14:06 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:14:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:14:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:14:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:14:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:14:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:14:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:14:11 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:15:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:16:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:16:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:16:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:16:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:16:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:16:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:16:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:20:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:20:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:21:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:21:49 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:21:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:21:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:21:52 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:21:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:21:52 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:21:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:21:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:21:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:21:53 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 05:21:53 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:21:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:21:57 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:23:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:23:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:23:29 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:23:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:23:29 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:23:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:23:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:23:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:23:30 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 05:23:30 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:23:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:23:33 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:24:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:24:56 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:24:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:24:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:24:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:24:57 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 05:24:58 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:24:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:24:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:24:58 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:24:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:24:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:24:58 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:24:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:24:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:24:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 05:24:59 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:25:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:25:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:25:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:25:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:25:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:25:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:25:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:25:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:25:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:25:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:25:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:25:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:25:54 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:25:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:25:54 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:32:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:32:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:32:30 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:32:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:32:30 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:33:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:33:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:33:24 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:33:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:33:24 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:33:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:33:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:33:57 --> Warning - Illegal string offset 'id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:35:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:35:23 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:49:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:49:06 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 10
WARNING - 2017-01-05 05:50:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:50:49 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:50:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:50:50 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:50:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:50:50 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:50:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:50:51 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:50:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:50:51 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:50:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:50:51 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:51:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:02 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:51:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:03 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:51:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:51:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:11 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:15 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:23 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:25 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:34 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:36 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:47 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:51:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:51 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:51 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:51:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:51:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:51:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:51:56 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:53:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:53:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:53:29 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:53:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:53:29 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:53:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:53:31 --> Warning - Illegal string offset 'product_id' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 9
WARNING - 2017-01-05 05:56:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:56:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:56:29 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:57:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:57:03 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:57:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:57:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:57:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:57:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:57:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:57:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:57:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:57:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:57:09 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:57:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:57:09 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:57:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:57:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:57:12 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:58:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:58:33 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:58:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:58:35 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:58:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:58:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:58:39 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:58:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:58:40 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:58:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:58:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:58:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:58:43 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:58:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:58:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:58:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:58:48 --> Parsing Error - syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 19
WARNING - 2017-01-05 05:58:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:58:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:58:54 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:59:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:59:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:59:00 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:59:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:59:00 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:59:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:59:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:59:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:59:04 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:59:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:59:04 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:59:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 05:59:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:59:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:59:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:59:30 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 05:59:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 05:59:33 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:00:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:00:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:00:04 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:00:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:00:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:00:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:00:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:00:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:00:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:00:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:00:12 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:04:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:04:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:04:03 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:04:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:04:04 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:04:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:04:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:04:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:04:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:04:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:04:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:04:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:04:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:04:11 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:04:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:04:12 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:04:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:04:16 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column '$id' in 'where clause' with query: "SELECT `product_id` FROM `comments` WHERE `id` = $id" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-05 06:05:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:20 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column '$product_id' in 'where clause' with query: "SELECT `slug` FROM `products` WHERE `id` = $product_id" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-05 06:05:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:21 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:05:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:22 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:22 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:05:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:24 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:24 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:27 --> 1054 - SQLSTATE[42S22]: Column not found: 1054 Unknown column '$product_id' in 'where clause' with query: "SELECT `slug` FROM `products` WHERE `id` = $product_id" in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 253
WARNING - 2017-01-05 06:05:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:40 --> Runtime Recoverable error - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 12
WARNING - 2017-01-05 06:05:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:05:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:42 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:42 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:05:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:05:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:05:46 --> Runtime Recoverable error - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 12
WARNING - 2017-01-05 06:13:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:13:14 --> Runtime Recoverable error - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\xampp\htdocs\Project\fuel\core\classes\database\connection.php on line 600
WARNING - 2017-01-05 06:13:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:13:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:13:25 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:13:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:13:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:13:40 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:13:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:13:40 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:14:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:14:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:14:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:16 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:14:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:16 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:14:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:20 --> Runtime Recoverable error - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 16
WARNING - 2017-01-05 06:14:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:14:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:37 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:14:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:14:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:46 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:14:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:46 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:14:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:14:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:14:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:50 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:14:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:50 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:14:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:14:54 --> Runtime Recoverable error - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 16
WARNING - 2017-01-05 06:16:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:16:22 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:16:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:16:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:16:31 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:16:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:16:31 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:16:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:16:31 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:16:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:16:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:16:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:16:38 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:16:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:16:38 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:16:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:16:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:16:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:16:42 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:16:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:16:42 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:17:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:17:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:17:27 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:17:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:17:28 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:17:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:17:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:17:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:17:34 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:17:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:17:34 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:17:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:17:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 06:17:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:17:37 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:17:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:17:37 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 06:20:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 06:23:36 --> Parsing Error - syntax error, unexpected 'echo' (T_ECHO) in C:\xampp\htdocs\Project\fuel\packages\oil\classes\console.php(116) : eval()'d code on line 1
WARNING - 2017-01-05 07:01:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:01:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:01:10 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:01:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:01:10 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:01:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:01:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:01:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:01:14 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:01:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:01:14 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:01:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:01:18 --> Notice - Undefined index: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 13
WARNING - 2017-01-05 07:02:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:02:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:02:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:02:12 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:02:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:02:12 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:02 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:02 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:06 --> Notice - Trying to get property of non-object in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 10
WARNING - 2017-01-05 07:06:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:16 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:16 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:24 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:24 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:28 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:28 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:48 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:48 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:06:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:54 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:54 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:06:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:06:58 --> Notice - Array to string conversion in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 16
WARNING - 2017-01-05 07:07:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:07:30 --> Notice - Undefined variable: cc in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 12
WARNING - 2017-01-05 07:07:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:07:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:07:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:07:32 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 07:07:32 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:07:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:07:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:07:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:07:37 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:07:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:07:37 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:07:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:07:41 --> Notice - Undefined variable: value in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 19
WARNING - 2017-01-05 07:08:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:08:40 --> Notice - Undefined variable: cc in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 12
WARNING - 2017-01-05 07:08:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:08:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:08:43 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:08:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:08:44 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:08:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:08:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:08:45 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:08:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:08:45 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:08:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:08:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:08:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:08:49 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:08:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:08:49 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:08:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:08:52 --> Notice - Undefined variable: sex in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 19
WARNING - 2017-01-05 07:09:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:09:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:09:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:09:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:09:41 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:09:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:09:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:09:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:09:46 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:09:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:09:46 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:09:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:09:50 --> Notice - Undefined variable: dech in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 19
WARNING - 2017-01-05 07:10:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:23 --> Notice - Undefined variable: cc in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 12
WARNING - 2017-01-05 07:10:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:10:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:35 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:10:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:35 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:10:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:10:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:10:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:38 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:10:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:38 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:10:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:10:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:10:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:43 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:10:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:43 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:10:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:10:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:10:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:49 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:10:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:10:49 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:05 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 07:11:08 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:32 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 07:11:32 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:35 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:36 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:39 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:39 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:51 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 07:11:51 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:11:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:55 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 07:11:55 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:11:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:11:59 --> Notice - Undefined variable: dech in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 19
WARNING - 2017-01-05 07:12:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:12:04 --> Notice - Undefined variable: cc in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 12
WARNING - 2017-01-05 07:12:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:12:05 --> Notice - Undefined variable: cc in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 12
WARNING - 2017-01-05 07:12:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:12:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:12:10 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:12:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:12:10 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:12:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:12:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:12:46 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:12:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:12:47 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:12:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:12:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:12:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:12:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:12:50 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 07:12:50 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:12:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:12:54 --> Notice - Undefined variable: dech in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 25
WARNING - 2017-01-05 07:19:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:19:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:19:57 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:19:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:19:57 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:20:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:20:04 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 07:20:04 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:20:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:20:08 --> Notice - Undefined variable: dech in C:\xampp\htdocs\Project\fuel\app\classes\controller\user\comment.php on line 25
WARNING - 2017-01-05 07:20:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:20:48 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:20:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:20:48 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:20:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:20:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:20:53 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:20:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:20:53 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:21:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:22:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:26:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:26:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:27:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:27:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:27:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:27:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:28:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:28:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:28:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:28:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:28:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:30:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:30:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:31:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:31:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:31:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:31:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:31:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:31:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:31:35 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:31:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:31:35 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:33:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:33:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:33:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:33:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:33:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:33:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:33:37 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:33:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:33:37 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:34:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:34:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:35:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:35:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:35:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:35:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:35:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:35:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:35:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:36:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:36:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:57:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:57:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:57:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:57:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:57:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:57:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:57:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:58:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:58:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:59:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:59:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:59:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:59:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:59:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 07:59:34 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
ERROR - 2017-01-05 07:59:34 --> Notice - Undefined variable: id in C:\xampp\htdocs\Project\fuel\app\classes\controller\product.php on line 52
WARNING - 2017-01-05 07:59:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:59:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:59:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 07:59:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:09:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:09:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:09:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:09:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:10:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:10:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:10:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:10:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:10:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 08:10:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 14:30:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 14:30:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 14:32:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 14:32:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:07:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:07:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:10:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:11:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:11:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 15:12:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:34:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:37:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:37:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:37:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:37:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:37:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:37:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:37:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:37:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:38:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:38:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:38:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:38:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:39:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:40:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:40:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:40:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:40:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:40:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 16:40:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:28:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 17:29:07 --> 2002 - SQLSTATE[HY000] [2002] A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 112
WARNING - 2017-01-05 17:33:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:33:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 17:33:38 --> 2002 - SQLSTATE[HY000] [2002] A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 112
WARNING - 2017-01-05 17:33:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 17:33:46 --> Error - Could not find asset: samsung a51483534711.jpg in C:\xampp\htdocs\Project\fuel\core\classes\asset\instance.php on line 413
WARNING - 2017-01-05 17:33:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2017-01-05 17:33:48 --> Error - Could not find asset: samsung a51483534711.jpg in C:\xampp\htdocs\Project\fuel\core\classes\asset\instance.php on line 413
ERROR - 2017-01-05 17:33:50 --> 2002 - SQLSTATE[HY000] [2002] A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 in C:\xampp\htdocs\Project\fuel\core\classes\database\pdo\connection.php on line 112
WARNING - 2017-01-05 17:34:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:34:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:35:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2017-01-05 17:35:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
