<?php
return array (
  'crypto_key' => 'PM8cCImXg3BgFsEfLMS5cf6I',
  'crypto_iv' => 'byQx2UbSYPhg2uQmmI7FkyAE',
  'crypto_hmac' => 'vAoO9MEQcrYEOFgAcs1uMETg',
);
