<?php
return array (
  'crypto_key' => 'K1sWekbJ40PksYAAQgdv8QJY',
  'crypto_iv' => 'BDE5NkxyMcOM0x4zrQjVAUuE',
  'crypto_hmac' => 'cEwRIkZsomLUH4sTog09Igog',
);
