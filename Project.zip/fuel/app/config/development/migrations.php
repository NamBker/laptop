<?php
return array (
  'version' => 
  array (
    'app' => 
    array (
      'default' => 
      array (
        0 => '001_create_users',
        1 => '002_create_posts',
        2 => '003_create_comments',
        3 => '004_create_gioithieus',
        4 => '005_create_lienhes',
        5 => '006_create_categories',
        6 => '007_create_checkouts',
        7 => '008_create_prices',
        8 => '009_create_priceimports',
        9 => '010_create_sanphams',
      ),
    ),
    'module' => 
    array (
    ),
    'package' => 
    array (
    ),
  ),
  'folder' => 'migrations/',
  'table' => 'migration',
);
