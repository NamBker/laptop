<?php
/**
 * The development database settings. These get merged with the global settings.
 */

// return array(
// 	'default' => array(
// 		'connection'  => array(
// 			'dsn'        => 'mysql:host=localhost;dbname=fantastic',
// 			'username'   => 'root',
// 			'password'   => '',
// 		),
// 	),
// );
return array(
	'default' => array(
		'connection'  => array(
			'dsn'        => 'mysql:host=ustora.96.lt;dbname=u613725151_stora',
			'username'   => 'u613725151_stora',
			'password'   => '123456',
		),
	),
);

