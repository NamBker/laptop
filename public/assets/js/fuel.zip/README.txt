In that code is not all workable!
It it just my test version of internet shop.
Without any validators, and 'add to cart' function. etc...

1. create database `shop`.
2. Use sql file to load all data.
3. READ -> http://www.fuelphp.com/docs/installation/instructions.html
3a. config.php => 'base_url'        => 'http://abba.com/' or other URL address whatever you want
4. edit inside css code if needed URLs from /public/assets/ to assets/

Sorry, but code without comments.

So, I am not responsible! :)

Good luck!

If you will have any questions about my code please - read docs, and that forum.
Because I do not why my code is working. :)