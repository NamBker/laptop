# --------------------------------------------------------
# Host:                         127.0.0.1
# Server version:               5.1.57-community - MySQL Community Server (GPL)
# Server OS:                    Win32
# HeidiSQL version:             6.0.0.3947
# Date/time:                    2011-09-28 16:16:14
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

# Dumping database structure for shop
CREATE DATABASE IF NOT EXISTS `shop` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `shop`;


# Dumping structure for table shop.brands
CREATE TABLE IF NOT EXISTS `brands` (
  `brandid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `brandname` varchar(50) NOT NULL,
  PRIMARY KEY (`brandid`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='Some brands';

# Dumping data for table shop.brands: ~32 rows (approximately)
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` (`brandid`, `brandname`) VALUES
	(1, 'Apple'),
	(2, 'Samsung'),
	(3, 'Nokia'),
	(4, 'HTC'),
	(5, 'Sony Ericsson'),
	(6, 'Motorolla'),
	(7, 'LG'),
	(8, 'Panasonic'),
	(9, 'HP'),
	(10, 'Acer'),
	(11, 'MSI'),
	(12, 'Lenovo'),
	(13, 'Sony'),
	(14, 'Casio'),
	(15, 'Logitech'),
	(16, 'ZTE'),
	(17, 'Huawei'),
	(18, 'Kodak'),
	(19, 'T\'nB'),
	(20, 'Asus'),
	(21, 'Toshiba'),
	(22, 'Dell'),
	(23, 'Philips'),
	(24, 'AOC'),
	(25, 'MyPhone'),
	(26, 'Palm'),
	(27, 'Canon'),
	(28, 'Nikon'),
	(29, 'Alien'),
	(30, 'Microsoft'),
	(31, 'Linux'),
	(32, 'Adobe');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;


# Dumping structure for table shop.carts
CREATE TABLE IF NOT EXISTS `carts` (
  `cookie_user_id` varchar(40) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `item_id` mediumint(9) unsigned NOT NULL,
  `item_quantity` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `item_price` decimal(8,2) unsigned NOT NULL,
  `item_color` varchar(20) DEFAULT NULL,
  `item_size` varchar(5) DEFAULT NULL,
  `order_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `cookie_user_id` (`cookie_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Here cart table, item_color and item_size just for example!!';

# Dumping data for table shop.carts: ~1 rows (approximately)
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` (`cookie_user_id`, `user_id`, `item_id`, `item_quantity`, `item_price`, `item_color`, `item_size`, `order_time`) VALUES
	('627c733b76bee13ca347657840adc2f18f5608f5', NULL, 12, 1, 123.00, NULL, NULL, '2011-09-28 14:19:31');
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;


# Dumping structure for table shop.category
CREATE TABLE IF NOT EXISTS `category` (
  `categoryid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(50) NOT NULL,
  `categoryurl` varchar(50) NOT NULL,
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

# Dumping data for table shop.category: ~8 rows (approximately)
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`categoryid`, `categoryname`, `categoryurl`) VALUES
	(1, 'Desktops', 'desktops'),
	(2, 'Laptops and Notebooks', 'laptops_and_notebooks'),
	(3, 'Components', 'components'),
	(4, 'Tablets', 'tablets'),
	(5, 'Cameras', 'cameras'),
	(6, 'Phones and PDA', 'phones_and_pda'),
	(7, 'Software', 'software'),
	(8, 'Mp3 Player', 'mp3_player');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


# Dumping structure for table shop.country
CREATE TABLE IF NOT EXISTS `country` (
  `countryid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  PRIMARY KEY (`countryid`)
) ENGINE=InnoDB AUTO_INCREMENT=240 DEFAULT CHARSET=utf8 COMMENT='Here NOT all countries in the world!';

# Dumping data for table shop.country: ~239 rows (approximately)
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` (`countryid`, `country_code`, `country_name`) VALUES
	(1, 'US', 'United States'),
	(2, 'CA', 'Canada'),
	(3, 'AF', 'Afghanistan'),
	(4, 'AL', 'Albania'),
	(5, 'DZ', 'Algeria'),
	(6, 'DS', 'American Samoa'),
	(7, 'AD', 'Andorra'),
	(8, 'AO', 'Angola'),
	(9, 'AI', 'Anguilla'),
	(10, 'AQ', 'Antarctica'),
	(11, 'AG', 'Antigua and/or Barbuda'),
	(12, 'AR', 'Argentina'),
	(13, 'AM', 'Armenia'),
	(14, 'AW', 'Aruba'),
	(15, 'AU', 'Australia'),
	(16, 'AT', 'Austria'),
	(17, 'AZ', 'Azerbaijan'),
	(18, 'BS', 'Bahamas'),
	(19, 'BH', 'Bahrain'),
	(20, 'BD', 'Bangladesh'),
	(21, 'BB', 'Barbados'),
	(22, 'BY', 'Belarus'),
	(23, 'BE', 'Belgium'),
	(24, 'BZ', 'Belize'),
	(25, 'BJ', 'Benin'),
	(26, 'BM', 'Bermuda'),
	(27, 'BT', 'Bhutan'),
	(28, 'BO', 'Bolivia'),
	(29, 'BA', 'Bosnia and Herzegovina'),
	(30, 'BW', 'Botswana'),
	(31, 'BV', 'Bouvet Island'),
	(32, 'BR', 'Brazil'),
	(33, 'IO', 'British lndian Ocean Territory'),
	(34, 'BN', 'Brunei Darussalam'),
	(35, 'BG', 'Bulgaria'),
	(36, 'BF', 'Burkina Faso'),
	(37, 'BI', 'Burundi'),
	(38, 'KH', 'Cambodia'),
	(39, 'CM', 'Cameroon'),
	(40, 'CV', 'Cape Verde'),
	(41, 'KY', 'Cayman Islands'),
	(42, 'CF', 'Central African Republic'),
	(43, 'TD', 'Chad'),
	(44, 'CL', 'Chile'),
	(45, 'CN', 'China'),
	(46, 'CX', 'Christmas Island'),
	(47, 'CC', 'Cocos (Keeling) Islands'),
	(48, 'CO', 'Colombia'),
	(49, 'KM', 'Comoros'),
	(50, 'CG', 'Congo'),
	(51, 'CK', 'Cook Islands'),
	(52, 'CR', 'Costa Rica'),
	(53, 'HR', 'Croatia (Hrvatska)'),
	(54, 'CU', 'Cuba'),
	(55, 'CY', 'Cyprus'),
	(56, 'CZ', 'Czech Republic'),
	(57, 'DK', 'Denmark'),
	(58, 'DJ', 'Djibouti'),
	(59, 'DM', 'Dominica'),
	(60, 'DO', 'Dominican Republic'),
	(61, 'TP', 'East Timor'),
	(62, 'EC', 'Ecudaor'),
	(63, 'EG', 'Egypt'),
	(64, 'SV', 'El Salvador'),
	(65, 'GQ', 'Equatorial Guinea'),
	(66, 'ER', 'Eritrea'),
	(67, 'EE', 'Estonia'),
	(68, 'ET', 'Ethiopia'),
	(69, 'FK', 'Falkland Islands (Malvinas)'),
	(70, 'FO', 'Faroe Islands'),
	(71, 'FJ', 'Fiji'),
	(72, 'FI', 'Finland'),
	(73, 'FR', 'France'),
	(74, 'FX', 'France, Metropolitan'),
	(75, 'GF', 'French Guiana'),
	(76, 'PF', 'French Polynesia'),
	(77, 'TF', 'French Southern Territories'),
	(78, 'GA', 'Gabon'),
	(79, 'GM', 'Gambia'),
	(80, 'GE', 'Georgia'),
	(81, 'DE', 'Germany'),
	(82, 'GH', 'Ghana'),
	(83, 'GI', 'Gibraltar'),
	(84, 'GR', 'Greece'),
	(85, 'GL', 'Greenland'),
	(86, 'GD', 'Grenada'),
	(87, 'GP', 'Guadeloupe'),
	(88, 'GU', 'Guam'),
	(89, 'GT', 'Guatemala'),
	(90, 'GN', 'Guinea'),
	(91, 'GW', 'Guinea-Bissau'),
	(92, 'GY', 'Guyana'),
	(93, 'HT', 'Haiti'),
	(94, 'HM', 'Heard and Mc Donald Islands'),
	(95, 'HN', 'Honduras'),
	(96, 'HK', 'Hong Kong'),
	(97, 'HU', 'Hungary'),
	(98, 'IS', 'Iceland'),
	(99, 'IN', 'India'),
	(100, 'ID', 'Indonesia'),
	(101, 'IR', 'Iran (Islamic Republic of)'),
	(102, 'IQ', 'Iraq'),
	(103, 'IE', 'Ireland'),
	(104, 'IL', 'Israel'),
	(105, 'IT', 'Italy'),
	(106, 'CI', 'Ivory Coast'),
	(107, 'JM', 'Jamaica'),
	(108, 'JP', 'Japan'),
	(109, 'JO', 'Jordan'),
	(110, 'KZ', 'Kazakhstan'),
	(111, 'KE', 'Kenya'),
	(112, 'KI', 'Kiribati'),
	(113, 'KP', 'Korea, Democratic People\'s Republic of'),
	(114, 'KR', 'Korea, Republic of'),
	(115, 'KW', 'Kuwait'),
	(116, 'KG', 'Kyrgyzstan'),
	(117, 'LA', 'Lao People\'s Democratic Republic'),
	(118, 'LV', 'Latvia'),
	(119, 'LB', 'Lebanon'),
	(120, 'LS', 'Lesotho'),
	(121, 'LR', 'Liberia'),
	(122, 'LY', 'Libyan Arab Jamahiriya'),
	(123, 'LI', 'Liechtenstein'),
	(124, 'LT', 'Lithuania'),
	(125, 'LU', 'Luxembourg'),
	(126, 'MO', 'Macau'),
	(127, 'MK', 'Macedonia'),
	(128, 'MG', 'Madagascar'),
	(129, 'MW', 'Malawi'),
	(130, 'MY', 'Malaysia'),
	(131, 'MV', 'Maldives'),
	(132, 'ML', 'Mali'),
	(133, 'MT', 'Malta'),
	(134, 'MH', 'Marshall Islands'),
	(135, 'MQ', 'Martinique'),
	(136, 'MR', 'Mauritania'),
	(137, 'MU', 'Mauritius'),
	(138, 'TY', 'Mayotte'),
	(139, 'MX', 'Mexico'),
	(140, 'FM', 'Micronesia, Federated States of'),
	(141, 'MD', 'Moldova, Republic of'),
	(142, 'MC', 'Monaco'),
	(143, 'MN', 'Mongolia'),
	(144, 'MS', 'Montserrat'),
	(145, 'MA', 'Morocco'),
	(146, 'MZ', 'Mozambique'),
	(147, 'MM', 'Myanmar'),
	(148, 'NA', 'Namibia'),
	(149, 'NR', 'Nauru'),
	(150, 'NP', 'Nepal'),
	(151, 'NL', 'Netherlands'),
	(152, 'AN', 'Netherlands Antilles'),
	(153, 'NC', 'New Caledonia'),
	(154, 'NZ', 'New Zealand'),
	(155, 'NI', 'Nicaragua'),
	(156, 'NE', 'Niger'),
	(157, 'NG', 'Nigeria'),
	(158, 'NU', 'Niue'),
	(159, 'NF', 'Norfork Island'),
	(160, 'MP', 'Northern Mariana Islands'),
	(161, 'NO', 'Norway'),
	(162, 'OM', 'Oman'),
	(163, 'PK', 'Pakistan'),
	(164, 'PW', 'Palau'),
	(165, 'PA', 'Panama'),
	(166, 'PG', 'Papua New Guinea'),
	(167, 'PY', 'Paraguay'),
	(168, 'PE', 'Peru'),
	(169, 'PH', 'Philippines'),
	(170, 'PN', 'Pitcairn'),
	(171, 'PL', 'Poland'),
	(172, 'PT', 'Portugal'),
	(173, 'PR', 'Puerto Rico'),
	(174, 'QA', 'Qatar'),
	(175, 'RE', 'Reunion'),
	(176, 'RO', 'Romania'),
	(177, 'RU', 'Russian Federation'),
	(178, 'RW', 'Rwanda'),
	(179, 'KN', 'Saint Kitts and Nevis'),
	(180, 'LC', 'Saint Lucia'),
	(181, 'VC', 'Saint Vincent and the Grenadines'),
	(182, 'WS', 'Samoa'),
	(183, 'SM', 'San Marino'),
	(184, 'ST', 'Sao Tome and Principe'),
	(185, 'SA', 'Saudi Arabia'),
	(186, 'SN', 'Senegal'),
	(187, 'SC', 'Seychelles'),
	(188, 'SL', 'Sierra Leone'),
	(189, 'SG', 'Singapore'),
	(190, 'SK', 'Slovakia'),
	(191, 'SI', 'Slovenia'),
	(192, 'SB', 'Solomon Islands'),
	(193, 'SO', 'Somalia'),
	(194, 'ZA', 'South Africa'),
	(195, 'GS', 'South Georgia South Sandwich Islands'),
	(196, 'ES', 'Spain'),
	(197, 'LK', 'Sri Lanka'),
	(198, 'SH', 'St. Helena'),
	(199, 'PM', 'St. Pierre and Miquelon'),
	(200, 'SD', 'Sudan'),
	(201, 'SR', 'Suriname'),
	(202, 'SJ', 'Svalbarn and Jan Mayen Islands'),
	(203, 'SZ', 'Swaziland'),
	(204, 'SE', 'Sweden'),
	(205, 'CH', 'Switzerland'),
	(206, 'SY', 'Syrian Arab Republic'),
	(207, 'TW', 'Taiwan'),
	(208, 'TJ', 'Tajikistan'),
	(209, 'TZ', 'Tanzania, United Republic of'),
	(210, 'TH', 'Thailand'),
	(211, 'TG', 'Togo'),
	(212, 'TK', 'Tokelau'),
	(213, 'TO', 'Tonga'),
	(214, 'TT', 'Trinidad and Tobago'),
	(215, 'TN', 'Tunisia'),
	(216, 'TR', 'Turkey'),
	(217, 'TM', 'Turkmenistan'),
	(218, 'TC', 'Turks and Caicos Islands'),
	(219, 'TV', 'Tuvalu'),
	(220, 'UG', 'Uganda'),
	(221, 'UA', 'Ukraine'),
	(222, 'AE', 'United Arab Emirates'),
	(223, 'GB', 'United Kingdom'),
	(224, 'UM', 'United States minor outlying islands'),
	(225, 'UY', 'Uruguay'),
	(226, 'UZ', 'Uzbekistan'),
	(227, 'VU', 'Vanuatu'),
	(228, 'VA', 'Vatican City State'),
	(229, 'VE', 'Venezuela'),
	(230, 'VN', 'Vietnam'),
	(231, 'VG', 'Virigan Islands (British)'),
	(232, 'VI', 'Virgin Islands (U.S.)'),
	(233, 'WF', 'Wallis and Futuna Islands'),
	(234, 'EH', 'Western Sahara'),
	(235, 'YE', 'Yemen'),
	(236, 'YU', 'Yugoslavia'),
	(237, 'ZR', 'Zaire'),
	(238, 'ZM', 'Zambia'),
	(239, 'ZW', 'Zimbabwe');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;


# Dumping structure for table shop.currensy
CREATE TABLE IF NOT EXISTS `currensy` (
  `currensyid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `currensyname` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`currensyid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='Some word currensy';

# Dumping data for table shop.currensy: ~13 rows (approximately)
/*!40000 ALTER TABLE `currensy` DISABLE KEYS */;
INSERT INTO `currensy` (`currensyid`, `currensyname`) VALUES
	(1, 'USD'),
	(2, 'EUR'),
	(3, 'GBP'),
	(4, 'CHF'),
	(5, 'SEK'),
	(6, 'NOK'),
	(7, 'DKK'),
	(8, 'JPY'),
	(9, 'RUB'),
	(10, 'HUF'),
	(11, 'SGD'),
	(12, 'CAD'),
	(13, 'PLN');
/*!40000 ALTER TABLE `currensy` ENABLE KEYS */;


# Dumping structure for table shop.items
CREATE TABLE IF NOT EXISTS `items` (
  `itemid` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `itemcategoryid` tinyint(3) unsigned DEFAULT NULL,
  `itemsubcategoryid` tinyint(3) unsigned DEFAULT NULL,
  `itemname` varchar(50) NOT NULL,
  `quantity` tinyint(3) unsigned NOT NULL,
  `newprice` decimal(8,2) unsigned DEFAULT NULL,
  `oldprice` decimal(8,2) unsigned DEFAULT NULL,
  `maxdiscount` tinyint(3) unsigned DEFAULT NULL,
  `brand` smallint(5) unsigned DEFAULT NULL,
  `currensy` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `description` text,
  PRIMARY KEY (`itemid`),
  KEY `itemcategoryid` (`itemcategoryid`),
  KEY `itemsubcategoryid` (`itemsubcategoryid`),
  KEY `currensy` (`currensy`),
  KEY `brand` (`brand`),
  CONSTRAINT `FK_items2_brands` FOREIGN KEY (`brand`) REFERENCES `brands` (`brandid`),
  CONSTRAINT `FK_items2_category` FOREIGN KEY (`itemcategoryid`) REFERENCES `category` (`categoryid`),
  CONSTRAINT `FK_items2_currensy` FOREIGN KEY (`currensy`) REFERENCES `currensy` (`currensyid`),
  CONSTRAINT `FK_items2_subcategory` FOREIGN KEY (`itemsubcategoryid`) REFERENCES `subcategory` (`subcategoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='Here you can found all items';

# Dumping data for table shop.items: ~28 rows (approximately)
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` (`itemid`, `itemcategoryid`, `itemsubcategoryid`, `itemname`, `quantity`, `newprice`, `oldprice`, `maxdiscount`, `brand`, `currensy`, `description`) VALUES
	(1, 2, 3, 'HP LP3065', 4, 117.00, 2342.00, NULL, 9, 1, 'Stop your co-workers in their tracks with the stunning new 30-inch diagonal HP LP3065 Flat Panel Monitor. This flagship monitor features best-in-class performance and presentation features on a huge wide-aspect screen while letting you work as comfortably as possible - you might even forget you\'re at the office'),
	(2, 6, 10, 'HTC Touch HD', 2, 580.00, 2345.00, NULL, 4, 1, 'HTC Touch - in High Definition. Watch music videos and streaming content in awe-inspiring high definition clarity for a mobile experience you never thought possible. Seductively sleek, the HTC Touch HD provides the next generation of mobile functionality, all at a simple touch. Fully integrated with Windows Mobile Professional 6.1, ultrafast 3.5G, GPS, 5MP camera, plus lots more - all delivered on a breathtakingly crisp 3.8" WVGA touchscreen - you can take control of your mobile world with the HTC Touch HD.'),
	(3, 8, 13, 'iPod Classic', 3, 120.00, 322.00, NULL, 1, 1, 'More room to move.'),
	(4, 6, 10, 'Palm Treo Pro', 8, 324.00, 2123.00, NULL, 26, 1, 'Redefine your workday with the Palm Treo Pro smartphone. Perfectly balanced, you can respond to business and personal email, stay on top of appointments and contacts, and use Wi-Fi or GPS when you’re out and about. Then watch a video on YouTube, catch up with news and sports on the web, or listen to a few songs. Balance your work and play the way you like it, with the Palm Treo Pro.'),
	(5, 5, 11, 'Canon EOS 5D', 4, 1233.00, NULL, NULL, 27, 1, 'Canon\'s press material for the EOS 5D states that it \'defines (a) new D-SLR category\', while we\'re not typically too concerned with marketing talk this particular statement is clearly pretty accurate. The EOS 5D is unlike any previous digital SLR in that it combines a full-frame (35 mm sized) high resolution sensor (12.8 megapixels) with a relatively compact body (slightly larger than the EOS 20D, although in your hand it feels noticeably \'chunkier\'). The EOS 5D is aimed to slot in between the EOS 20D and the EOS-1D professional digital SLR\'s, an important difference when compared to the latter is that the EOS 5D doesn\'t have any environmental seals. While Canon don\'t specifically refer to the EOS 5D as a \'professional\' digital SLR it will have obvious appeal to professionals who want a high quality digital SLR in a body lighter than the EOS-1D. It will also no doubt appeal to current EOS 20D owners (although lets hope they\'ve not bought too many EF-S lenses...)'),
	(6, 3, 6, 'Samsung SyncMaster 941BW', 5, 230.00, NULL, NULL, 2, 1, 'Imagine the advantages of going big without slowing down. The big 19" 941BW monitor combines wide aspect ratio with fast pixel response time, for bigger images, more room to work and crisp motion. In addition, the exclusive MagicBright 2, MagicColor and MagicTune technologies help deliver the ideal image in every situation, while sleek, narrow bezels and adjustable stands deliver style just the way you want it. With the Samsung 941BW widescreen analog/digital LCD monitor, it\'s not hard to imagine.'),
	(7, 6, 10, 'iPhone', 7, 500.00, NULL, NULL, 1, 1, 'iPhone is a revolutionary new mobile phone that allows you to make a call by simply tapping a name or number in your address book, a favorites list, or a call log. It also automatically syncs all your contacts from a PC, Mac, or Internet service. And it lets you select and listen to voicemail messages in whatever order you want just like email.'),
	(8, 3, 6, 'Apple Cinema 30"', 2, 1200.00, NULL, NULL, 1, 1, 'The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed specifically for the creative professional, this display provides more space for easier access to all the tools and palettes needed to edit, format and composite your work. Combine this display with a Mac Pro, MacBook Pro, or PowerMac G5 and there\'s no limit to what you can achieve.'),
	(9, 2, 4, 'MacBook', 4, 800.00, NULL, NULL, 1, 1, 'Intel Core 2 Duo processor\r\n\r\nPowered by an Intel Core 2 Duo processor at speeds up to 2.16GHz, the new MacBook is the fastest ever.\r\n\r\n1GB memory, larger hard drives\r\n\r\nThe new MacBook now comes with 1GB of memory standard and larger hard drives for the entire line perfect for running more of your favorite applications and storing growing media collections.\r\n\r\nSleek, 1.08-inch-thin design\r\n\r\nMacBook makes it easy to hit the road thanks to its tough polycarbonate case, built-in wireless technologies, and innovative MagSafe Power Adapter that releases automatically if someone accidentally trips on the cord.\r\n\r\nBuilt-in iSight camera\r\n\r\nRight out of the box, you can have a video chat with friends or family,2 record a video at your desk, or take fun pictures with Photo Booth\r\n'),
	(10, 2, 3, 'MacBook Air', 2, 500.00, NULL, NULL, 1, 1, 'MacBook Air is ultrathin, ultraportable, and ultra unlike anything else. But you don’t lose inches and pounds overnight. It’s the result of rethinking conventions. Of multiple wireless innovations. And of breakthrough design. With MacBook Air, mobile computing suddenly has a new standard.'),
	(11, 2, 4, 'Sony VAIO', 5, 750.00, NULL, NULL, 13, 1, 'Unprecedented power. The next generation of processing technology has arrived. Built into the newest VAIO notebooks lies Intel\'s latest, most powerful innovation yet: Intel® Centrino® 2 processor technology. Boasting incredible speed, expanded wireless connectivity, enhanced multimedia support and greater energy efficiency, all the high-performance essentials are seamlessly combined into a single chip.'),
	(12, 4, 15, 'Samsung Galaxy Tab 10.1', 10, 650.00, NULL, NULL, 2, 1, 'Samsung Galaxy Tab 10.1, is the world’s thinnest tablet, measuring 8.6 mm thickness, running with Android 3.0 Honeycomb OS on a 1GHz dual-core Tegra 2 processor, similar to its younger brother Samsung Galaxy Tab 8.9.'),
	(13, 5, 14, 'Nikon D300', 1, 1200.00, NULL, NULL, 28, 1, 'Engineered with pro-level features and performance, the 12.3-effective-megapixel D300 combines brand new technologies with advanced features inherited from Nikon\'s newly announced D3 professional digital SLR camera to offer serious photographers remarkable performance combined with agility.'),
	(14, 8, 13, 'iPod Touch', 23, 90.00, 120.00, NULL, 1, 1, 'Revolutionary multi-touch interface.'),
	(15, 8, 13, 'iPod Shuffle', 2, 40.00, NULL, NULL, 1, 1, 'Born to be worn.\r\n\r\nClip on the worlds most wearable music player and take up to 240 songs with you anywhere. Choose from five colors including four new hues to make your musical fashion statement.\r\n\r\nRandom meets rhythm.\r\n\r\nWith iTunes autofill, iPod shuffle can deliver a new musical experience every time you sync. For more randomness, you can shuffle songs during playback with the slide of a switch.\r\nEverything is easy.\r\n\r\nCharge and sync with the included USB dock. Operate the iPod shuffle controls with one hand. Enjoy up to 12 hours straight of skip-free music playback.\r\n'),
	(16, 8, 13, 'iPod Nano', 3, 40.00, NULL, NULL, 1, 1, 'Video in your pocket.\r\n\r\nIts the small iPod with one very big idea: video. The worlds most popular music player now lets you enjoy movies, TV shows, and more on a two-inch display thats 65% brighter than before.\r\n\r\nCover Flow.\r\n\r\nBrowse through your music collection by flipping through album art. Select an album to turn it over and see the track list. \r\n\r\nEnhanced interface.\r\n\r\nExperience a whole new way to browse and view your music and video.\r\n\r\nSleek and colorful.\r\n\r\nWith an anodized aluminum and polished stainless steel enclosure and a choice of five colors, iPod nano is dressed to impress.\r\n\r\niTunes.\r\n\r\nAvailable as a free download, iTunes makes it easy to browse and buy millions of songs, movies, TV shows, audiobooks, and games and download free podcasts all at the iTunes Store. And you can import your own music, manage your whole media library, and sync your iPod or iPhone with ease.\r\n'),
	(17, 2, 4, 'MacBook Pro', 3, 1200.00, NULL, NULL, 1, 1, 'Macbook pro - Just Buy it! :) "by Solovej".'),
	(18, 1, 1, 'Compaq Presario', 3, 870.00, NULL, NULL, 9, 1, 'Good PC for home.'),
	(29, 2, 3, 'Dell XPS 15z XPS15z-72ELS', 8, 979.00, NULL, NULL, 22, 1, 'The thinnest 15-inch PC on the planet, the Dell XPS 15z (model XPS15z-72ELS) delivers the power you need while keeping things light (just 5-1/2 pounds) and easily portable. Housed in a luxurious, eye-catching, and elegantly crafted case that\'s less than an inch thick, it features a backlit keyboard with adjustable brightness. Rounded contours and precision-crafted lines give XPS 15z the illusion of floating just above every surface. It also offers a smooth-textured, comfort-designed palmrest and touchpad.'),
	(30, 2, 3, 'Acer Aspire TimelineX AS1830T-68U118', 4, 590.00, NULL, NULL, 10, 1, 'The TimelineX 1830T provides up to 8 hours of battery life thanks to a combination of Intel\'s Core processing technology and the LED-backlit display, which enables a 22.2 percent power savings compared with other notebook displays. You\'ll be able to remain productive as you work remotely from 9 to 5 without ever stopping to plug in and recharge, or keep yourself entertained throughout an entire coast-to-coast flight without worrying whether you\'ll make it to the end of your movie.'),
	(31, 2, 3, 'Alienware M14x AM14X-6557STB', 7, 1450.00, NULL, NULL, 29, 1, 'Take control of your gaming with the Alienware M14X multimedia laptop (model AM14X-6557STB), which features a thermally optimized case design with aggressive lines and an in-your-face attitude. It features a stunning, high-definition 14-inch display and a powerful, second-generation Intel Core i5 processor. Additionally, it offers ultra-fast DDR3 system memory and dual graphics capabilities, allowing you to save on battery life with the integrated Intel HD Graphics 3000 or ramp up your gaming with the NVIDIA GeForce GT 555M with 1.5 GB of discrete memory. Taken together, this combination of high-performance technologies allow you to rip through the latest 3D games at lightning-fast frame-rates.'),
	(32, 2, 3, 'ASUS G74SX-XA1', 4, 1499.00, NULL, NULL, 20, 1, 'The world of portable gaming has a new reigning king. The Republic of Gamers G74SX-XA1 is a performance notebook that imposes its will with the combined power of a second generation Intel® Core™ i7-2630QM CPU and NVIDIA® GTX 560M GPU with 3GB of GDDR5 VRAM. A score of P2008 in 3DMark11 and P9180 in 3DMark Vantage takes over the reins as the fastest notebook in the land. Support for DirectX®11 ensures that you\'ll not only have the fastest rig in town, but also the ability to play games as they were meant to be seen for a long time.'),
	(33, 7, 17, 'Microsoft Windows 7 Home Premium', 5, 190.00, NULL, NULL, 30, 1, 'Windows 7 Home Premium makes it easy to create a home network and share all of your favorite photos, videos, and music. You can even watch, pause, rewind, and record TV (a broadcast TV tuner may be required). Get the best entertainment experience with Windows 7 Home Premium. Do you use your PC for work, run Windows XP programs, or require enhanced security? Consider Windows 7 Professional.'),
	(34, 7, 17, 'Ubuntu Linux Complete Edition 8.04', 4, 12.00, NULL, NULL, 31, 1, 'Ubuntu gives users an operating system that is perfect for laptops and desktops and allows users to surf the web, read email, create documents and spreadsheets, edit images and much more. Take your old computer and give it a new life with Ubuntu. There\'s so much to like about Ubuntu, it\'s hard to know where to begin. I\'ve now got two Linux machines that are purring along and doing exactly what they should without throwing me any curveballs. Getting Started Technical Support: 60 days of unlimited customer support. '),
	(35, 7, 17, 'Mac OS X version 10.6.3 Snow Leopard', 4, 90.00, NULL, NULL, 1, 1, 'Mac OS X Snow Leopard is an even more powerful and refined version of the world’s most advanced operating system. In ways big and small, it gets faster, more reliable, and easier to use. New core technologies unleash the power of today’s advanced hardware technology and prepare Mac OS X for future innovation. And Snow Leopard includes built-in support for the latest version of Microsoft Exchange Server, so you can use your Mac at home and at work. '),
	(36, 7, 17, 'Red Hat Linux 9.0 Personal', 2, 300.00, NULL, NULL, 31, 1, 'Red Hat Linux 9 combines the latest Linux technology from the Open Source community in one easy to use operating system. No other operating system offers so much control in an easy to use package. Combining the latest Red Hat Linux technology and stunning Bluecurve interface, Red Hat Linux 9 is the ideal OS for home computing and technology enthusiasts.'),
	(37, 7, 17, 'Microsoft Windows XP Home Edition Upgrade', 1, 70.00, NULL, NULL, 30, 1, 'Packed with multimedia features, Windows XP Home Edition aims to unlock the full potential of your personal computer. It also looks great, with rounded window corners, larger and more detailed icons, and a clean-look desktop.'),
	(38, 7, 18, 'Adobe Acrobat Professional 9 [OLD VERSION]', 2, 230.00, NULL, NULL, 32, 1, 'dobe Dynamic PDF technology enables you to connect, interact, and engage in powerful new ways.  Streamline how your team works, collaborates, and creates high-impace communications--all with the reliability, visual fidelity, and control you expect from Adobe.  Designed to meet the needs of today\'s businesses, Adobe Dynamic PDF helps your team get more done--easier, faster, better.');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;


# Dumping structure for table shop.itemsindex
CREATE TABLE IF NOT EXISTS `itemsindex` (
  `indexitemid` mediumint(9) unsigned NOT NULL,
  KEY `itemsindx => items` (`indexitemid`),
  CONSTRAINT `itemsindx => items` FOREIGN KEY (`indexitemid`) REFERENCES `items` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='first index page items';

# Dumping data for table shop.itemsindex: ~6 rows (approximately)
/*!40000 ALTER TABLE `itemsindex` DISABLE KEYS */;
INSERT INTO `itemsindex` (`indexitemid`) VALUES
	(5),
	(6),
	(7),
	(8),
	(10),
	(13);
/*!40000 ALTER TABLE `itemsindex` ENABLE KEYS */;


# Dumping structure for table shop.items_fulltext
CREATE TABLE IF NOT EXISTS `items_fulltext` (
  `itemid` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `itemname` varchar(50) NOT NULL,
  `description` text,
  PRIMARY KEY (`itemid`),
  FULLTEXT KEY `itemname_description` (`itemname`,`description`),
  FULLTEXT KEY `itemname` (`itemname`),
  FULLTEXT KEY `description` (`description`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Here you can found all items';

# Dumping data for table shop.items_fulltext: 18 rows
/*!40000 ALTER TABLE `items_fulltext` DISABLE KEYS */;
INSERT INTO `items_fulltext` (`itemid`, `itemname`, `description`) VALUES
	(1, 'HP LP3065', 'Stop your co-workers in their tracks with the stunning new 30-inch diagonal HP LP3065 Flat Panel Monitor. This flagship monitor features best-in-class performance and presentation features on a huge wide-aspect screen while letting you work as comfortably as possible - you might even forget you\'re at the office'),
	(2, 'HTC Touch HD', 'HTC Touch - in High Definition. Watch music videos and streaming content in awe-inspiring high definition clarity for a mobile experience you never thought possible. Seductively sleek, the HTC Touch HD provides the next generation of mobile functionality, all at a simple touch. Fully integrated with Windows Mobile Professional 6.1, ultrafast 3.5G, GPS, 5MP camera, plus lots more - all delivered on a breathtakingly crisp 3.8" WVGA touchscreen - you can take control of your mobile world with the HTC Touch HD.\r\n\r\nFeatures\r\n\r\n    Processor Qualcomm® MSM 7201A™ 528 MHz\r\n    Windows Mobile® 6.1 Professional Operating System\r\n    Memory: 512 MB ROM, 288 MB RAM\r\n    Dimensions: 115 mm x 62.8 mm x 12 mm / 146.4 grams\r\n    3.8-inch TFT-LCD flat touch-sensitive screen with 480 x 800 WVGA resolution\r\n    HSDPA/WCDMA: Europe/Asia: 900/2100 MHz; Up to 2 Mbps up-link and 7.2 Mbps down-link speeds\r\n    Quad-band GSM/GPRS/EDGE: Europe/Asia: 850/900/1800/1900 MHz (Band frequency, HSUPA availability, and data speed are operator dependent.)\r\n    Device Control via HTC TouchFLO™ 3D & Touch-sensitive front panel buttons\r\n    GPS and A-GPS ready\r\n    Bluetooth® 2.0 with Enhanced Data Rate and A2DP for wireless stereo headsets\r\n    Wi-Fi®: IEEE 802.11 b/g\r\n    HTC ExtUSB™ (11-pin mini-USB 2.0)\r\n    5 megapixel color camera with auto focus\r\n    VGA CMOS color camera\r\n    Built-in 3.5 mm audio jack, microphone, speaker, and FM radio\r\n    Ring tone formats: AAC, AAC+, eAAC+, AMR-NB, AMR-WB, QCP, MP3, WMA, WAV\r\n    40 polyphonic and standard MIDI format 0 and 1 (SMF)/SP MIDI\r\n    Rechargeable Lithium-ion or Lithium-ion polymer 1350 mAh battery\r\n    Expansion Slot: microSD™ memory card (SD 2.0 compatible)\r\n    AC Adapter Voltage range/frequency: 100 ~ 240V AC, 50/60 Hz DC output: 5V and 1A\r\n    Special Features: FM Radio, G-Sensor\r\n\r\n'),
	(3, 'iPod Classic', 'More room to move.\r\n\r\nWith 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.\r\n\r\nCover Flow.\r\n\r\nBrowse through your music collection by flipping through album art. Select an album to turn it over and see the track list.\r\n\r\nEnhanced interface.\r\n\r\nExperience a whole new way to browse and view your music and video.\r\n\r\nSleeker design.\r\n\r\nBeautiful, durable, and sleeker than ever, iPod classic now features an anodized aluminum and polished stainless steel enclosure with rounded edges.\r\n'),
	(4, 'Palm Treo Pro', 'Redefine your workday with the Palm Treo Pro smartphone. Perfectly balanced, you can respond to business and personal email, stay on top of appointments and contacts, and use Wi-Fi or GPS when you’re out and about. Then watch a video on YouTube, catch up with news and sports on the web, or listen to a few songs. Balance your work and play the way you like it, with the Palm Treo Pro.\r\n\r\nFeatures\r\n\r\n    Windows Mobile® 6.1 Professional Edition\r\n    Qualcomm® MSM7201 400MHz Processor\r\n    320x320 transflective colour TFT touchscreen\r\n    HSDPA/UMTS/EDGE/GPRS/GSM radio\r\n    Tri-band UMTS — 850MHz, 1900MHz, 2100MHz\r\n    Quad-band GSM — 850/900/1800/1900\r\n    802.11b/g with WPA, WPA2, and 801.1x authentication\r\n    Built-in GPS\r\n    Bluetooth Version: 2.0 + Enhanced Data Rate\r\n    256MB storage (100MB user available), 128MB RAM\r\n    2.0 megapixel camera, up to 8x digital zoom and video capture\r\n    Removable, rechargeable 1500mAh lithium-ion battery\r\n    Up to 5.0 hours talk time and up to 250 hours standby\r\n    MicroSDHC card expansion (up to 32GB supported)\r\n    MicroUSB 2.0 for synchronization and charging\r\n    3.5mm stereo headset jack\r\n    60mm (W) x 114mm (L) x 13.5mm (D) / 133g\r\n\r\n'),
	(5, 'Canon EOS 5D', 'Canon\'s press material for the EOS 5D states that it \'defines (a) new D-SLR category\', while we\'re not typically too concerned with marketing talk this particular statement is clearly pretty accurate. The EOS 5D is unlike any previous digital SLR in that it combines a full-frame (35 mm sized) high resolution sensor (12.8 megapixels) with a relatively compact body (slightly larger than the EOS 20D, although in your hand it feels noticeably \'chunkier\'). The EOS 5D is aimed to slot in between the EOS 20D and the EOS-1D professional digital SLR\'s, an important difference when compared to the latter is that the EOS 5D doesn\'t have any environmental seals. While Canon don\'t specifically refer to the EOS 5D as a \'professional\' digital SLR it will have obvious appeal to professionals who want a high quality digital SLR in a body lighter than the EOS-1D. It will also no doubt appeal to current EOS 20D owners (although lets hope they\'ve not bought too many EF-S lenses...)'),
	(6, 'Samsung SyncMaster 941BW', 'Imagine the advantages of going big without slowing down. The big 19" 941BW monitor combines wide aspect ratio with fast pixel response time, for bigger images, more room to work and crisp motion. In addition, the exclusive MagicBright 2, MagicColor and MagicTune technologies help deliver the ideal image in every situation, while sleek, narrow bezels and adjustable stands deliver style just the way you want it. With the Samsung 941BW widescreen analog/digital LCD monitor, it\'s not hard to imagine.'),
	(7, 'iPhone', 'iPhone is a revolutionary new mobile phone that allows you to make a call by simply tapping a name or number in your address book, a favorites list, or a call log. It also automatically syncs all your contacts from a PC, Mac, or Internet service. And it lets you select and listen to voicemail messages in whatever order you want just like email.'),
	(8, 'Apple Cinema 30"', 'The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed specifically for the creative professional, this display provides more space for easier access to all the tools and palettes needed to edit, format and composite your work. Combine this display with a Mac Pro, MacBook Pro, or PowerMac G5 and there\'s no limit to what you can achieve.\r\n\r\nThe Cinema HD features an active-matrix liquid crystal display that produces flicker-free images that deliver twice the brightness, twice the sharpness and twice the contrast ratio of a typical CRT display. Unlike other flat panels, it\'s designed with a pure digital interface to deliver distortion-free images that never need adjusting. With over 4 million digital pixels, the display is uniquely suited for scientific and technical applications such as visualizing molecular structures or analyzing geological data.\r\n\r\nOffering accurate, brilliant color performance, the Cinema HD delivers up to 16.7 million colors across a wide gamut allowing you to see subtle nuances between colors from soft pastels to rich jewel tones. A wide viewing angle ensures uniform color from edge to edge. Apple\'s ColorSync technology allows you to create custom profiles to maintain consistent color onscreen and in print. The result: You can confidently use this display in all your color-critical applications.\r\n\r\nHoused in a new aluminum design, the display has a very thin bezel that enhances visual accuracy. Each display features two FireWire 400 ports and two USB 2.0 ports, making attachment of desktop peripherals, such as iSight, iPod, digital and still cameras, hard drives, printers and scanners, even more accessible and convenient. Taking advantage of the much thinner and lighter footprint of an LCD, the new displays support the VESA (Video Electronics Standards Association) mounting interface standard. Customers with the optional Cinema Display VESA Mount Adapter kit gain the flexibility to mount their display in locations most appropriate for their work environment.\r\n\r\nThe Cinema HD features a single cable design with elegant breakout for the USB 2.0, FireWire 400 and a pure digital connection using the industry standard Digital Video Interface (DVI) interface. The DVI connection allows for a direct pure-digital connection.\r\nFeatures:\r\n\r\nUnrivaled display performance\r\n\r\n    30-inch (viewable) active-matrix liquid crystal display provides breathtaking image quality and vivid, richly saturated color.\r\n    Support for 2560-by-1600 pixel resolution for display of high definition still and video imagery.\r\n    Wide-format design for simultaneous display of two full pages of text and graphics.\r\n    Industry standard DVI connector for direct attachment to Mac- and Windows-based desktops and notebooks\r\n    Incredibly wide (170 degree) horizontal and vertical viewing angle for maximum visibility and color performance.\r\n    Lightning-fast pixel response for full-motion digital video playback.\r\n    Support for 16.7 million saturated colors, for use in all graphics-intensive applications.\r\n\r\nSimple setup and operation\r\n\r\n    Single cable with elegant breakout for connection to DVI, USB and FireWire ports\r\n    Built-in two-port USB 2.0 hub for easy connection of desktop peripheral devices.\r\n    Two FireWire 400 ports to support iSight and other desktop peripherals\r\n\r\nSleek, elegant design\r\n\r\n    Huge virtual workspace, very small footprint.\r\n    Narrow Bezel design to minimize visual impact of using dual displays\r\n    Unique hinge design for effortless adjustment\r\n    Support for VESA mounting solutions (Apple Cinema Display VESA Mount Adapter sold separately)\r\n\r\nTechnical specifications\r\n\r\nScreen size (diagonal viewable image size)\r\n\r\n    Apple Cinema HD Display: 30 inches (29.7-inch viewable)\r\n\r\nScreen type\r\n\r\n    Thin film transistor (TFT) active-matrix liquid crystal display (AMLCD)\r\n\r\nResolutions\r\n\r\n    2560 x 1600 pixels (optimum resolution)\r\n    2048 x 1280\r\n    1920 x 1200\r\n    1280 x 800\r\n    1024 x 640\r\n\r\nDisplay colors (maximum)\r\n\r\n    16.7 million\r\n\r\nViewing angle (typical)\r\n\r\n    170° horizontal; 170° vertical\r\n\r\nBrightness (typical)\r\n\r\n    30-inch Cinema HD Display: 400 cd/m2\r\n\r\nContrast ratio (typical)\r\n\r\n    700:1\r\n\r\nResponse time (typical)\r\n\r\n    16 ms\r\n\r\nPixel pitch\r\n\r\n    30-inch Cinema HD Display: 0.250 mm\r\n\r\nScreen treatment\r\n\r\n    Antiglare hardcoat\r\n\r\nUser controls (hardware and software)\r\n\r\n    Display Power,\r\n    System sleep, wake\r\n    Brightness\r\n    Monitor tilt\r\n\r\nConnectors and cables\r\nCable\r\n\r\n    DVI (Digital Visual Interface)\r\n    FireWire 400\r\n    USB 2.0\r\n    DC power (24 V)\r\n\r\nConnectors\r\n\r\n    Two-port, self-powered USB 2.0 hub\r\n    Two FireWire 400 ports\r\n    Kensington security port\r\n\r\nVESA mount adapter\r\nRequires optional Cinema Display VESA Mount Adapter (M9649G/A)\r\n\r\n    Compatible with VESA FDMI (MIS-D, 100, C) compliant mounting solutions\r\n\r\nElectrical requirements\r\n\r\n    Input voltage: 100-240 VAC 50-60Hz\r\n    Maximum power when operating: 150W\r\n    Energy saver mode: 3W or less\r\n\r\nEnvironmental requirements\r\n\r\n    Operating temperature: 50° to 95° F (10° to 35° C)\r\n    Storage temperature: -40° to 116° F (-40° to 47° C)\r\n    Operating humidity: 20% to 80% noncondensing\r\n    Maximum operating altitude: 10,000 feet\r\n\r\nAgency approvals\r\n\r\n    FCC Part 15 Class B\r\n    EN55022 Class B\r\n    EN55024\r\n    VCCI Class B\r\n    AS/NZS 3548 Class B\r\n    CNS 13438 Class B\r\n    ICES-003 Class B\r\n    ISO 13406 part 2\r\n    MPR II\r\n    IEC 60950\r\n    UL 60950\r\n    CSA 60950\r\n    EN60950\r\n    ENERGY STAR\r\n    TCO \'03\r\n\r\nSize and weight\r\n30-inch Apple Cinema HD Display\r\n\r\n    Height: 21.3 inches (54.3 cm)\r\n    Width: 27.2 inches (68.8 cm)\r\n    Depth: 8.46 inches (21.5 cm)\r\n    Weight: 27.5 pounds (12.5 kg)\r\n\r\nSystem Requirements\r\n\r\n    Mac Pro, all graphic options\r\n    MacBook Pro\r\n    Power Mac G5 (PCI-X) with ATI Radeon 9650 or better or NVIDIA GeForce 6800 GT DDL or better\r\n    Power Mac G5 (PCI Express), all graphics options\r\n    PowerBook G4 with dual-link DVI support\r\n    Windows PC and graphics card that supports DVI ports with dual-link digital bandwidth and VESA DDC standard for plug-and-play setup\r\n\r\n'),
	(9, 'MacBook', 'Intel Core 2 Duo processor\r\n\r\nPowered by an Intel Core 2 Duo processor at speeds up to 2.16GHz, the new MacBook is the fastest ever.\r\n\r\n1GB memory, larger hard drives\r\n\r\nThe new MacBook now comes with 1GB of memory standard and larger hard drives for the entire line perfect for running more of your favorite applications and storing growing media collections.\r\n\r\nSleek, 1.08-inch-thin design\r\n\r\nMacBook makes it easy to hit the road thanks to its tough polycarbonate case, built-in wireless technologies, and innovative MagSafe Power Adapter that releases automatically if someone accidentally trips on the cord.\r\n\r\nBuilt-in iSight camera\r\n\r\nRight out of the box, you can have a video chat with friends or family,2 record a video at your desk, or take fun pictures with Photo Booth\r\n'),
	(10, 'MacBook Air', 'MacBook Air is ultrathin, ultraportable, and ultra unlike anything else. But you don’t lose inches and pounds overnight. It’s the result of rethinking conventions. Of multiple wireless innovations. And of breakthrough design. With MacBook Air, mobile computing suddenly has a new standard.'),
	(11, 'Sony VAIO', 'Unprecedented power. The next generation of processing technology has arrived. Built into the newest VAIO notebooks lies Intel\'s latest, most powerful innovation yet: Intel® Centrino® 2 processor technology. Boasting incredible speed, expanded wireless connectivity, enhanced multimedia support and greater energy efficiency, all the high-performance essentials are seamlessly combined into a single chip.'),
	(12, 'Samsung Galaxy Tab 10.1', 'Samsung Galaxy Tab 10.1, is the world’s thinnest tablet, measuring 8.6 mm thickness, running with Android 3.0 Honeycomb OS on a 1GHz dual-core Tegra 2 processor, similar to its younger brother Samsung Galaxy Tab 8.9.\r\n\r\nSamsung Galaxy Tab 10.1 gives pure Android 3.0 experience, adding its new TouchWiz UX or TouchWiz 4.0 – includes a live panel, which lets you to customize with different content, such as your pictures, bookmarks, and social feeds, sporting a 10.1 inches WXGA capacitive touch screen with 1280 x 800 pixels of resolution, equipped with 3 megapixel rear camera with LED flash and a 2 megapixel front camera, HSPA+ connectivity up to 21Mbps, 720p HD video recording capability, 1080p HD playback, DLNA support, Bluetooth 2.1, USB 2.0, gyroscope, Wi-Fi 802.11 a/b/g/n, micro-SD slot, 3.5mm headphone jack, and SIM slot, including the Samsung Stick – a Bluetooth microphone that can be carried in a pocket like a pen and sound dock with powered subwoofer.\r\n\r\nSamsung Galaxy Tab 10.1 will come in 16GB / 32GB / 64GB verities and pre-loaded with Social Hub, Reader’s Hub, Music Hub and Samsung Mini Apps Tray – which gives you access to more commonly used apps to help ease multitasking and it is capable of Adobe Flash Player 10.2, powered by 6860mAh battery that gives you 10hours of video-playback time.'),
	(13, 'Nikon D300', 'Engineered with pro-level features and performance, the 12.3-effective-megapixel D300 combines brand new technologies with advanced features inherited from Nikon\'s newly announced D3 professional digital SLR camera to offer serious photographers remarkable performance combined with agility.\r\n\r\nSimilar to the D3, the D300 features Nikon\'s exclusive EXPEED Image Processing System that is central to driving the speed and processing power needed for many of the camera\'s new features. The D300 features a new 51-point autofocus system with Nikon\'s 3D Focus Tracking feature and two new LiveView shooting modes that allow users to frame a photograph using the camera\'s high-resolution LCD monitor. The D300 shares a similar Scene Recognition System as is found in the D3; it promises to greatly enhance the accuracy of autofocus, autoexposure, and auto white balance by recognizing the subject or scene being photographed and applying this information to the calculations for the three functions.\r\n\r\nThe D300 reacts with lightning speed, powering up in a mere 0.13 seconds and shooting with an imperceptible 45-millisecond shutter release lag time. The D300 is capable of shooting at a rapid six frames per second and can go as fast as eight frames per second when using the optional MB-D10 multi-power battery pack. In continuous bursts, the D300 can shoot up to 100 shots at full 12.3-megapixel resolution. (NORMAL-LARGE image setting, using a SanDisk Extreme IV 1GB CompactFlash card.)\r\n\r\nThe D300 incorporates a range of innovative technologies and features that will significantly improve the accuracy, control, and performance photographers can get from their equipment. Its new Scene Recognition System advances the use of Nikon\'s acclaimed 1,005-segment sensor to recognize colors and light patterns that help the camera determine the subject and the type of scene being photographed before a picture is taken. This information is used to improve the accuracy of autofocus, autoexposure, and auto white balance functions in the D300. For example, the camera can track moving subjects better and by identifying them, it can also automatically select focus points faster and with greater accuracy. It can also analyze highlights and more accurately determine exposure, as well as infer light sources to deliver more accurate white balance detection.'),
	(14, 'iPod Touch', 'Revolutionary multi-touch interface.\r\niPod touch features the same multi-touch screen technology as iPhone. Pinch to zoom in on a photo. Scroll through your songs and videos with a flick. Flip through your library by album artwork with Cover Flow.\r\n\r\nGorgeous 3.5-inch widescreen display.\r\nWatch your movies, TV shows, and photos come alive with bright, vivid color on the 320-by-480-pixel display.\r\n\r\nMusic downloads straight from iTunes.\r\nShop the iTunes Wi-Fi Music Store from anywhere with Wi-Fi.1 Browse or search to find the music youre looking for, preview it, and buy it with just a tap.\r\n\r\nSurf the web with Wi-Fi.\r\nBrowse the web using Safari and watch YouTube videos on the first iPod with Wi-Fi built in'),
	(15, 'iPod Shuffle', 'Born to be worn.\r\n\r\nClip on the worlds most wearable music player and take up to 240 songs with you anywhere. Choose from five colors including four new hues to make your musical fashion statement.\r\n\r\nRandom meets rhythm.\r\n\r\nWith iTunes autofill, iPod shuffle can deliver a new musical experience every time you sync. For more randomness, you can shuffle songs during playback with the slide of a switch.\r\nEverything is easy.\r\n\r\nCharge and sync with the included USB dock. Operate the iPod shuffle controls with one hand. Enjoy up to 12 hours straight of skip-free music playback.\r\n'),
	(16, 'iPod Nano', 'Video in your pocket.\r\n\r\nIts the small iPod with one very big idea: video. The worlds most popular music player now lets you enjoy movies, TV shows, and more on a two-inch display thats 65% brighter than before.\r\n\r\nCover Flow.\r\n\r\nBrowse through your music collection by flipping through album art. Select an album to turn it over and see the track list. \r\n\r\nEnhanced interface.\r\n\r\nExperience a whole new way to browse and view your music and video.\r\n\r\nSleek and colorful.\r\n\r\nWith an anodized aluminum and polished stainless steel enclosure and a choice of five colors, iPod nano is dressed to impress.\r\n\r\niTunes.\r\n\r\nAvailable as a free download, iTunes makes it easy to browse and buy millions of songs, movies, TV shows, audiobooks, and games and download free podcasts all at the iTunes Store. And you can import your own music, manage your whole media library, and sync your iPod or iPhone with ease.\r\n'),
	(17, 'MacBook Pro', 'Macbook pro - Just Buy it! :) "by Solovej".'),
	(18, 'Compaq Presario', 'Good PC for home.');
/*!40000 ALTER TABLE `items_fulltext` ENABLE KEYS */;


# Dumping structure for table shop.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `orderid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(9) unsigned NOT NULL,
  `itemid` mediumint(9) unsigned NOT NULL,
  `quantity` tinyint(3) unsigned NOT NULL,
  `price` smallint(6) unsigned NOT NULL,
  `currency` tinyint(1) unsigned NOT NULL,
  `paid` varchar(3) DEFAULT NULL,
  `orderdatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Here you can found orders from users';

# Dumping data for table shop.orders: ~0 rows (approximately)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;


# Dumping structure for table shop.paid
CREATE TABLE IF NOT EXISTS `paid` (
  `paidid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderid` int(10) unsigned NOT NULL,
  `paid_yes_or_not` varchar(3) NOT NULL,
  PRIMARY KEY (`paidid`),
  KEY `paid => orders` (`orderid`),
  CONSTRAINT `paid => orders` FOREIGN KEY (`orderid`) REFERENCES `orders` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Here you can found information about users payment for order';

# Dumping data for table shop.paid: ~0 rows (approximately)
/*!40000 ALTER TABLE `paid` DISABLE KEYS */;
/*!40000 ALTER TABLE `paid` ENABLE KEYS */;


# Dumping structure for table shop.photo
CREATE TABLE IF NOT EXISTS `photo` (
  `photoitemid` mediumint(9) unsigned NOT NULL,
  `thumbnail` varchar(50) DEFAULT NULL,
  `photo1` varchar(50) DEFAULT NULL,
  `photo2` varchar(50) DEFAULT NULL,
  `photo3` varchar(50) DEFAULT NULL,
  `photo4` varchar(50) DEFAULT NULL,
  `photo5` varchar(50) DEFAULT NULL,
  `photo6` varchar(50) DEFAULT NULL,
  `photo7` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`photoitemid`),
  CONSTRAINT `photo => items` FOREIGN KEY (`photoitemid`) REFERENCES `items` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Items photos';

# Dumping data for table shop.photo: ~28 rows (approximately)
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` (`photoitemid`, `thumbnail`, `photo1`, `photo2`, `photo3`, `photo4`, `photo5`, `photo6`, `photo7`) VALUES
	(1, 'hp_1-80x80.jpg', 'hp_1-228x228.jpg', 'hp_3.jpg', 'hp_3.jpg', NULL, NULL, NULL, NULL),
	(2, 'htc_touch_hd_1-80x80.jpg', 'htc_touch_hd_1-228x228.jpg', 'htc_touch_hd_2.jpg', 'htc_touch_hd_3.jpg', NULL, NULL, NULL, NULL),
	(3, 'ipod_classic_1-90x90.jpg', 'ipod_classic_1-228x228.jpg', 'ipod_classic_2.jpg', 'ipod_classic_3.jpg', 'ipod_classic_4.jpg', NULL, NULL, NULL),
	(4, 'palm_treo_pro_1-80x80.jpg', 'palm_treo_pro_1-228x228.jpg', 'palm_treo_pro_2.jpg', 'palm_treo_pro_3.jpg', NULL, NULL, NULL, NULL),
	(5, 'canon_eos_5d_1-80x80.jpg', 'canon_eos_5d_1-228x228.jpg', 'canon_eos_5d_2.jpg', 'canon_eos_5d_3.jpg', NULL, NULL, NULL, NULL),
	(6, 'samsung_syncmaster_941bw-80x80.jpg', 'samsung_syncmaster_941bw-228x228.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(7, 'iphone_1-80x80.jpg', 'iphone_1-228x228.jpg', 'iphone_2.jpg', 'iphone_3.jpg', 'iphone_4.jpg', 'iphone_5.jpg', 'iphone_6.jpg', NULL),
	(8, 'apple_cinema_30-80x80.jpg', 'apple_cinema_30-228x228.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(9, 'macbook_1-80x80.jpg', 'macbook_1-228x228.jpg', 'macbook_2.jpg', 'macbook_3.jpg', 'macbook_4.jpg', 'macbook_5.jpg', NULL, NULL),
	(10, 'macbook_air_1-80x80.jpg', 'macbook_air_1-228x228.jpg', 'macbook_air_2.jpg', 'macbook_air_3.jpg', 'macbook_air_4.jpg', NULL, NULL, NULL),
	(11, 'sony_vaio_1-80x80.jpg', 'sony_vaio_1-228x228.jpg', 'sony_vaio_2.jpg', 'sony_vaio_3.jpg', 'sony_vaio_4.jpg', 'sony_vaio_5.jpg', NULL, NULL),
	(12, 'samsung_tab_1-80x80.jpg', 'samsung_tab_1-228x228.jpg', 'samsung_tab_2.jpg', 'samsung_tab_3.jpg', 'samsung_tab_4.jpg', 'samsung_tab_5.jpg', 'samsung_tab_6.jpg', 'samsung_tab_7.jpg'),
	(13, 'nikon_d300_1-80x80.jpg', 'nikon_d300_1-228x228.jpg', 'nikon_d300_2.jpg', 'nikon_d300_3.jpg', 'nikon_d300_4.jpg', 'nikon_d300_5.jpg', NULL, NULL),
	(14, 'ipod_touch_1-90x90.jpg', 'ipod_touch_1-228x228.jpg', 'ipod_touch_2.jpg', 'ipod_touch_3.jpg', 'ipod_touch_4.jpg', 'ipod_touch_5.jpg', 'ipod_touch_6.jpg', 'ipod_touch_7.jpg'),
	(15, 'ipod_shuffle_1-90x90.jpg', 'ipod_shuffle_1-228x228.jpg', 'ipod_shuffle_2.jpg', 'ipod_shuffle_3.jpg', 'ipod_shuffle_4.jpg', 'ipod_shuffle_5.jpg', NULL, NULL),
	(16, 'ipod_nano_1-90x90.jpg', 'ipod_nano_1-228x228.jpg', 'ipod_nano_2.jpg', 'ipod_nano_3.jpg', 'ipod_nano_4.jpg', 'ipod_nano_5.jpg', NULL, NULL),
	(17, 'macbook_pro_1-80x80.jpg', 'macbook_pro_1-80x80.jpg', 'macbook_pro_2.jpg', 'macbook_pro_3.jpg', 'macbook_pro_4.jpg', NULL, NULL, NULL),
	(18, 'compaq.jpg', 'compaq.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(29, 'dellmini80.jpg', 'dellmini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(30, 'acermini80.jpg', 'acermini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(31, 'alienmini80.jpg', 'alienmini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(32, 'asusmini80.jpg', 'asusmini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(33, 'windowsmini80.jpg', 'windowsmini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(34, 'ubutumini80.jpg', 'ubutumini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(35, 'Macosmini80.jpg', 'Macosmini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(36, 'redhatmini80.jpg', 'redhatmini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(37, 'windowsXPmini80.jpg', 'windowsXPmini.jpg', NULL, NULL, NULL, NULL, NULL, NULL),
	(38, 'adobemini80.jpg', 'adobemini.jpg', NULL, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;


# Dumping structure for table shop.sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL,
  `previous_id` varchar(40) NOT NULL,
  `user_agent` text NOT NULL,
  `ip_hash` char(32) NOT NULL DEFAULT '',
  `created` int(10) unsigned NOT NULL DEFAULT '0',
  `updated` int(10) unsigned NOT NULL DEFAULT '0',
  `payload` longtext NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `PREVIOUS` (`previous_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# Dumping data for table shop.sessions: ~5 rows (approximately)
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` (`session_id`, `previous_id`, `user_agent`, `ip_hash`, `created`, `updated`, `payload`) VALUES
	('2e7128688c0a0208bc988dbf6fed8f2e', '8ffa3449d6eaf4ed0e759688ee7619c3', 'Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2', '4869e012aa045958bdf5c461577cf02d', 1317204704, 1317204872, 'a:2:{i:0;a:0:{}i:1;a:0:{}}'),
	('913a40f82f900dbebb74c35d206c31bd', '913a40f82f900dbebb74c35d206c31bd', 'Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2', '4869e012aa045958bdf5c461577cf02d', 1317196488, 1317196497, 'a:2:{i:0;a:0:{}i:1;a:0:{}}'),
	('dbd2bb9f77736e4b17cc953a063efa44', 'a7922dfc27c46be242705c28d15f2422', 'Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2', '4869e012aa045958bdf5c461577cf02d', 1317197089, 1317197089, 'a:2:{i:0;a:0:{}i:1;a:0:{}}'),
	('eb7025123fb62ffd084fbb58568e06f8', 'eb7025123fb62ffd084fbb58568e06f8', 'Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2', '4869e012aa045958bdf5c461577cf02d', 1317196439, 1317196442, 'a:2:{i:0;a:0:{}i:1;a:0:{}}'),
	('edc27d6315c7888d4d1407aba9a13d13', 'edc27d6315c7888d4d1407aba9a13d13', 'Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2', '4869e012aa045958bdf5c461577cf02d', 1317202848, 1317202848, '');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;


# Dumping structure for table shop.simpleusers
CREATE TABLE IF NOT EXISTS `simpleusers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `group` int(11) unsigned NOT NULL DEFAULT '1',
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_login` varchar(25) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `login_hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `profile_fields` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# Dumping data for table shop.simpleusers: ~0 rows (approximately)
/*!40000 ALTER TABLE `simpleusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `simpleusers` ENABLE KEYS */;


# Dumping structure for table shop.subcategory
CREATE TABLE IF NOT EXISTS `subcategory` (
  `subcategoryid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `rootid` tinyint(3) unsigned NOT NULL,
  `subcategoryname` varchar(50) NOT NULL,
  `subcategoryurl` varchar(50) NOT NULL,
  PRIMARY KEY (`subcategoryid`),
  KEY `FK_subcategory_category` (`rootid`),
  CONSTRAINT `FK_subcategory_category` FOREIGN KEY (`rootid`) REFERENCES `category` (`categoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

# Dumping data for table shop.subcategory: ~18 rows (approximately)
/*!40000 ALTER TABLE `subcategory` DISABLE KEYS */;
INSERT INTO `subcategory` (`subcategoryid`, `rootid`, `subcategoryname`, `subcategoryurl`) VALUES
	(1, 1, 'Pc', 'pc'),
	(2, 1, 'Mac', 'mac'),
	(3, 2, 'Laptops', 'laptops'),
	(4, 2, 'Notebooks', 'notebooks'),
	(5, 3, 'Mice and Trackballs', 'mice_and_trackballs'),
	(6, 3, 'Monitors', 'monitors'),
	(7, 3, 'Printers', 'printers'),
	(8, 3, 'Scanners', 'scanners'),
	(9, 3, 'Web Cameras', 'web_cameras'),
	(10, 6, 'Mobile Phones', 'mobile_phones'),
	(11, 8, 'CD players', 'cd_players'),
	(12, 8, 'SD players', 'sd_players'),
	(13, 8, 'Flash players', 'flashe_players'),
	(14, 5, 'Digital cameras', 'digital_cameras'),
	(15, 4, 'Android Tablets', 'android_tablets'),
	(16, 4, 'IOS Tablets', 'ios_tablets'),
	(17, 4, 'OS', 'os'),
	(18, 4, 'Graphic Software', 'graphic_software');
/*!40000 ALTER TABLE `subcategory` ENABLE KEYS */;


# Dumping structure for table shop.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `profile_fields` text,
  `group` int(11) DEFAULT NULL,
  `last_login` int(20) DEFAULT NULL,
  `login_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

# Dumping data for table shop.users: ~1 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`, `email`, `profile_fields`, `group`, `last_login`, `login_hash`) VALUES
	(17, 'demo', 'LG5JF0hJxx4ahubqeMMkXBMc0+3JNc8iym/gY56nZBg=', 'demo@demo.de', 'a:0:{}', 100, NULL, NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


# Dumping structure for table shop.user_fullinfo
CREATE TABLE IF NOT EXISTS `user_fullinfo` (
  `userid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country` smallint(5) unsigned NOT NULL,
  `city` varchar(50) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `phonenumber` varchar(50) NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `user => country` (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Here you can found information about user: tel, adress';

# Dumping data for table shop.user_fullinfo: ~0 rows (approximately)
/*!40000 ALTER TABLE `user_fullinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_fullinfo` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
