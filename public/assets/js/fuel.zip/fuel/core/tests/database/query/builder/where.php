<?php
/**
 * Fuel is a fast, lightweight, community driven PHP5 framework.
 *
 * @package    Fuel
 * @version    1.0
 * @author     Fuel Development Team
 * @license    MIT License
 * @copyright  2010 - 2011 Fuel Development Team
 * @link       http://fuelphp.com
 */

namespace Fuel\Core;

/**
 * Database_Query_Builder_Where class tests
 * 
 * @group Core
 * @group Database
 */
class Test_Database_Query_Builder_Where extends TestCase {
 	public function test_foo() {}
}
