<?php
/**
 * Fuel is a fast, lightweight, community driven PHP5 framework.
 *
 * @package    Fuel
 * @version    1.0.1
 * @author     Solovej <bravosms@gmail.com>
 * @license    MIT License
 * @copyright  2010 - 2011 Fuel Development Team
 * @link       http://fuelphp.com
 */


Autoloader::add_core_namespace('Cartgo');

Autoloader::add_classes(array(
	'Cartgo\\Cart'						=> __DIR__.'/classes/cartgo.php',
	'Cartgo\\InvalidCartgoException'		=> __DIR__.'/classes/cartgo.php',
	'Cartgo\\InvalidCartgoItemException'	=> __DIR__.'/classes/cartgo.php',
	'Cartgo\\Cartgo_Item'					=> __DIR__.'/classes/cartgo/item.php',
	//'Cartgo\\Cartgo_Driver'					=> __DIR__.'/classes/cart/driver.php',
	//'Cartgo\\Cartgo_Auth'					=> __DIR__.'/classes/cart/auth.php',
	'Cartgo\\Cartgo_Cookie'					=> __DIR__.'/classes/cartgo/cookie.php',
	//'Cartgo\\Cartgo_Session'				=> __DIR__.'/classes/cartgo/session.php',
));