<?php
/**
 * Fuel is a fast, lightweight, community driven PHP5 framework.
 *
 * @package    Fuel
 * @version    1.0.1
 * @author     Solovej <bravosms@gmail.com>
 * @license    MIT License
 * @copyright  2010 - 2011 Fuel Development Team
 * @link       http://fuelphp.com
 */

namespace Cartgo;


/**
 * Exception for invalid cartgo instance retrieval.
 */
class InvalidCartgoException extends \Fuel_Exception {}

/**
 * Exception for invalid cartgo item insert.
 */
class InvalidCartgoItemException extends \Fuel_Exception {}

abstract class Cartgo{
    protected static $default = array();
	protected static $instances = array();
	protected static $instance = null;

    	/**
	 * Cart instance factory. Returns a new cart driver.
	 *
	 * @param	string	$cart	the cart identifier.
	 * @param	array	$config		aditional config array
	 * @return	object	new cart driver instance
	 */
    public static function factory($cartgo = 'default', $config = array())
    {

    }

	/**
	 * Resturns a cart driver instance.
	 *
	 * @param	string	$cart		the cart identifier.
	 * @param	array	$config		aditional config array
	 * @return	object	new cart driver instance
	 */
    public static function instance($cartgo = null, $config = array())
    {

    }
    /**
	 * Method passthrough for static usage.
	 */
    public static function __callStatic()
    {

    }
    /**
	 * Class init.
	 */
    public static function _init()
    {
        \Config::load('cartgo', TRUE);
       static::$default = \Config::get('cartgo.default');
    }
}
