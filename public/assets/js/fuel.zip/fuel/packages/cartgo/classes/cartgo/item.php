<?php

namespace Cartgo;

class Cartgo_Item
{
    protected $values = array();
    protected $options = array();
    protected $cartgo;
    protected $rowid;

    public function __construct(){}
    public function get_name(){}
    public function get_id(){}
    public function get_quantity(){}
    public function get_size(){}
    public function get_color(){}
    public function get_all_item_info(){}
    public function get_options(){}
    public function get_rowid(){}
    public function get_price(){}
    public function delete_item(){}
    public function update(){}
}