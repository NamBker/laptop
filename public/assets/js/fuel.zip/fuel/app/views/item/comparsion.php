<div id="content">  <div class="breadcrumb">
        <a href="home">Home</a>
         » <a href="compare">Product Comparison</a>
      </div>
  <h1>Product Comparison</h1>
    <table class="compare-info">
    <thead>
      <tr>
        <td colspan="3">Product Details</td>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Product</td>
                <td class="name"><a href="http://demo.opencart.com/index.php?route=product/product&amp;product_id=33">Samsung SyncMaster 941BW</a></td>
                <td class="name"><a href="http://demo.opencart.com/index.php?route=product/product&amp;product_id=42">Apple Cinema 30"</a></td>
              </tr>
      <tr>
        <td>Image</td>
                <td>          <img src="samsung_syncmaster_941bw-90x90.jpg" alt="Samsung SyncMaster 941BW">
          </td>
                <td>          <img src="apple_cinema_30-90x90.jpg" alt="Apple Cinema 30&quot;">
          </td>
              </tr>
      <tr>
        <td>Price</td>
                <td>                    $235.00                    </td>
                <td>                    <span class="price-old">$117.50</span> <span class="price-new">$105.75</span>
                    </td>
              </tr>
      <tr>
        <td>Model</td>
                <td>Product 6</td>
                <td>Product 15</td>
              </tr>
      <tr>
        <td>Brand</td>
                <td></td>
                <td>Apple</td>
              </tr>
      <tr>
        <td>Availability</td>
                <td>2 - 3 Days</td>
                <td>In Stock</td>
              </tr>
      <tr>
        <td>Rating</td>
                <td><img src="stars-0.png" alt="Based on 0 reviews."><br>
          Based on 0 reviews.</td>
                <td><img src="stars-0.png" alt="Based on 0 reviews."><br>
          Based on 0 reviews.</td>
              </tr>
      <tr>
        <td>Summary</td>
                <td class="description">
	Imagine the advantages of going big without slowing down. The big 19" 941BW monitor combines wide aspect ratio with fast pixel response time, for bigger images, more room to work and crisp mot..</td>
                <td class="description">
	The 30-inch Apple Cinema HD Display delivers an amazing 2560 x 1600 pixel resolution. Designed specifically for the creative professional, this display provides more space for easier access to all ..</td>
              </tr>
      <tr>
        <td>Weight</td>
                <td>5.00kg</td>
                <td>12.50lb</td>
              </tr>
      <tr>
        <td>Dimensions (L x W x H)</td>
                <td>0.00mm x 0.00mm x 0.00mm</td>
                <td>1.00mm x 2.00mm x 3.00mm</td>
              </tr>
    </tbody>
        <thead>
      <tr>
        <td colspan="3">Memory</td>
      </tr>
    </thead>
        <tbody>
      <tr>
        <td>test 2</td>
                        <td></td>
                                <td>rtgrf</td>
                      </tr>
    </tbody>
            <thead>
      <tr>
        <td colspan="3">Processor</td>
      </tr>
    </thead>
        <tbody>
      <tr>
        <td>Clockspeed</td>
                        <td></td>
                                <td>dffgrfgf</td>
                      </tr>
    </tbody>
            <tbody><tr>
      <td></td>
            <td><a onclick="addToCart('33');" class="button"><span>Add to Cart</span></a></td>
            <td><a onclick="addToCart('42');" class="button"><span>Add to Cart</span></a></td>
          </tr>
    <tr>
      <td></td>
            <td><form action="http://demo.opencart.com/index.php?route=product/compare" method="post" enctype="multipart/form-data">
          <input name="remove" value="33" type="hidden">
          <a class="button" onclick="$(this).parent().submit();"><span>Remove</span></a>
        </form></td>
            <td><form action="http://demo.opencart.com/index.php?route=product/compare" method="post" enctype="multipart/form-data">
          <input name="remove" value="42" type="hidden">
          <a class="button" onclick="$(this).parent().submit();"><span>Remove</span></a>
        </form></td>
          </tr>
  </tbody></table>
  <div class="buttons">
    <div class="right"><a href="http://demo.opencart.com/index.php?route=common/home" class="button"><span>Continue</span></a></div>
  </div>
    </div>