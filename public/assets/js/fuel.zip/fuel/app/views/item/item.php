<?php foreach($data as $data1 => $key):?>
<div id="content">  <div class="breadcrumb">
        <a href="home">Home</a>
          <?php echo isset($key['categoryname'])? ' » '. \Fuel\Core\Html::anchor('category/'.$key['categoryurl'],$key['categoryname']):'' ;?>
          <?php echo isset($key['subcategoryname'])? ' » '.\Fuel\Core\Html::anchor('category/'.$key['categoryurl'].'/'.$key['subcategoryurl'],$key['subcategoryname']):'' ;?>
      </div>

  <h1><?php echo $key['itemname'];?></h1>
  <div class="product-info">
        <div class="left">
            <div class="image">

                <?php echo \Fuel\Core\Html::anchor('',\Fuel\Core\Asset::img($key['photo1'],array('alt'=>$key['itemname'],'title'=>$key['itemname'])));?>

            </div>
                  <div class="image-additional">

              </div>
          </div>
        <div class="right">
      <div class="description">
                <span>Brand:</span> <a href="#"><?php echo $key['brandname'];?></a><br>
                <span>Product Code:</span> <?php echo $key['itemid'];?><br>
        
        <span>Quantity in stock:</span> <?php echo $key['quantity'];?></div>
            <div class="price">Price:                <?php echo $key['newprice'];?>€                <br>
                <span class="price-tax">+ 20% PVM</span><br>
                              </div>
                  <div class="cart">
        <div>Qty:          <input name="quantity" size="2" value="1" type="text">
          <input name="product_id" size="2" value="41" type="hidden">
          &nbsp;<a id="button-cart" class="button"><span>Add to Cart</span></a></div>
        <div><span>&nbsp;&nbsp;&nbsp;- OR -&nbsp;&nbsp;&nbsp;</span></div>
        <div><a>Add to Wish List</a><br>
          <a>Add to Compare</a></div>
              </div>
           
          </div>
  </div>
  <div id="tabs" class="htabs"><a class="selected" style="display: inline;" href="#tab-description">Description</a>

      </div>
  <div style="display: block;" id="tab-description" class="tab-content"><div>
	<?php echo $key['description'];?></div>
</div>
      <div style="display: none;" id="tab-related" class="tab-content">
          <div id="review"><div class="content">There are no reviews for this product.</div>
</div>
    
  </div>
      <div style="display: none;" id="tab-related" class="tab-content">
    <div class="box-product">
            <div>
                <div class="image"><a href="#"><img src="apple_cinema_30-80x80.jpg" alt="Apple Cinema 30&quot;"></a></div>
                <div class="name"><a href="#">Apple Cinema 30"</a></div>
                <div class="price">
                    <span class="price-old">86.03€</span> <span class="price-new">77.43€</span>
                  </div>
                        <a class="button"><span>Add to Cart</span></a></div>
          </div>
  </div>
      </div>
<?php endforeach;?>