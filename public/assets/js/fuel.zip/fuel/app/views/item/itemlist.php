<div id="content">  <div class="breadcrumb">
        <a href="http://demo.opencart.com/index.php?route=common/home">Home</a>
         » <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=20">Desktops</a>
         » <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=20_27">Mac</a>
         » <a href="http://demo.opencart.com/index.php?route=product/product&amp;path=20_27&amp;product_id=41">iMac</a>
      </div>
  <h1>iMac</h1>
  <div class="product-info">
        <div class="left">
            <div class="image"><a href="http://demo.opencart.com/image/cache/data/imac_1-500x500.jpg" title="iMac" class="fancybox" rel="fancybox"><img src="imac_1-228x228.jpg" title="iMac" alt="iMac" id="image"></a></div>
                  <div class="image-additional">
                <a href="http://demo.opencart.com/image/cache/data/imac_3-500x500.jpg" title="iMac" class="fancybox" rel="fancybox"><img src="imac_3-74x74.jpg" title="iMac" alt="iMac"></a>
                <a href="http://demo.opencart.com/image/cache/data/imac_2-500x500.jpg" title="iMac" class="fancybox" rel="fancybox"><img src="imac_2-74x74.jpg" title="iMac" alt="iMac"></a>
              </div>
          </div>
        <div class="right">
      <div class="description">
                <span>Brand:</span> <a href="http://demo.opencart.com/index.php?route=product/manufacturer/product&amp;manufacturer_id=8">Apple</a><br>
                <span>Product Code:</span> Product 14<br>
        <span>Reward Points:</span> 0<br>
        <span>Availability:</span> Out Of Stock</div>
            <div class="price">Price:                430.17€                <br>
                <span class="price-tax">Ex Tax: 366.10€</span><br>
                              </div>
                  <div class="cart">
        <div>Qty:          <input name="quantity" size="2" value="1" type="text">
          <input name="product_id" size="2" value="41" type="hidden">
          &nbsp;<a id="button-cart" class="button"><span>Add to Cart</span></a></div>
        <div><span>&nbsp;&nbsp;&nbsp;- OR -&nbsp;&nbsp;&nbsp;</span></div>
        <div><a onclick="addToWishList('41');">Add to Wish List</a><br>
          <a onclick="addToCompare('41');">Add to Compare</a></div>
              </div>
            <div class="review">
        <div><img src="stars-0.png" alt="0 reviews">&nbsp;&nbsp;<a onclick="$('a[href=\'#tab-review\']').trigger('click');">0 reviews</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a onclick="$('a[href=\'#tab-review\']').trigger('click');">Write a review</a></div>
        <div class="share"><!-- AddThis Button BEGIN -->
          <div class="addthis_default_style"><a class="addthis_button_compact">Share</a> <a class="addthis_button_email"></a><a class="addthis_button_print"></a> <a class="addthis_button_facebook"></a> <a class="addthis_button_twitter"></a></div>
           
          <!-- AddThis Button END --> 
        </div>
      </div>
          </div>
  </div>
  <div id="tabs" class="htabs"><a class="selected" style="display: inline;" href="#tab-description">Description</a>

      </div>
  <div style="display: block;" id="tab-description" class="tab-content"><div>
	Just when you thought iMac had everything, now there's even more. More powerful Intel Core 2 Duo processors. And more memory standard. Combine this with Mac OS X Leopard and iLife '08, and it's more all-in-one than ever. iMac packs amazing performance into a stunningly slim space.</div>
</div>
      <div style="display: none;" id="tab-review" class="tab-content">
    <div id="review"><div class="content">There are no reviews for this product.</div>
</div>
    
  </div>
      <div style="display: none;" id="tab-related" class="tab-content">
    <div class="box-product">
            <div>
                <div class="image"><a href="http://demo.opencart.com/index.php?route=product/product&amp;product_id=42"><img src="apple_cinema_30-80x80.jpg" alt="Apple Cinema 30&quot;"></a></div>
                <div class="name"><a href="http://demo.opencart.com/index.php?route=product/product&amp;product_id=42">Apple Cinema 30"</a></div>
                <div class="price">
                    <span class="price-old">86.03€</span> <span class="price-new">77.43€</span>
                  </div>
                        <a onclick="addToCart('42');" class="button"><span>Add to Cart</span></a></div>
          </div>
  </div>
      </div>