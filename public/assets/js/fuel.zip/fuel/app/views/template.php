<?php echo Html::doctype();?>
<html lang="en" xml:lang="en" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
<head>

<?php echo \Fuel\Core\Html::title('Simple shop');?>

    <?php
        $meta = array(
                        array('http-equiv'=>'Content-Type',   'content'=>'text/html; charset=UTF-8'),
                        array('name'=>'robots',   'content'=>'no-cache'),
                        array('name'=>'description',   'content'=>'Simple shop powered by Fuelphp'),
                        array('name'=>'keywords',   'content'=>'simple shop, fuelphp, framework,'),
                      );
        echo \Fuel\Core\Html::meta($meta);
    ?>
<link href="http://abba.com/assets/img/cart.png" rel="icon">

<?php echo \Fuel\Core\Asset::css('style.css'); ?>

</head>
<body>
<div id="container">
<div id="header">
    <div id="logo">
        <?php echo
                    Fuel\Core\Html::anchor('home',
                                                \Fuel\Core\Asset::img('logo.png',array('alt'=>'Fuelphp store' )))
        ;?>
    </div>
    <div id="currency">Currency<br>
                        <a title="Euro"><b>€</b></a>
                                    <a title="Pound Sterling">£</a>
                                    <a title="US Dollar">$</a>              
      
    </div>
    <div id="cart">
    <div class="heading">
<?php echo isset($cart)?$cart:'';?></div>
    <div class="content"></div>
  </div>
  <div id="search">
    <div class="button-search"></div>
        <input name="filter_name" value="Search"  type="text">
      </div>
  <div id="welcome">
        <?php echo !\Auth\Auth::check()?'Welcome visitor you can ':'Welcome ALEX';?>
<?php echo !\Auth\Auth::check()? \Fuel\Core\Html::anchor('account/login','Login'):'';?>
      <?php echo !\Auth\Auth::check()?' or ':'';?>
      <?php echo !\Auth\Auth::check()? \Fuel\Core\Html::anchor('account/signup','Signup'):'';?>.     </div>
  <div class="links">
      <?php echo \Auth\Auth::check()?\Fuel\Core\Html::anchor('home','Home'):'';?>
      <?php echo \Auth\Auth::check()?\Fuel\Core\Html::anchor('account/wishlist','Wish List'):'';?>
      <?php echo \Auth\Auth::check()?\Fuel\Core\Html::anchor('account/myprofile','My Profile'):'';?>
      <?php echo Fuel\Core\Html::anchor('account/cart','Shopping Cart');?>
      <?php echo \Fuel\Core\Html::anchor('account/checkout','Checkout');?>
      <?php echo \Auth\Auth::check()?\Fuel\Core\Html::anchor('account/logout','Logout'):'';?>
  </div>
</div> <!--header-->
<div id="menu">
  <ul>
        <li><?php echo \Fuel\Core\Html::anchor('category/desktops','Desktops');?>
            <div style="">
<ul>
                    <li><?php echo \Fuel\Core\Html::anchor('category/desktops/pc','Pc (0)');?></li>
                    <li><?php echo \Fuel\Core\Html::anchor('category/desktops/mac','Mac (1)');?></li>

    
                            </ul>
              </div>
          </li>
        <li><?php echo \Fuel\Core\Html::anchor('category/laptops_and_notebooks','Laptops &amp; Notebooks');?>
            <div style="">
<ul>
        <li><?php echo \Fuel\Core\Html::anchor('category/laptops_and_notebooks/laptops','Laptops (0)');?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/laptops_and_notebooks/notebooks','Notebooks (0)');?></li>

                            </ul>
              </div>
          </li>
        <li><?php echo \Fuel\Core\Html::anchor('category/components','Components');?>
            <div style="">
<ul>
        <li><?php echo \Fuel\Core\Html::anchor('category/components/mice_and_trackballs','Mice and Trackballs (0)');?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/components/monitors','Monitors (2)');?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/components/printers','Printers (0)');?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/components/scanners','Scanners (0)');?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/components/web_cameras','Web Cameras (0)');?></li>

                            </ul>
              </div>
          </li>
        <li><?php echo \Fuel\Core\Html::anchor('category/tablets','Tablets') ;?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/software','Software') ;?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/phones_and_pda','Phones & PDA') ;?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/cameras','Cameras') ;?></li>
        <li><?php echo \Fuel\Core\Html::anchor('category/mp3_player','Mp3 Player') ;?></li>
            <div style="margin-left: -315px;">
              </div>
          </li>
      </ul>
</div> <!--menu-->
<div id="notification"></div>

<?php echo isset($leftmenu) ? $leftmenu : '';?>
<?php echo isset($rightmenu) ? $rightmenu : '';?>
<?php echo isset($content) ? $content : '';?>

 
 

<div id="footer">
  <div class="column">
    <h3>Information</h3>
    <ul>
            <li><?php echo \Fuel\Core\Html::anchor('about_us','About Us')?></li>
            <li><?php echo \Fuel\Core\Html::anchor('delivery_information','Delivery Information')?></li>
            <li><?php echo \Fuel\Core\Html::anchor('privacy_policy','Privacy Policy')?></li>
            <li><?php echo \Fuel\Core\Html::anchor('terms_and_conditions','Terms &amp; Conditions')?></li>
          </ul>
  </div>
  <div class="column">
    <h3>Customer Service</h3>
    <ul>
        <li><?php echo \Fuel\Core\Html::anchor('contacts','Contact Us')?></li>
        <li><?php echo \Fuel\Core\Html::anchor('returns','Returns')?></li>
        <li><?php echo \Fuel\Core\Html::anchor('site_map','Site Map')?></li>
    </ul>
  </div>
  <div class="column">
    <h3>Extras</h3>
    <ul>
        <li><?php echo \Fuel\Core\Html::anchor('brands','Brands')?></li>
        <li><?php echo \Fuel\Core\Html::anchor('gift_vouchers','Gift Vouchers')?></li>
        <li><?php echo \Fuel\Core\Html::anchor('affiliates','Affiliates')?></li>
        <li><?php echo \Fuel\Core\Html::anchor('specials','Specials')?></li>
    </ul>
  </div>
  <div class="column">
    <h3>My Account</h3>
    <ul>
        <li><?php echo \Fuel\Core\Html::anchor('account/myprofile','My Profile')?></li>
        <li><?php echo \Fuel\Core\Html::anchor('account/order_history','Order History')?></li>
        <li><?php echo \Fuel\Core\Html::anchor('account/wishlist','Wish List')?></li>
        <li><?php echo \Fuel\Core\Html::anchor('newsletter','Newsletter')?></li>
    </ul>
  </div>
</div> <!--footer-->
<div id="powered">Powered By <a href="http://www.fuelphp.com/">FuelPHP framework</a><br> Design from Opencart Shop</div>
    <p style="text-align: right">Page renedered in {exec_time}s &middot; Memory Usage {mem_usage}MB</p>
</div>
</body>
</html>

