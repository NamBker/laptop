<div id="content">  <div class="breadcrumb">
        <a href="home">Home</a>
         » <a href="about_us">About Us</a>
      </div>
  <h1>About Us</h1>
  <p>
	About Us</p>
  <div class="buttons">
    <div class="right"><a href="home" class="button"><span>Continue</span></a></div>
  </div>
  </div>