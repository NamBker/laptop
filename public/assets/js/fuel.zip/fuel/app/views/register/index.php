<?php if(!\Captcha::check()): ?>
<form method="post">
    <img src="/captcha" alt="captcha" />
    <input type="text" name="keystring" />
    <button type="submit">Register</button>
</form>
<?php else: ?>
<p>Thanks for registering! Now you can login to your account.</p>
<?php endif; ?>