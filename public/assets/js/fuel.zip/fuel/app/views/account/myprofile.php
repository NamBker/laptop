<div id="content">  <div class="breadcrumb">
        <a href="http://demo.opencart.com/index.php?route=common/home">Home</a>
         » <a href="http://demo.opencart.com/index.php?route=account/account">Account</a>
      </div>
  <h1>My Account</h1>
    <h2>My Account</h2>
  <div class="content">
    <ul>
      <li><a href="http://demo.opencart.com/index.php?route=account/edit">Edit your account information</a></li>
      <li><a href="http://demo.opencart.com/index.php?route=account/password">Change your password</a></li>
      <li><a href="http://demo.opencart.com/index.php?route=account/address">Modify your address book entries</a></li>
      <li><a href="http://demo.opencart.com/index.php?route=account/wishlist">Modify your wish list</a></li>
    </ul>
  </div>
  <h2>My Orders</h2>
  <div class="content">
    <ul>
      <li><a href="http://demo.opencart.com/index.php?route=account/order">View your order history</a></li>
      <li><a href="http://demo.opencart.com/index.php?route=account/download">Downloads</a></li>
      <li><a href="http://demo.opencart.com/index.php?route=account/reward">Your Reward Points</a></li>
      <li><a href="http://demo.opencart.com/index.php?route=account/return">View your return requests</a></li>
      <li><a href="http://demo.opencart.com/index.php?route=account/transaction">Your Transactions</a></li>
    </ul>
  </div>
  <h2>Newsletter</h2>
  <div class="content">
    <ul>
      <li><a href="http://demo.opencart.com/index.php?route=account/newsletter">Subscribe / unsubscribe to newsletter</a></li>
    </ul>
  </div>
  </div>