    <div id="content">  <div class="breadcrumb">
     <?php echo \Fuel\Core\Html::anchor('home','Home');?>
   &raquo <?php echo \Fuel\Core\Html::anchor('account', 'Account');?>
    &raquo <?php echo \Fuel\Core\Html::anchor('account/signup','Register');?>
      </div>
  <h1>Register Account</h1>
    <p>If you already have an account with us, please login at the <?php echo \Fuel\Core\Html::anchor('account/login','Login page');?>.</p>
  <?php echo \Fuel\Core\Session::get_flash('notice');?>
<?php echo isset($errors) ? $errors : false; ?>
<?php echo Form::open('account/signup'); ?>
    <h2>Your Personal Details</h2>
    <div class="content">
      <table class="form">
        <tbody>
        <tr>
          <td><span class="required">*</span> <?php echo Form::label('Email: ', 'email'); ?></td>
          <td><?php echo Form::input('email', NULL, array('size' => 30)); ?>
            </td>
        </tr>

        <tr>
          <td><span class="required">*</span> <?php echo Form::label('User name: ', 'username'); ?></td>
          <td><?php echo Form::input('username', NULL, array('size' => 30)); ?></td>
        </tr>
      </tbody></table>
    </div>
    <h2>Your Password</h2>
    <div class="content">
      <table class="form">
        <tbody><tr>
          <td><span class="required">*</span> <?php echo Form::label('Password', 'username'); ?></td>
          <td><?php echo Form::password('password', NULL, array('size' => 30)); ?>
            </td>
        </tr>

      </tbody></table>
    </div>
        <div class="buttons">
      <div class="right">I have read and agree to the
          <?php echo \Fuel\Core\Html::anchor('privacy_policy','<b>Privacy Policy</b>',array('class'=>'fancybox','Alt'=>'Privacy Policy'));?><input name="agree" value="1" type="checkbox">
          <?php echo Form::submit('account/signup', 'Register',array('class'=>'button')); ?>
          <a href="#" class="button"><span>Continue</span></a></div>
            <?php echo Html::anchor('account/login','<span>Next</span>',array('class'=>'button'));  ?>

<?php echo Form::close(); ?>
    </div>

  </div>
