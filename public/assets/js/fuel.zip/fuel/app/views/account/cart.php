<div class="container"> 
  <div id="content">    <div class="breadcrumb">
            <a href="http://demo.opencart.com/index.php?route=common/home">Home</a>
             » <a href="http://demo.opencart.com/index.php?route=checkout/cart">Shopping Cart</a>
          </div>
    <h1>Shopping Cart            &nbsp;(5.00kg)
      </h1>
        
            <div class="warning">Products marked with *** are not available in the desired quantity or not in stock!</div>
      <form action="http://demo.opencart.com/index.php?route=checkout/cart" method="post" enctype="multipart/form-data" id="basket">
      <div class="cart-info">
        <table>
          <thead>
            <tr>
              <td class="remove">Remove</td>
              <td class="image">Image</td>
              <td class="name">Product Name</td>
              <td class="model">Model</td>
              <td class="quantity">Quantity</td>
              <td class="price">Unit Price</td>
              <td class="total">Total</td>
            </tr>
          </thead>
          <tbody>
                        <tr>
              <td class="remove"><input name="remove[]" value="41" type="checkbox"></td>
              <td class="image">                <a href="http://demo.opencart.com/index.php?route=product/product&amp;product_id=41"><img src="imac_1-80x80.jpg" alt="iMac" title="iMac"></a>
                </td>
              <td class="name"><a href="http://demo.opencart.com/index.php?route=product/product&amp;product_id=41">iMac</a>
                                <span class="stock">***</span>
                                <div>
                  </div>
                </td>
              <td class="model">Product 14</td>
              <td class="quantity"><input name="quantity[41]" value="1" size="3" type="text"></td>
              <td class="price">$587.50</td>
              <td class="total">$587.50</td>
            </tr>
            </tbody>
        </table>
      </div>
    </form>
      <div class="cart-total">
        <table>
                <tbody><tr>
          <td colspan="5"></td>
          <td class="right"><b>Sub-Total:</b></td>
          <td class="right">$500.00</td>
        </tr>
                <tr>
          <td colspan="5"></td>
          <td class="right"><b>VAT 17.5%:</b></td>
          <td class="right">$87.50</td>
        </tr>
                <tr>
          <td colspan="5"></td>
          <td class="right"><b>Total:</b></td>
          <td class="right">$587.50</td>
        </tr>
        </tbody></table>
  </div>
    <div class="buttons">
      <div class="left"><a onclick="$('#basket').submit();" class="button"><span>Update</span></a></div>
      <div class="right"><a href="http://demo.opencart.com/index.php?route=checkout/checkout" class="button"><span>Checkout</span></a></div>
      <div class="center"><a href="http://demo.opencart.com/index.php?route=common/home" class="button"><span>Continue Shopping</span></a></div>
    </div>
    </div>
</div>