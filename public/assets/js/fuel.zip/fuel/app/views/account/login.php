<div id="content">  <div class="breadcrumb">
     <?php echo \Fuel\Core\Html::anchor('home','Home');?>
   &raquo <?php echo \Fuel\Core\Html::anchor('account', 'Account');?>
    &raquo <?php echo \Fuel\Core\Html::anchor('account/login','Login');?>


      </div>
  <h1>Account Login</h1>
      <div class="login-content">
    <div class="left">
      <h2>New Customer</h2>
      <div class="content">
        <p><b>Register Account</b></p>

        <p>By creating an account you will be able to shop faster, be up to date on an order's status, and keep track of the orders you have previously made.</p>
      
      <?php echo \Fuel\Core\Html::anchor('account/signup','<span>Continue</span>',array('class'=>'button'));?>
      </div>
    </div>
    <div class="right">
      <h2>Returning Customer</h2>
<?php echo \Fuel\Core\Session::get_flash('notice');?>
<?php echo isset($errors) ? $errors : false; ?>
<?php echo Form::open('account/login'); ?>
        <div class="content">

          <p>I am a returning customer</p>
            <?php echo Form::label('<b>Username:</b>', 'username'); ?>
            <?php echo Form::input('username', isset($username) ? $username : false, array('size' => 30)); ?>
          <br />
          <br />

            <?php echo Form::label('<b>Password:</b>', 'password'); ?>
          <?php echo Form::password('password', NULL, array('size' => 30)); ?>

          <br />
          
            <?php echo \Fuel\Core\Html::anchor('account/forgotten','Forgotten Password') ;?> <br />
          <br />

          <span><?php echo Form::submit('login','Login', array('class'=>'button')); ?></span>
                  </div>

    </div>
  </div>

  </div>