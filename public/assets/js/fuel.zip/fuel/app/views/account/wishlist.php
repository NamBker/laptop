<div id="content">  <div class="breadcrumb">
        <a href="http://demo.opencart.com/index.php?route=common/home">Home</a>
         » <a href="http://demo.opencart.com/index.php?route=account/account">Account</a>
         » <a href="http://demo.opencart.com/index.php?route=account/wishlist">My Wish List</a>
      </div>
  <h1>My Wish List</h1>  
    <form action="http://demo.opencart.com/index.php?route=account/wishlist" method="post" enctype="multipart/form-data" id="wishlist">
    <div class="wishlist-product">
      <table>
        <thead>
          <tr>
            <td class="remove">Remove</td>
            <td class="image">Image</td>
            <td class="name">Product Name</td>
            <td class="model">Model</td>
            <td class="stock">Stock</td>
            <td class="price">Unit Price</td>
            <td class="cart">Buy Now</td>
          </tr>
        </thead>
        <tbody>
                    <tr>
            <td class="remove"><input name="remove[]" value="41" type="checkbox"></td>
            <td class="image">              <a href="http://demo.opencart.com/index.php?route=product/product&amp;product_id=41"><img src="imac_1-50x50.jpg" alt="iMac" title="iMac"></a>
              </td>
            <td class="name"><a href="http://demo.opencart.com/index.php?route=product/product&amp;product_id=41">iMac</a></td>
            <td class="model">Product 14</td>
            <td class="stock">Out Of Stock</td>
            <td class="price">              <div class="price">
                                $587.50                              </div>
              </td>
            <td class="cart"><a onclick="addToCart('41');" class="button"><span>Add to Cart</span></a></td>
          </tr>
                  </tbody>
      </table>
    </div>
  </form>
  <div class="buttons">
    <div class="left"><a href="http://demo.opencart.com/index.php?route=account/account" class="button"><span>Back</span></a></div>
    <div class="right"><a onclick="$('#wishlist').submit();" class="button"><span>Update</span></a></div>
  </div>
    </div>