<div id="content">  <div class="breadcrumb">
         <?php echo \Fuel\Core\Html::anchor('home','Home');?>
   &raquo <?php echo \Fuel\Core\Html::anchor('account', 'Account');?>
    &raquo <?php echo \Fuel\Core\Html::anchor('account/forgotten','Forgotten Password');?>


      </div>
  <h1>Forgot Your Password?</h1>
    <?php echo \Fuel\Core\Session::get_flash('notice');?>
<?php echo isset($errors) ? $errors : false; ?>
<?php echo Form::open('account/forgotten'); ?>

    <p>Enter the e-mail address associated with your account. Click submit to have your password e-mailed to you.</p>
    <h2>Your E-Mail Address</h2>
    <div class="content">
      <table class="form">

        <tr>
          <td><?php echo Form::label('<b>Username:</b>', 'username'); ?></td>
          <td><?php echo Form::input('username', isset($username) ? $username : false, array('size' => 30)); ?></td>
        </tr>
      </table>
    </div>
    <div class="buttons">
      <div class="left">
      <?php echo \Fuel\Core\Html::anchor('account/login','<span>Back</span>',array('class'=>'button'));?>

      </div>

      <div class="right">
          <?php echo Form::submit('forgotten','Get my Password', array('class'=>'button')); ?>
          <a onclick="$('#forgotten').submit();" class="button"><span>Continue</span></a></div>
    </div>
  </form>
  </div>
 
