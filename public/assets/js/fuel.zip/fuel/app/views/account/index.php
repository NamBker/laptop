<h1>Login</h1>
    <?php \Fuel\Core\Session::get_flash('notice');?>