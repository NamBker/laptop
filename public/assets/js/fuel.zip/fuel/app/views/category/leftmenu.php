<div id="column-left">
    <div class="box">
  <div class="box-heading">Categories</div>
  <div class="box-content">


    <div class="box-category">
      <ul>
                <li>
                    <a href="desktops" >Desktops (13)</a>
                              <ul>
                        <li>
                            <a href="pc"> - PC (0)</a>
                          </li>
                        <li>
                            <a href="mac"> - Mac (1)</a>
                          </li>
                      </ul>
                  </li>
                <li>
                    <a href="laptops">Laptops &amp; Notebooks (5)</a>
                              <ul>
                        <li>
                            <a href="laptops"> - Laptops (0)</a>
                          </li>
                        <li>
                            <a href="notebooks"> - Notebooks (0)</a>
                          </li>
                      </ul>
                  </li>
                <li>
                    <a href="components">Components (2)</a>
                              <ul>
                        <li>
                            <a href="mice"> - Mice and Trackballs (0)</a>
                          </li>
                        <li>
                            <a href="monitors"> - Monitors (2)</a>
                          </li>
                        <li>
                            <a href="printers"> - Printers (0)</a>
                          </li>
                        <li>
                            <a href="scanner"> - Scanners (0)</a>
                          </li>
                        <li>
                            <a href="web_cameras"> - Web Cameras (0)</a>
                          </li>
                      </ul>
                  </li>
                <li>
                    <a href="tablets" >Tablets (1)</a>
                            </li>
                <li>
                    <a href="software">Software (0)</a>
                            </li>
                <li>
                    <a href="phones_and_PDA">Phones &amp; PDAs (3)</a>
                            </li>
                <li>
                    <a href="cameras">Cameras (2)</a>
                            </li>
                <li>
                    <a href="mp3_player"class="active">MP3 Players (4)</a>
                              <ul>
                      </ul>
                  </li>
              </ul>
    </div>
  </div>
</div>
</div>
