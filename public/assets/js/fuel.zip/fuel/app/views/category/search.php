        <div id="content">  <div class="breadcrumb">
        <?php foreach($data2 as $data2 => $key2) ;?>
            <a href="home">Home</a>
          <?php echo isset($key2['categoryname'])? ' » '. \Fuel\Core\Html::anchor('category/'.$key2['categoryurl'],$key2['categoryname']):'' ;?>
          <?php echo isset($key2['subcategoryname'])? ' » '.\Fuel\Core\Html::anchor('category/'.$key2['categoryurl'].'/'.$key2['subcategoryurl'],$key2['subcategoryname']):'' ;?>

      </div>

  <h1>
      <?php
            if(isset($key2['subcategoryname']))
            {
                echo $key2['subcategoryname'];
            }
            elseif(isset($key2['categoryname']))
            {
                echo $key2['categoryname'];
            }else
            {
                echo '';
            }
      ?>
  </h1>

  
        <div class="product-filter">
    <div class="display"><b>Display:</b> List <b>/</b> <a>Grid</a></div>
    <div class="limit"><b>Show:</b>
      <select>
                        <option value="#" selected="selected">15</option>
                                <option value="#">25</option>
                                <option value="#">50</option>
                                <option value="#">75</option>
                                <option value="#">100</option>
                      </select>
    </div>



            <div class="sort"><b>Sort By:</b>
      <select>
                        <option value="#" selected="selected">Default</option>
                                <option value="#">Name (A - Z)</option>
                                <option value="#">Name (Z - A)</option>
                                <option value="#">Price (Low &gt; High)</option>
                                <option value="#">Price (High &gt; Low)</option>
                                <option value="#">Rating (Highest)</option>
                                <option value="#">Rating (Lowest)</option>
                                <option value="#">Model (A - Z)</option>
                                <option value="#">Model (Z - A)</option>
                      </select>
    </div>
  </div>
  <div class="product-compare"><a href="#" id="compare_total">Product Compare (0)</a></div>

  <?php foreach($data as $data1 => $key) :?>





    <div class="product-list">
        <div>
            <div class="right">
                <div class="cart"><a class="button"><span>Add to Cart</span></a>
                </div>
                <div class="wishlist"><a>Add to Wish List</a>
                </div>
                <div class="compare"><a>Add to Compare</a>
                </div>
            </div>
            <div class="left">
                <div class="image">

                <?php echo \Fuel\Core\Html::anchor('item/'.str_replace(" ","_",$key['itemname']) .'/'. $key['itemid'],\Fuel\Core\Asset::img($key['thumbnail'],array('title'=>$key['itemname'],'alt'=>$key['itemname']))) ;?>
</div>




        </div><div class="price">
                <?php echo $key['newprice'];?>€                        <br>
        <span class="price-tax">Ex Tax: 366.10€</span>
              </div>  <div class="name">
            <?php echo \Fuel\Core\Html::anchor('item/'.str_replace(" ","_",$key['itemname']) .'/'. $key['itemid'],$key['itemname']);?>

              <div class="description">
	<?php echo Str::truncate($key['description'], 120);?></div></div></div>
      </div>
    <?php endforeach;?>

  <div class="pagination"><div class="results"><?php echo Pagination::create_links();?></div></div>
      </div>
