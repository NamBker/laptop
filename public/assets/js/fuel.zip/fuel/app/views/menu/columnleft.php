<div id="column-left">
    <div class="box">
  <div class="box-heading">Categories</div>
  <div class="box-content">
    <div class="box-category">
      <ul>
                <li>
                    <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=20" class="active">Desktops (13)</a>
                              <ul>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=20_26"> - PC (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=20_27" class="active"> - Mac (1)</a>
                          </li>
                      </ul>
                  </li>
                <li>
                    <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=18">Laptops &amp; Notebooks (5)</a>
                              <ul>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=18_46"> - Macs (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=18_45"> - Windows (0)</a>
                          </li>
                      </ul>
                  </li>
                <li>
                    <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=25">Components (2)</a>
                              <ul>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=25_29"> - Mice and Trackballs (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=25_28"> - Monitors (2)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=25_30"> - Printers (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=25_31"> - Scanners (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=25_32"> - Web Cameras (0)</a>
                          </li>
                      </ul>
                  </li>
                <li>
                    <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=57">Tablets (1)</a>
                            </li>
                <li>
                    <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=17">Software (0)</a>
                            </li>
                <li>
                    <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=24">Phones &amp; PDAs (3)</a>
                            </li>
                <li>
                    <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=33">Cameras (2)</a>
                            </li>
                <li>
                    <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34">MP3 Players (4)</a>
                              <ul>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_43"> - test 11 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_44"> - test 12 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_47"> - test 15 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_48"> - test 16 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_49"> - test 17 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_50"> - test 18 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_51"> - test 19 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_52"> - test 20 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_53"> - test 21 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_54"> - test 22 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_55"> - test 23 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_56"> - test 24 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_38"> - test 4 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_37"> - test 5 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_39"> - test 6 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_40"> - test 7 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_41"> - test 8 (0)</a>
                          </li>
                        <li>
                            <a href="http://demo.opencart.com/index.php?route=product/category&amp;path=34_42"> - test 9 (0)</a>
                          </li>
                      </ul>
                  </li>
              </ul>
    </div>
  </div>
</div>
</div>