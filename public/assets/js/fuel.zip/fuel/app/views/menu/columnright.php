<div id="column-right">
    <div class="box">
  <div class="box-heading">Account</div>
  <div class="box-content">
    <ul>
            <li><a href="myaccount">My Account</a></li>
            <li><a href="editaccount">Edit Account</a></li>
      <li><a href="password">Password</a></li>
            <li><a href="wishlist">Wish List</a></li>
      <li><a href="orderhistory">Order History</a></li>
      <li><a href="downloads">Downloads</a></li>
      <li><a href="returns">Returns</a></li>
      <li><a href="transactions">Transactions</a></li>
      <li><a href="newsletter">Newsletter</a></li>
            <li><a href="logout">Logout</a></li>
          </ul>
  </div>
</div>
  </div>