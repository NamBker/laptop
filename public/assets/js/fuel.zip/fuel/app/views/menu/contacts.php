<div id="content">  <div class="breadcrumb">
        <a href="http://demo.opencart.com/index.php?route=common/home">Home</a>
         » <a href="http://demo.opencart.com/index.php?route=information/contact">Contact Us</a>
      </div>
  <h1>Contact Us</h1>
  <form action="http://demo.opencart.com/index.php?route=information/contact" method="post" enctype="multipart/form-data" id="contact">
    <h2>Our Location</h2>
    <div class="contact-info">
      <div class="content"><div class="left"><b>Address:</b><br>
        Your Store<br>
        Address 1</div>
      <div class="right">
                <b>Telephone:</b><br>
        123456789<br>
        <br>
                      </div>
    </div>
    </div>
    <h2>Contact Form</h2>
    <div class="content">
    <b>First Name:</b><br>
    <input name="name" value="" type="text">
    <br>
        <br>
    <b>E-Mail Address:</b><br>
    <input name="email" value="" type="text">
    <br>
        <br>
    <b>Enquiry:</b><br>
    <textarea name="enquiry" cols="40" rows="10" style="width: 950px; height: 180px;"></textarea>
    <br>
        <br>
    <b>Enter the code in the box below:</b><br>
    <input name="captcha" value="" type="text">
    <br>
    <img src="index.php" alt="">
        </div>
    <div class="buttons">
      <div class="right"><a onclick="$('#contact').submit();" class="button"><span>Continue</span></a></div>
    </div>
  </form>
  </div>