<div id="content">  <div class="breadcrumb">
        <a href="http://demo.opencart.com/index.php?route=common/home">Home</a>
         » <a href="http://demo.opencart.com/index.php?route=information/information&amp;information_id=4">About Us</a>
      </div>
  <h1>About Us</h1>
  <p>
	About Us</p>
  <div class="buttons">
    <div class="right"><a href="http://demo.opencart.com/index.php?route=common/home" class="button"><span>Continue</span></a></div>
  </div>
  </div>