<div id="content"><div class="slideshow">

  <div id="slideshow0" class="nivoSlider" style="width: 980px; height: 280px; position: relative; background: url('/assets/img/samsung_banner-980x280.jpg') no-repeat scroll 0% 0% transparent;">
            <a style="display: block;" class="nivo-imageLink" href="http://a.a/public/index.php/item/Samsung_Galaxy_Tab_10.1/12"><img style="display: none;" src="samsung_banner-980x280.jpg" alt="Samsung Tab 10.1"></a>
      <div style="display: none; opacity: 0.8;" class="nivo-caption"><p></p></div><div style="display: none;" class="nivo-directionNav"><a class="nivo-prevNav">Prev</a><a class="nivo-nextNav">Next</a></div><div class="nivo-controlNav"><a class="nivo-control active" rel="0">1</a></div><div style="left: 0px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll 0px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 65px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -65px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 130px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -130px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 195px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -195px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 260px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -260px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 325px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -325px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 390px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -390px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 455px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -455px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 520px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -520px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 585px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -585px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 650px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -650px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 715px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -715px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 780px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -780px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 845px; width: 65px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -845px 0% transparent; bottom: 0px;" class="nivo-slice"></div><div style="left: 910px; width: 70px; height: 100%; opacity: 1; background: url('http://a.a/public/assets/img/samsung_banner-980x280.jpg') no-repeat scroll -910px 0% transparent; bottom: 0px;" class="nivo-slice"></div></div>
</div>
<div class="box">
  <div class="box-heading">Featured</div>
  <div class="box-content">

      <div class="box-product">
          <?php foreach($data as $data => $key):?>
          <div>
                <div class="image">
                    <?php echo \Fuel\Core\Html::anchor('item/'.str_replace(" ","_",$key['itemname']) .'/'. $key['itemid'],\Fuel\Core\Asset::img($key['thumbnail'],array('alt'=>$key['itemname']))); ?>
                   

                </div>
                <div class="name">
                    <?php echo \Fuel\Core\Html::anchor('item/'.str_replace(" ","_",$key['itemname']) .'/'. $key['itemid'],Str::truncate($key['itemname'],17));?>
                    </div>
                <div class="price">
                    <?php echo $key['newprice'];?>€                  </div>
                        <div class="cart"><a href="/cart/add" class="button"><span>Add to Cart</span></a></div>
      </div>
      <?php endforeach;?>
    </div>


  </div>
</div>
</div> <!--content-->

