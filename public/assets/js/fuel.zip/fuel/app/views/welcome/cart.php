<h4>Shopping Cart</h4>
  <?php foreach($datacart as $datacart1 => $key);?>
 
<a><span id="cart_total"><?php echo isset($datacount)?$datacount:'';?> item(s) - <?php echo isset($key['sum(item_price)'])?$key['sum(item_price)']:'';?>$</span></a>

