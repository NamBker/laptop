<?php

 
class Controller_Services extends \Fuel\Core\Controller_Template{
    public function action_index()
    {

    }
    public function action_contacts()
    {
        $this->template->content = \Fuel\Core\View::factory('services/contacts');
    }
    public function action_returns()
    {
        $this->template->content = \Fuel\Core\View::factory('services/returns');
    }
    public function action_sitemap()
    {
        $this->template->content = \Fuel\Core\View::factory('services/sitemap');
    }
    public function action_404(){

        $this->template->content = "Error 404";
    }
}
