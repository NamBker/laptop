<?php

 
class Controller_welcome extends \Fuel\Core\Controller_Template {

    public function action_index()
    {
        // that code generate new user_id and show how how many items in cart
        if(Cookie::get('user_id'))
        {
            $user_id = Cookie::get('user_id');
            $query_count = DB::query('SELECT item_id FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute();
            $query2 = DB::query('SELECT sum(item_price) FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute()->as_array();
            $data = $query_count->as_array();
            $datasum = $query2;
            $data_count = $query_count->count();
        }else
        {
            $unique_id = Str::random('sha1');
            Cookie::set('user_id',$unique_id,time()+3600,'/','abba.com');
        }
        //show items from db on main page
        $query = \Fuel\Core\DB::query('SELECT
                                                    itemid,
                                                    indexitemid,
                                                    photoitemid,
                                                    itemname,
                                                    newprice,
                                                    thumbnail
                                               FROM
                                                    items,
                                                    itemsindex,
                                                    photo
                                               WHERE
                                                    items.itemid = photo.photoitemid
                                               AND
                                                    items.itemid = itemsindex.indexitemid
                                               LIMIT 6
                                        ')->execute();
        $data = $query->as_array();

        $this->template->content = \Fuel\Core\View::factory('welcome/index')->set('data',$data);
        $this->template->cart = View::factory('welcome/cart')->set('datacart',$datasum)->set('datacount',$data_count);
    }
    public function action_404(){

        $this->template->content = "Error 404";
    }
}
