<?php

 
class Controller_Category extends \Fuel\Core\Controller_Template {
    public $data;

    public function action_index(){
        
        $this->template->leftmenu = \Fuel\Core\View::factory('category/leftmenu');
        $this->template->content = \Fuel\Core\View::factory('category/index');
    }
    public function action_search($maincategory='', $subcategory='', $offset='')
    {
        // that code generate new user_id and show how how many items in cart
        if(Cookie::get('user_id'))
        {
            $user_id = Cookie::get('user_id');
            $query_count = DB::query('SELECT item_id FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute();
            $query2 = DB::query('SELECT sum(item_price) FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute()->as_array();
            $data = $query_count->as_array();
            $datasum = $query2;
            $data_count = $query_count->count();
        }else
        {
            $unique_id = Str::random('sha1');
            Cookie::set('user_id',$unique_id,time()+3600,'/','abba.com');
        }
        if(isset($maincategory) AND empty($subcategory))
        {
            $querycount = \Fuel\Core\DB::query('SELECT
                                                    itemcategoryid,
                                                    categoryurl,
                                                    categoryid
                                                FROM
                                                    items,
                                                    category
                                                WHERE
                                                category.categoryurl = "'.$maincategory.'"
                                                AND
                                                category.categoryid = items.itemcategoryid
                                                ')->execute();
            $config = array('pagination_url' => \Fuel\Core\Uri::create('category/'.$maincategory),
                            'uri_segment' => 2,
                            'total_items' => $querycount->count(),
                            'per_page' => 4,
                            'current_page'=>1
                            
            );
            Pagination::set_config($config);
            $query = \Fuel\Core\DB::query('SELECT
                                                itemid,
                                                itemcategoryid,
                                                itemname,
                                                newprice,
                                                description,
                                                categoryid,
                                                categoryurl,
                                                thumbnail,
                                                categoryname
                                            FROM
                                                items,
                                                photo,
                                                category
                                            WHERE
                                                category.categoryurl = "'.$maincategory.'"
                                            AND
                                                category.categoryid = items.itemcategoryid
                                            AND
                                                itemid = photoitemid
                                            LIMIT '. \Fuel\Core\Pagination::$per_page .'
                                            
                                            ')->execute();
            $query2 = \Fuel\Core\DB::query('SELECT
                                                categoryid,
                                                categoryurl,
                                                categoryname
                                             FROM
                                                category
                                             WHERE
                                                categoryurl = "'.$maincategory.'"
            ')->execute();
//            ----------

            
//            ----------
            $data = $query->as_array();
            $data2 = $query2->as_array();
        $this->template->leftmenu = \Fuel\Core\View::factory('category/leftmenu');
        $this->template->content = \Fuel\Core\View::factory('category/search')->set('data',$data)->set('data2',$data2);
             $this->template->cart = View::factory('welcome/cart')->set('datacart',$datasum)->set('datacount',$data_count);

        }elseif(isset($maincategory) AND isset($subcategory) and !is_numeric($subcategory) and empty($offset))
        {

            $querycount = \Fuel\Core\DB::query('SELECT
                                                    itemsubcategoryid,
                                                    subcategoryurl,
                                                    subcategoryid
                                                FROM
                                                    items,
                                                    subcategory
                                                WHERE
                                                subcategory.subcategoryurl = "'.$subcategory.'"
                                                AND
                                                subcategory.subcategoryid = items.itemsubcategoryid
                                                ')->execute();
            $config = array('pagination_url' => \Fuel\Core\Uri::create('category/'.$maincategory.'/'.$subcategory),
                            'uri_segment' => 4,
                            'total_items' => $querycount->count(),
                            'per_page' => 4,

            );
            Pagination::set_config($config);
            $query = \Fuel\Core\DB::query('SELECT
                                                itemid,
                                                itemsubcategoryid,
                                                itemname,
                                                newprice,
                                                description,
                                                subcategoryid,
                                                subcategoryurl,
                                                thumbnail,
                                                subcategoryname
                                            FROM
                                                items,
                                                photo,
                                                subcategory

                                            WHERE
                                                subcategory.subcategoryurl = "'.$subcategory.'"
                                            AND
                                                subcategory.subcategoryid = items.itemsubcategoryid
                                            AND
                                                itemid = photoitemid
                                                
                                        ')->execute();
            
            $query2 = \Fuel\Core\DB::query('SELECT
                                                categoryid,
                                                subcategoryid,
                                                rootid,
                                                categoryname,
                                                subcategoryname,
                                                categoryurl,
                                                subcategoryurl
                                             FROM
                                                category,
                                                subcategory
                                             WHERE
                                                subcategoryurl = "'.$subcategory.'"
                                             AND
                                                rootid = categoryid

            ')->execute();

            $data = $query->as_array();
            $data2 = $query2->as_array();

        $this->template->leftmenu = \Fuel\Core\View::factory('category/leftmenu');
        
        $this->template->content = \Fuel\Core\View::factory('category/search')->set('data',$data)->set('data2',$data2);
             $this->template->cart = View::factory('welcome/cart')->set('datacart',$datasum)->set('datacount',$data_count);
        }elseif(isset($maincategory) AND isset($subcategory) and is_numeric($subcategory))
        {

            $querycount = \Fuel\Core\DB::query('SELECT
                                                    itemcategoryid,
                                                    categoryurl,
                                                    categoryid
                                                FROM
                                                    items,
                                                    category
                                                WHERE
                                                category.categoryurl = "'.$maincategory.'"
                                                AND
                                                category.categoryid = items.itemcategoryid
                                                ')->execute();
            $config = array('pagination_url' => \Fuel\Core\Uri::create('category/'.$maincategory),
                            'uri_segment' => 3,
                            'total_items' => $querycount->count(),
                            'per_page' => 4,
                            
            );

            Pagination::set_config($config);
            $query = \Fuel\Core\DB::query('SELECT
                                                itemid,
                                                itemcategoryid,
                                                itemname,
                                                newprice,
                                                description,
                                                categoryid,
                                                categoryurl,
                                                thumbnail,
                                                categoryname
                                            FROM
                                                items,
                                                photo,
                                                category
                                            WHERE
                                                category.categoryurl = "'.$maincategory.'"
                                            AND
                                                category.categoryid = items.itemcategoryid
                                            AND
                                                itemid = photoitemid
                                            LIMIT '. \Fuel\Core\Pagination::$per_page .'
                                            OFFSET '. \Fuel\Core\Pagination::$offset .'
                                            ')->execute();

            
            $query2 = \Fuel\Core\DB::query('SELECT
                                                categoryid,
                                                categoryurl,
                                                categoryname
                                             FROM
                                                category
                                             WHERE
                                                categoryurl = "'.$maincategory.'"
            ')->execute();
//            ----------


//            ----------
            $data = $query->as_array();
            $data2 = $query2->as_array();
        $this->template->leftmenu = \Fuel\Core\View::factory('category/leftmenu');
        $this->template->content = \Fuel\Core\View::factory('category/search')->set('data',$data)->set('data2',$data2);
 $this->template->cart = View::factory('welcome/cart')->set('datacart',$datasum)->set('datacount',$data_count);



        }elseif(isset($maincategory) AND isset($subcategory) AND !is_numeric($subcategory) AND is_numeric($offset))
        {

        $querycount = \Fuel\Core\DB::query('SELECT
                                                    itemsubcategoryid,
                                                    subcategoryurl,
                                                    subcategoryid
                                                FROM
                                                    items,
                                                    subcategory
                                                WHERE
                                                subcategory.subcategoryurl = "'.$subcategory.'"
                                                AND
                                                subcategory.subcategoryid = items.itemsubcategoryid
                                                ')->execute();
            $config = array('pagination_url' => \Fuel\Core\Uri::create('category/'.$maincategory.'/'.$subcategory),
                            'uri_segment' => 4,
                            'total_items' => $querycount->count(),
                            'per_page' => 4,

            );
            Pagination::set_config($config);
            $query = \Fuel\Core\DB::query('SELECT
                                                itemid,
                                                itemsubcategoryid,
                                                itemname,
                                                newprice,
                                                description,
                                                subcategoryid,
                                                subcategoryurl,
                                                thumbnail,
                                                subcategoryname
                                            FROM
                                                items,
                                                photo,
                                                subcategory

                                            WHERE
                                                subcategory.subcategoryurl = "'.$subcategory.'"
                                            AND
                                                subcategory.subcategoryid = items.itemsubcategoryid
                                            AND
                                                itemid = photoitemid
                                            LIMIT '. \Fuel\Core\Pagination::$per_page .'
                                            OFFSET '. \Fuel\Core\Pagination::$offset .'

                                        ')->execute();

            $query2 = \Fuel\Core\DB::query('SELECT
                                                categoryid,
                                                subcategoryid,
                                                rootid,
                                                categoryname,
                                                subcategoryname,
                                                categoryurl,
                                                subcategoryurl
                                             FROM
                                                category,
                                                subcategory
                                             WHERE
                                                subcategoryurl = "'.$subcategory.'"
                                             AND
                                                rootid = categoryid

            ')->execute();

            $data = $query->as_array();
            $data2 = $query2->as_array();

        $this->template->leftmenu = \Fuel\Core\View::factory('category/leftmenu');

        $this->template->content = \Fuel\Core\View::factory('category/search')->set('data',$data)->set('data2',$data2);
             $this->template->cart = View::factory('welcome/cart')->set('datacart',$datasum)->set('datacount',$data_count);

        }



        else
        {
            echo 'Something wrong in your url, CHECK IT OUT PLEASE.';
        }
        



    }



    public function action_404(){

        $this->template->content = "Error 404";
    }


}
