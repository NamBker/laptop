<?php

 
class Controller_Information extends \Fuel\Core\Controller_Template{
    public function action_index()
    {
        $this->template;
    }
    public function action_about()
    {
        $this->template->content = \Fuel\Core\View::factory('info/about');
    }
    public function action_delivery()
    {
        $this->template->content = \Fuel\Core\View::factory('info/delivery');
    }
    public function action_privacy()
    {
        $this->template->content = \Fuel\Core\View::factory('info/privacy');
    }
    public function action_terms()
    {
        $this->template->content = \Fuel\Core\View::factory('info/terms');
    }
    public function action_404()
    {
        $this->template->content = 'Some thing wrong in URL adress, check it out please.';
    }

}
