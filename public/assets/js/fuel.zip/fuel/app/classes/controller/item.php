<?php

 
class Controller_Item extends \Fuel\Core\Controller_Template{
    public function action_index()
    {
        $this->template->content = "What are you searching for?";
    }
    public function action_search($description='', $itemid='')
    {
        // that code generate new user_id and show how how many items in cart
        if(Cookie::get('user_id'))
        {
            $user_id = Cookie::get('user_id');
            $query_count = DB::query('SELECT item_id FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute();
            $query2 = DB::query('SELECT sum(item_price) FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute()->as_array();
            $data = $query_count->as_array();
            $datasum = $query2;
            $data_count = $query_count->count();
        }else
        {
            $unique_id = Str::random('sha1');
            Cookie::set('user_id',$unique_id,time()+3600,'/','abba.com');
        }
        if(is_numeric($itemid))
        {
            $query = \Fuel\Core\DB::query('SELECT
                                                itemid,
                                                itemname,
                                                quantity,
                                                brand,
                                                newprice,
                                                description,
                                                photoitemid,
                                                photo1,
                                                photo2,
                                                photo3,
                                                brandname,
                                                itemcategoryid,
                                                itemsubcategoryid,
                                                categoryid,
                                                subcategoryid,
                                                categoryurl,
                                                subcategoryurl,
                                                rootid,
                                                categoryname,
                                                subcategoryname
                                            FROM
                                                items,
                                                photo,
                                                brands,
                                                category,
                                                subcategory
                                            WHERE
                                                itemid = '.$itemid.'

                                            AND brand = brandid
                                            AND itemid = photoitemid
                                            AND itemcategoryid = categoryid
                                            AND itemsubcategoryid = subcategoryid

                                            LIMIT 1
            ')->execute();
        }else{
            echo 'something wrong in URL';
        }
        if(isset($query))
        {
            $data = $query->as_array();
        }
        else
        {
            $data = array();
        }



        $this->template->leftmenu = \Fuel\Core\View::factory('item/leftmenu');
        $this->template->content = \Fuel\Core\View::factory('item/item')->set('data',$data);
        $this->template->cart = View::factory('welcome/cart')->set('datacart',$datasum)->set('datacount',$data_count);
    }

    public function action_404()
    {
        $this->template->content = "Error 404";
    }
}
