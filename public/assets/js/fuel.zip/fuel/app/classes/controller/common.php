<?php

class Controller_Common extends Controller_Template {
	
	    public function before()
    {
        parent::before();
        $uri_string = explode('/', Uri::string());

        if (count($uri_string)>1 and $uri_string[0] == 'account' and ($uri_string[1] == 'login' or $uri_string[1] == 'signup' or $uri_string[1] == 'forgotten'or $uri_string[1] == 'cart' or $uri_string[1] == 'checkout'))
        {
            $this->template->logged_in = false;
        }
        else
        {
            if(\Auth::check())
            {
                $user = \Auth::instance()->get_user_id();
                $this->user_id = $user[1];
                $this->template->logged_in = true;
            }
            else
            {
                $this->template->logged_in = false;
                
                \Fuel\Core\Response::redirect('account/login');
            }
        }
    }

	
	public function action_404()
	{
		$messages = array('Aw, crap!', 'Bloody Hell!', 'Uh Oh!', 'Nope, not here.', 'Huh?');
		$data['title'] = $messages[array_rand($messages)];
		
		// Set a HTTP 404 output header
		$this->response->status = 404;
		$this->template->content = View::factory('404', $data);
	}
}

/* End of file common.php */
