<?php


class Controller_Account extends Controller_Common{
        public function before()
    {
        parent::before();
    }
    public function action_index()
    {
        $this->template->content = \Fuel\Core\View::factory('account/index');
    }
    public function action_login()
    {

        // that code generate new user_id and show how how many items in cart
        if(Cookie::get('user_id'))
        {
            $user_id = Cookie::get('user_id');
            $query_count = DB::query('SELECT item_id FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute();
            $query2 = DB::query('SELECT sum(item_price) FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute()->as_array();
            $data = $query_count->as_array();
            $datasum = $query2;
            $data_count = $query_count->count();
        }else
        {
            $unique_id = Str::random('sha1');
            Cookie::set('user_id',$unique_id,time()+3600,'/','abba.com');
        }
        //login
        if(Auth::check())
        {
            Response::redirect('account');
        }
            $val =\Fuel\Core\Validation::factory('users');
            $val->add_field('username', 'Your username', 'required|min_length[3]|max_length[20]');
            $val->add_field('password', 'Your password', 'required|min_length[3]|max_length[20]');
        if($val->run())
        {
            $auth = Auth::instance();
            if($auth->login($val->validated('username'),$val->validated('password')))
            {
                Session::set_flash('notice','FLASH: logged in');
                Response::redirect('account');
            }else
            {
                $data['username'] = $val->validated('username');
                $data['errors'] = 'Wrong username/password';
            }
        }else
        {
            if($_POST)
            {
                $data['username'] = $val->validated('username');
                $data['errors'] = 'Wrong username/password combo. Try again';
            }
            else
            {
                $data['errors'] = false;
            }
        }
        $this->template->errors = @$data['errors'];
        $this->template->content = \Fuel\Core\View::factory('account/login', $data);
        $this->template->cart = View::factory('welcome/cart')->set('datacart',$datasum)->set('datacount',$data_count);
    }
    public function action_signup()
    {
        //signup
        if(Cookie::get('user_id'))
        {
            $user_id = Cookie::get('user_id');
            $query_count = DB::query('SELECT item_id FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute();
            $query2 = DB::query('SELECT sum(item_price) FROM carts WHERE cookie_user_id = "'. $user_id .'"')->execute()->as_array();
            $data = $query_count->as_array();
            $datasum = $query2;
            $data_count = $query_count->count();
        }else
        {
            $unique_id = Str::random('sha1');
            Cookie::set('user_id',$unique_id,time()+3600,'/','abba.com');
        }
        if ( Auth::check())
        {
            \Fuel\Core\Response::redirect('home');
        }
        $val = Validation::factory('user_signup');
        $val->add_field('username', 'Your username', 'required|min_length[3]|max_length[20]');
        $val->add_field('password', 'Your password', 'required|min_length[3]|max_length[20]');
        $val->add_field('email', 'Email', 'required|valid_email');
        if ( $val->run() )
        {
            $create_user = Auth::instance()->create_user(
                    $val->validated('username'),
                    $val->validated('password'),
                    $val->validated('email'),
                    '100'
            );

            if( $create_user )
            {
                $daz = Session::set_flash('notice', '<strong>FLASH: User created.</strong>');
                \Fuel\Core\Response::redirect('account',$daz);
            }
            else
            {
                throw new Exception('An unexpected error occurred. Please try again.');
            }
        }
        else
        {
            if( $_POST )
            {
                $data['username'] = $val->validated('username');
                $data['login_error'] = 'All fields are required.';
            }
            else
            {
                $data['login_error'] = false;
            }
        }
        $this->template->content = \Fuel\Core\View::factory('account/signup');
        $this->template->cart = View::factory('welcome/cart')->set('datacart',$datasum)->set('datacount',$data_count);
    }
    public function action_logout()
    {
        \Auth\Auth::instance()->logout();
        \Fuel\Core\Response::redirect('/');
        $this->template->content = \Fuel\Core\View::factory('account/logout');
        
    }
    public function action_wishlist()
    {
        $this->template->content = \Fuel\Core\View::factory('account/wishlist');
    }
    public function action_history()
    {
        $this->template->content = \Fuel\Core\View::factory('account/history');
    }
    public function action_cart()
    {
        var_dump($_POST);
        $this->template->content = \Fuel\Core\View::factory('account/cart');
    }
    public function action_checkout()
    {
        $this->template->content = \Fuel\Core\View::factory('account/checkout');
    }
    public function action_forgotten()
    {
        $this->template->content = \Fuel\Core\View::factory('account/forgotten');
    }
    public function action_myprofile()
    {
        $this->template->content = \Fuel\Core\View::factory('account/myprofile');
    }
    public function action_404(){
        
        $this->template->content = "Error 404a";
    }

}
