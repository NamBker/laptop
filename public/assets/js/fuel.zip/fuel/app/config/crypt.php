<?php
/**
 * Fuel is a fast, lightweight, community driven PHP5 framework.
 *
 * @package		Fuel
 * @version		1.0
 * @author		Fuel Development Team
 * @license		MIT License
 * @copyright	2011 Fuel Development Team
 * @link		http://fuelphp.com
 */

return array (
	'salt' => 'sup3rs3Cr3tk3y564',
	'use_mcrypt' => true,
	'mcrypt_cipher' => 'rijndael-256',
	'mcrypt_mode' => 'cbc',
	'crypto_key' => 'AOgAVw-TckgcSOM47ElUYpbU',
	'crypto_iv' => 'mAUkkU5dQWWEgGIalk2yMtYY',
	'crypto_hmac' => 'J1YFyg9Q8YTovkIE4k1p08eE',
);

