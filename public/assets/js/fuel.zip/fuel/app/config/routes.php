<?php
return array(
	'_root_'        => 'welcome/index',  // The default route
    'home'          => 'welcome/index',
	'_404_'         => 'welcome/404',    // The main 404 route
    'account/login'         => 'account/login',
    'account/logout'        => 'account/logout',
    'account/signup'        => 'account/signup',
    'account/logout'        => 'account/logout',
    'account/wishlist'      => 'account/wishlist',
    'account/order_history' => 'account/history',
    'account'               => 'account/index',
    'account/myprofile'     => 'account/myprofile',
    'account/cart'          => 'account/cart',
    'account/checkout'      => 'account/checkout',
    'account/forgotten'     => 'account/forgotten',
    'account/orders'        => 'account/orders',
    'category/(:id)'        => 'category/search/$1',
    'about_us'              => 'information/about',
    'delivery_information'  => 'information/delivery',
    'privacy_policy'        => 'information/privacy',
    'terms_and_conditions'  => 'information/terms',
    'contacts'              => 'services/contacts',
    'returns'               => 'services/returns',
    'site_map'              => 'services/sitemap',
    'item/(:id)'            => 'item/search/$1',
    'dima'                  => 'dima/index'


//    'category/(:id)' => 'category/index/$1',
//    'item/(:id)'=>'item/index/$1',
//    'page/(:id)'=>'page/index/$1',
	
	/**
	 * This is an example of a BASIC named route (used in reverse routing).
	 * The translated route MUST come first, and the 'name' element must come
	 * after it.
	 */
	// 'foo/bar' => array('welcome/foo', 'name' => 'foo'),
);