<?php
/**
 * Part of the Fuel framework.
 *
 * @package    Fuel
 * @version    1.8
 * @author     Fuel Development Team
 * @license    MIT License
 * @copyright  2010 - 2016 Fuel Development Team
 * @link       http://fuelphp.com
 */

namespace Fuel\Core;

/**
 * Database_Query_Builder_Update class tests
 *
 * @group Core
 * @group Database
 */
class Test_Database_Query_Builder_Update extends TestCase
{
 	public function test_foo() {}
}
