<?php
namespace Media;
class Presenter_Information_Detail extends \Presenter_Media
{

	public function view()
	{
		\Additional_Log::debug("start.");
		parent::view();
	}

}
