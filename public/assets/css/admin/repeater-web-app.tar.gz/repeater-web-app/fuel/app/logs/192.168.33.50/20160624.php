<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:02:02 --> user/index called
INFO - 2016-06-24 16:02:02 --> store/index called
INFO - 2016-06-24 16:02:02 --> company/index called
INFO - 2016-06-24 16:02:02 --> brand/index called
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:02:27 --> store/index called
INFO - 2016-06-24 16:02:27 --> brand/index called
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:02:27 --> user/index called
INFO - 2016-06-24 16:02:27 --> company/index called
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
INFO - 2016-06-24 16:02:35 --> company/index called
DEBUG - 2016-06-24 16:02:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:02:35 --> user/index called
INFO - 2016-06-24 16:02:35 --> store/index called
INFO - 2016-06-24 16:02:35 --> brand/index called
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:03:36 --> store/index called
INFO - 2016-06-24 16:03:36 --> brand/index called
INFO - 2016-06-24 16:03:36 --> company/index called
INFO - 2016-06-24 16:03:36 --> user/index called
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:03:36 --> store/index called
DEBUG - 2016-06-24 16:03:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:03:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:03:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:03:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:03:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:03:36 --> brand/index called
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:03:36 --> company/index called
DEBUG - 2016-06-24 16:03:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:03:45 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:03:45 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:03:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:03:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:03:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:03:45 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:03:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:03:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:03:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:03:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:03:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:03:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:03:52 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:03:52 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:03:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:03:52 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:03:52 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:03:52 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:03:52 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:04 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:04 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:04 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:04 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:04 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:04 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:04 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:05 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:05 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:05 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:05 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:07 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:07 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:07 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:07 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:10 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:10 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:10 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:10 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:17 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:17 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:17 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:18 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:24 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:24 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:24 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:24 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:29 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:29 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:29 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:29 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:04:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:04:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:04:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:04:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:04:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:04:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:04:34 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:04:34 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:04:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:04:34 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:04:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:04:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:04:34 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:05:03 --> user/index called
INFO - 2016-06-24 16:05:03 --> store/index called
INFO - 2016-06-24 16:05:03 --> brand/index called
INFO - 2016-06-24 16:05:03 --> company/index called
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:03 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:05:03 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 16:05:03 --> store/index called
DEBUG - 2016-06-24 16:05:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:05:03 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:05:03 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:03 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:05:03 --> brand/index called
INFO - 2016-06-24 16:05:03 --> company/index called
DEBUG - 2016-06-24 16:05:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:05 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:05:05 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:05:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:05:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:05:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:05:05 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:05:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:11 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:05:11 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:05:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:05:11 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:05:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:05:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:05:11 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:05:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:13 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:05:13 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:05:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:05:13 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:05:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:05:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:05:13 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:05:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:27 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:05:27 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:05:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:05:27 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:05:27 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:05:27 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:05:27 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:05:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:29 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:05:29 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:05:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:05:29 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:05:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:05:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:05:29 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:05:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:05:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:05:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:05:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:05:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:05:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:05:31 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:05:31 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:05:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:05:31 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:05:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:05:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:05:31 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:06:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:19 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:06:19 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:06:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:06:19 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:06:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:06:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:06:19 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:06:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:20 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:06:20 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:06:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:06:20 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:06:20 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:06:20 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:06:20 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:34 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:06:34 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:06:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:06:34 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:06:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:06:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:06:34 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:34 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:06:34 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:06:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:06:35 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:06:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:06:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:06:35 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:06:41 --> store/index called
INFO - 2016-06-24 16:06:41 --> brand/index called
INFO - 2016-06-24 16:06:41 --> company/index called
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:41 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-24 16:06:41 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-24 16:06:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:06:41 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-24 16:06:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:43 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-24 16:06:43 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-24 16:06:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:06:43 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-24 16:06:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:48 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-24 16:06:48 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-24 16:06:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:06:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:06:48 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:06:54 --> company/index called
INFO - 2016-06-24 16:06:54 --> brand/index called
INFO - 2016-06-24 16:06:54 --> store/index called
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:06:54 --> user/index called
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
INFO - 2016-06-24 16:06:54 --> store/index called
DEBUG - 2016-06-24 16:06:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:06:54 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-24 16:06:54 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-24 16:06:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:55 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:06:55 --> brand/index called
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:06:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:06:55 --> company/index called
DEBUG - 2016-06-24 16:07:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:07:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:07:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:07:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:07:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:07:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:07:00 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-24 16:07:00 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-24 16:07:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:07:00 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-24 16:07:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:07:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:07:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:07:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:07:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:07:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:07:03 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-24 16:07:03 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-24 16:07:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:07:03 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:07:03 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:09:21 --> brand/index called
DEBUG - 2016-06-24 16:09:21 --> Api\Controller_Questionnaire->index(40) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-24 16:09:21 --> Api\Controller_Questionnaire->setParams(170) - 【QUESTIONNAIRE API】:SET PARAM
INFO - 2016-06-24 16:09:21 --> company/index called
INFO - 2016-06-24 16:09:21 --> store/index called
DEBUG - 2016-06-24 16:09:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:09:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:09:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:09:21 --> Api\Controller_Questionnaire->index(80) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-24 16:09:21 --> Api\Controller_Questionnaire->index(84) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-24 16:09:21 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-24 16:09:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:25 --> Api\Controller_Questionnaire->index(40) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-24 16:09:25 --> Api\Controller_Questionnaire->setParams(170) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-24 16:09:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:09:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:09:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:09:25 --> Api\Controller_Questionnaire->index(80) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-24 16:09:25 --> Api\Controller_Questionnaire->index(84) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-24 16:09:25 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-24 16:09:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:31 --> Api\Controller_Questionnaire->index(40) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-24 16:09:31 --> Api\Controller_Questionnaire->setParams(170) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-24 16:09:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:09:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:09:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:09:31 --> Api\Controller_Questionnaire->index(80) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-24 16:09:31 --> Api\Controller_Questionnaire->index(84) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-24 16:09:31 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-24 16:09:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:32 --> Api\Controller_Questionnaire->index(40) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-24 16:09:32 --> Api\Controller_Questionnaire->setParams(170) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-24 16:09:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:09:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:09:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:09:32 --> Api\Controller_Questionnaire->index(80) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-24 16:09:32 --> Api\Controller_Questionnaire->index(84) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-24 16:09:32 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-24 16:09:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:35 --> Api\Controller_Questionnaire->index(40) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-24 16:09:35 --> Api\Controller_Questionnaire->setParams(170) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-24 16:09:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:09:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:09:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:09:35 --> Api\Controller_Questionnaire->index(80) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-24 16:09:35 --> Api\Controller_Questionnaire->index(84) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-24 16:09:35 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:09:41 --> company/index called
INFO - 2016-06-24 16:09:41 --> brand/index called
INFO - 2016-06-24 16:09:41 --> user/index called
INFO - 2016-06-24 16:09:41 --> store/index called
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:09:41 --> store/index called
DEBUG - 2016-06-24 16:09:41 --> Api\Controller_Questionnaire->index(40) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-24 16:09:41 --> Api\Controller_Questionnaire->setParams(170) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-24 16:09:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:09:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:09:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:09:41 --> Api\Controller_Questionnaire->index(80) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-24 16:09:41 --> Api\Controller_Questionnaire->index(84) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-24 16:09:41 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 16:09:41 --> brand/index called
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:09:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:09:41 --> company/index called
DEBUG - 2016-06-24 16:15:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:15:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:15:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:15:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:15:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:15:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:15:11 --> Api\Controller_Questionnaire->index(40) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-24 16:15:11 --> Api\Controller_Questionnaire->setParams(170) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-24 16:15:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:15:11 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:15:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:15:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:15:11 --> Api\Controller_Questionnaire->index(80) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-24 16:15:11 --> Api\Controller_Questionnaire->index(84) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-24 16:15:11 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:15:23 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:15:23 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 16:15:23 --> brand/index called
INFO - 2016-06-24 16:15:23 --> company/index called
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:15:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:15:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:15:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:15:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-24 16:15:23 --> store/index called
DEBUG - 2016-06-24 16:15:23 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:20:09 --> user/index called
INFO - 2016-06-24 16:20:09 --> brand/index called
INFO - 2016-06-24 16:20:09 --> company/index called
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:20:09 --> store/index called
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:20:09 --> store/index called
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:20:09 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:20:09 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:20:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:20:09 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:20:09 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:20:09 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 16:20:09 --> brand/index called
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:20:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:20:09 --> company/index called
DEBUG - 2016-06-24 16:22:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:22:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:22:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:22:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:22:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:22:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:22:15 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:22:15 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:22:15 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:22:15 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:22:15 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:22:15 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:22:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:22:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:22:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:22:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:22:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:22:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:22:16 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:22:16 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:22:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:22:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:22:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:22:16 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:34:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:34:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:34:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:34:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:34:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:34:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:34:30 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:34:30 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:34:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:34:30 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:34:30 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:34:30 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:34:30 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:34:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:34:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:34:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:34:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:34:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:34:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:34:31 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:34:31 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:34:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:34:31 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:34:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:34:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:34:31 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:34:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:34:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:34:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:34:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:34:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:34:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:34:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:34:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:34:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:34:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:34:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:34:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:34:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:34:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:34:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:34:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:34:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:34:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:34:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:34:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:34:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:34:41 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:34:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:34:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:34:41 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:34:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:34:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:34:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:34:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:34:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:34:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:34:43 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:34:43 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:34:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:34:43 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 16:34:43 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:34:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:34:43 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:54:17 --> company/index called
INFO - 2016-06-24 16:54:17 --> store/index called
INFO - 2016-06-24 16:54:17 --> user/index called
INFO - 2016-06-24 16:54:17 --> brand/index called
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:54:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:54:17 --> store/index called
DEBUG - 2016-06-24 16:54:18 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:54:18 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:54:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:54:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:54:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:54:18 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 16:54:18 --> brand/index called
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:54:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:54:18 --> company/index called
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:56:28 --> user/index called
INFO - 2016-06-24 16:56:28 --> store/index called
INFO - 2016-06-24 16:56:28 --> company/index called
INFO - 2016-06-24 16:56:28 --> brand/index called
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:56:28 --> store/index called
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:28 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:56:28 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:56:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:56:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:56:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:28 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:56:28 --> company/index called
INFO - 2016-06-24 16:56:28 --> brand/index called
DEBUG - 2016-06-24 16:56:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:30 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:56:30 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:56:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:56:30 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:56:30 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:56:30 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:56:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:56:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:56:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:56:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:56:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:56:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:56:51 --> company/index called
INFO - 2016-06-24 16:56:51 --> user/index called
INFO - 2016-06-24 16:56:51 --> brand/index called
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:56:51 --> store/index called
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:51 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:56:51 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 16:56:51 --> store/index called
DEBUG - 2016-06-24 16:56:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:56:51 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:56:51 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:56:51 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 16:56:51 --> brand/index called
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:56:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:56:51 --> company/index called
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:57:19 --> company/index called
INFO - 2016-06-24 16:57:19 --> brand/index called
INFO - 2016-06-24 16:57:19 --> store/index called
INFO - 2016-06-24 16:57:19 --> user/index called
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:57:19 --> store/index called
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:57:19 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:57:19 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:57:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:57:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:57:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:57:19 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 16:57:19 --> brand/index called
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 16:57:19 --> company/index called
DEBUG - 2016-06-24 16:57:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:57:22 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:57:22 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:57:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:57:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:57:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:57:22 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 16:57:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 16:57:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 16:57:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 16:57:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 16:57:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 16:57:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 16:57:28 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 16:57:28 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 16:57:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 16:57:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 16:57:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 16:57:28 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:03:16 --> brand/index called
INFO - 2016-06-24 17:03:16 --> company/index called
INFO - 2016-06-24 17:03:16 --> store/index called
INFO - 2016-06-24 17:03:16 --> user/index called
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:03:16 --> store/index called
DEBUG - 2016-06-24 17:03:16 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:16 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:16 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:03:16 --> brand/index called
INFO - 2016-06-24 17:03:16 --> company/index called
DEBUG - 2016-06-24 17:03:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:19 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:19 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:19 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:24 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:24 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:24 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:26 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:26 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:26 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:26 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:27 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:29 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:29 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:29 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:40 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:40 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:40 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:41 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:43 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:43 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:43 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:43 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:45 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:45 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:45 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:50 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:50 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:50 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:50 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:50 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:03:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:03:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:03:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:03:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:03:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:03:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:03:51 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:03:51 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:03:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:03:51 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:03:51 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:03:51 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:32 --> company/index called
INFO - 2016-06-24 17:05:32 --> store/index called
INFO - 2016-06-24 17:05:32 --> user/index called
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 17:05:32 --> brand/index called
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:32 --> store/index called
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:05:32 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:05:32 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:05:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:05:33 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:05:33 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:33 --> brand/index called
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:33 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:33 --> company/index called
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:42 --> brand/index called
INFO - 2016-06-24 17:05:42 --> user/index called
INFO - 2016-06-24 17:05:42 --> company/index called
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:43 --> store/index called
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:43 --> store/index called
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:05:43 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:05:43 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:05:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:05:43 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:05:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:43 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:43 --> brand/index called
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:05:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:05:43 --> company/index called
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:07:24 --> brand/index called
INFO - 2016-06-24 17:07:24 --> store/index called
INFO - 2016-06-24 17:07:24 --> user/index called
INFO - 2016-06-24 17:07:24 --> company/index called
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:07:24 --> store/index called
DEBUG - 2016-06-24 17:07:24 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 17:07:24 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 17:07:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 17:07:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 17:07:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 17:07:24 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 17:07:24 --> brand/index called
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 17:07:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 17:07:24 --> company/index called
DEBUG - 2016-06-24 18:33:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:33:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:33:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:33:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:33:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:33:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:33:21 --> Api\Controller_Coupon->index(40) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:33:21 --> Api\Controller_Coupon->setParams(158) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:33:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:33:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:33:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:33:21 --> Api\Controller_Coupon->index(89) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:44:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:44:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:44:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:44:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:44:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:44:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:44:11 --> Api\Controller_Daily_Store->index(22) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-24 18:44:11 --> Api\Controller_Daily_Store->setParams(79) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-24 18:44:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:44:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:44:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:44:11 --> Api\Controller_Daily_Store->index(71) - 【DAILY STORE API】:END
DEBUG - 2016-06-24 18:47:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:47:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:47:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:47:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:47:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:47:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:47:54 --> Api\Controller_Daily_Store->index(22) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-24 18:47:54 --> Api\Controller_Daily_Store->setParams(79) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-24 18:47:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:47:54 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:47:54 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:47:54 --> Api\Controller_Daily_Store->index(71) - 【DAILY STORE API】:END
DEBUG - 2016-06-24 18:49:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:49:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:49:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:49:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:49:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:49:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:49:49 --> Api\Controller_Coupon->index(40) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:49:49 --> Api\Controller_Coupon->setParams(158) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:49:49 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:49:49 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:49:49 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:49:49 --> Api\Controller_Coupon->index(89) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:50:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:50:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:50:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:50:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:50:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:50:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:50:07 --> Api\Controller_Daily_Store->index(22) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-24 18:50:07 --> Api\Controller_Daily_Store->setParams(79) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-24 18:50:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:50:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:50:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:50:07 --> Api\Controller_Daily_Store->index(71) - 【DAILY STORE API】:END
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:56:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 18:56:41 --> user/index called
INFO - 2016-06-24 18:56:41 --> company/index called
INFO - 2016-06-24 18:56:41 --> brand/index called
INFO - 2016-06-24 18:56:41 --> store/index called
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 18:57:06 --> store/index called
INFO - 2016-06-24 18:57:06 --> company/index called
INFO - 2016-06-24 18:57:06 --> user/index called
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 18:57:06 --> brand/index called
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
INFO - 2016-06-24 18:57:08 --> store/index called
INFO - 2016-06-24 18:57:08 --> company/index called
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 18:57:08 --> brand/index called
INFO - 2016-06-24 18:57:08 --> user/index called
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 18:57:22 --> company/index called
INFO - 2016-06-24 18:57:22 --> store/index called
INFO - 2016-06-24 18:57:22 --> user/index called
INFO - 2016-06-24 18:57:22 --> brand/index called
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 18:57:22 --> store/index called
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:22 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:57:22 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:57:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:57:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:57:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:23 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
INFO - 2016-06-24 18:57:23 --> brand/index called
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 18:57:23 --> company/index called
DEBUG - 2016-06-24 18:57:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:57:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:57:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:57:36 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 18:57:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:57:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:57:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:57:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:40 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:57:40 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:57:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:57:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 18:57:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:57:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:57:40 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:57:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:57:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:57:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:57:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:57:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:57:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:57:42 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:57:42 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:57:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:57:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:57:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:57:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:58:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:58:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:58:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:58:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:58:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:58:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:58:05 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:58:05 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:58:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:58:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:58:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:58:05 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:58:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:58:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:58:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:58:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:58:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:58:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:58:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:58:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:58:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:58:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:58:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:58:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:58:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:58:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:58:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:58:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:58:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:58:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:58:22 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:58:22 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:58:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:58:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:58:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:58:22 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:58:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:58:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:58:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:58:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:58:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:58:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:58:24 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:58:24 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:58:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:58:24 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 18:58:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:58:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:58:24 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 18:58:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 18:58:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 18:58:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 18:58:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 18:58:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 18:58:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 18:58:27 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 18:58:27 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 18:58:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 18:58:27 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 18:58:27 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 18:58:27 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 18:58:27 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:08:57 --> company/index called
INFO - 2016-06-24 19:08:57 --> store/index called
INFO - 2016-06-24 19:08:57 --> user/index called
INFO - 2016-06-24 19:08:57 --> brand/index called
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:08:57 --> store/index called
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:08:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:08:58 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:08:58 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:08:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:08:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:08:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 19:08:58 --> brand/index called
DEBUG - 2016-06-24 19:08:58 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:08:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:08:58 --> company/index called
DEBUG - 2016-06-24 19:09:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:09:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:09:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:09:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:09:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:09:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:09:05 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:09:05 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:09:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:09:05 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:09:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:09:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:09:05 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:09:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:09:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:09:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:09:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:09:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:09:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:09:13 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:09:13 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:09:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:09:13 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:09:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:09:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:09:13 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:09:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:09:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:09:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:09:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:09:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:09:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:09:15 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:09:15 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:09:15 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:09:15 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:09:15 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:09:15 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:09:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:09:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:09:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:09:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:09:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:09:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:09:21 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:09:21 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:09:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:09:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:09:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:09:21 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:13:23 --> company/index called
INFO - 2016-06-24 19:13:23 --> brand/index called
INFO - 2016-06-24 19:13:23 --> store/index called
INFO - 2016-06-24 19:13:23 --> user/index called
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:13:24 --> store/index called
DEBUG - 2016-06-24 19:13:24 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:13:24 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:13:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:13:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:13:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:13:24 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
INFO - 2016-06-24 19:13:24 --> brand/index called
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:13:24 --> company/index called
DEBUG - 2016-06-24 19:13:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:13:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:13:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:13:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:13:36 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:13:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:13:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:13:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:13:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:13:38 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:13:38 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:13:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:13:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:13:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:13:38 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:13:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:13:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:13:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:13:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:13:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:13:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:13:46 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:13:46 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:13:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:13:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:13:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:13:46 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:16:25 --> user/index called
INFO - 2016-06-24 19:16:25 --> brand/index called
INFO - 2016-06-24 19:16:25 --> company/index called
INFO - 2016-06-24 19:16:25 --> store/index called
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:16:25 --> store/index called
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:16:25 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:16:25 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:16:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:16:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:16:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:25 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:16:25 --> brand/index called
INFO - 2016-06-24 19:16:25 --> company/index called
DEBUG - 2016-06-24 19:16:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:16:33 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:16:33 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:16:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:16:33 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:16:33 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:16:33 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:16:33 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:16:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:16:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:16:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:16:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:16:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:16:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:16:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:16:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:16:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:16:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:16:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:16:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:16:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:16:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:16:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:16:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:16:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:16:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:16:41 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:17:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:25 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:17:25 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:17:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:17:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:17:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:17:25 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:17:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:26 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:17:26 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:17:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:17:26 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:17:26 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:17:26 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:17:32 --> user/index called
INFO - 2016-06-24 19:17:32 --> store/index called
INFO - 2016-06-24 19:17:32 --> company/index called
INFO - 2016-06-24 19:17:32 --> brand/index called
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:17:32 --> store/index called
INFO - 2016-06-24 19:17:32 --> brand/index called
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 19:17:32 --> company/index called
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:32 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:17:32 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:17:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:17:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:17:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:17:33 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:17:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:54 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:17:54 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:17:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:17:54 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:17:54 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:17:54 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:17:54 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:17:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:55 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:17:55 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:17:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:17:55 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:17:55 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:17:55 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:17:55 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:17:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:17:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:17:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:17:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:17:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:17:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:17:59 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:17:59 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:17:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:17:59 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:17:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:17:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:17:59 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:02 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:02 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:02 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:02 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:06 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:06 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:06 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:06 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:06 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:06 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:07 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:07 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:07 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:07 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:08 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:09 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:09 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:35 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:35 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:35 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:35 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:18:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:18:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:18:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:18:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:18:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:18:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:18:43 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:18:43 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:18:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:18:43 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:18:43 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:18:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:18:43 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:20:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:20:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:20:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:20:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:20:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:20:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:20:01 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:20:01 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:20:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:20:01 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:20:01 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:20:01 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:20:01 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:20:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:20:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:20:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:20:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:20:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:20:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:20:02 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:20:02 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:20:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:20:02 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:20:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:20:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:20:02 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:21:54 --> brand/index called
INFO - 2016-06-24 19:21:54 --> company/index called
INFO - 2016-06-24 19:21:54 --> store/index called
INFO - 2016-06-24 19:21:54 --> user/index called
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:21:54 --> store/index called
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:21:54 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:21:54 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:21:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:21:54 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:21:54 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:21:54 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:21:54 --> brand/index called
INFO - 2016-06-24 19:21:54 --> company/index called
DEBUG - 2016-06-24 19:22:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:22:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:22:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:22:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:22:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:22:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:22:17 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:22:17 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:22:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:22:17 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:22:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:22:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:22:17 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:22:19 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:22:19 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:22:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:22:19 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:22:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:22:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:22:19 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:22:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:22:19 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:22:19 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:22:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:22:19 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:22:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:22:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:22:19 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:22:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:22:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:22:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:22:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:22:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:22:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:22:26 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:22:26 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:22:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:22:26 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:22:26 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:22:26 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:22:26 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:27:43 --> brand/index called
INFO - 2016-06-24 19:27:43 --> company/index called
INFO - 2016-06-24 19:27:43 --> user/index called
INFO - 2016-06-24 19:27:43 --> store/index called
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:27:43 --> store/index called
DEBUG - 2016-06-24 19:27:43 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:27:43 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:27:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:27:43 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:27:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:27:43 --> brand/index called
INFO - 2016-06-24 19:27:43 --> company/index called
DEBUG - 2016-06-24 19:27:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:27:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:27:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:27:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:27:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:27:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:27:46 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:27:46 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:27:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:27:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:27:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:27:46 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:28:02 --> store/index called
INFO - 2016-06-24 19:28:02 --> company/index called
INFO - 2016-06-24 19:28:02 --> brand/index called
INFO - 2016-06-24 19:28:02 --> user/index called
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:28:02 --> store/index called
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:28:02 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:28:02 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:28:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:28:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:28:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:28:02 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:28:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:28:02 --> brand/index called
INFO - 2016-06-24 19:28:02 --> company/index called
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:35:22 --> user/index called
INFO - 2016-06-24 19:35:22 --> company/index called
INFO - 2016-06-24 19:35:22 --> store/index called
INFO - 2016-06-24 19:35:22 --> brand/index called
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:35:22 --> store/index called
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:35:22 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:35:22 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:35:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:35:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:35:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:22 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:35:22 --> brand/index called
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:35:22 --> company/index called
DEBUG - 2016-06-24 19:35:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:35:46 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:35:46 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:35:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:35:46 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:35:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:35:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:35:46 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:35:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:35:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:35:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:35:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:35:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:35:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:35:55 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:35:55 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:35:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:35:55 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:35:55 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:35:55 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:38:15 --> brand/index called
INFO - 2016-06-24 19:38:15 --> company/index called
INFO - 2016-06-24 19:38:15 --> store/index called
INFO - 2016-06-24 19:38:15 --> user/index called
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:38:15 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:38:15 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 19:38:15 --> store/index called
DEBUG - 2016-06-24 19:38:15 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:38:15 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:38:15 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:15 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 19:38:15 --> brand/index called
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:38:15 --> company/index called
DEBUG - 2016-06-24 19:38:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:38:34 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:38:34 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:38:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:38:34 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:38:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:38:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:38:34 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:38:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:38:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:38:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:38:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:38:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:38:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:38:38 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:38:38 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:38:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:38:38 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:38:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:38:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:38:38 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:39:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:39:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:39:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:39:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:39:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:39:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:39:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:39:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:39:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:39:37 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:39:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:39:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:39:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:39:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:39:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:39:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:39:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:39:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:39:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:39:44 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:39:44 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:39:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:39:44 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:39:44 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:39:44 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:39:44 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:39:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:39:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:39:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:39:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:39:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:39:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:39:49 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:39:49 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:39:49 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:39:49 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:39:49 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:39:49 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:39:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:39:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:39:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:39:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:39:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:39:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:39:57 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:39:57 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:39:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:39:57 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:39:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:39:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:39:57 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:44:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:44:31 --> company/index called
INFO - 2016-06-24 19:44:31 --> store/index called
INFO - 2016-06-24 19:44:31 --> brand/index called
INFO - 2016-06-24 19:44:31 --> user/index called
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
INFO - 2016-06-24 19:44:31 --> store/index called
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:31 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:44:31 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:44:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:44:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:44:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:31 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:44:31 --> brand/index called
INFO - 2016-06-24 19:44:31 --> company/index called
DEBUG - 2016-06-24 19:44:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:52 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:44:52 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:44:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:44:52 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:44:52 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:44:52 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:44:52 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:44:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:53 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:44:53 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:44:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:44:53 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:44:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:44:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:44:53 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:44:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:44:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:44:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:44:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:44:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:44:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:44:59 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:44:59 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:44:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:44:59 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:44:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:44:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:44:59 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:45:00 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:45:00 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:45:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:45:00 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:45:00 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:45:00 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:45:00 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:45:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:45:00 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:45:00 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:45:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:45:00 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:45:00 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:45:00 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:45:00 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:45:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:45:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:45:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:45:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:45:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:45:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:45:07 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:45:07 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:45:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:45:07 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:45:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:45:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:45:07 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:45:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:45:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:45:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:45:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:45:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:45:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:45:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:45:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:45:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:45:41 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:45:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:45:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:45:41 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:45:42 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:45:42 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:45:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:45:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:45:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:45:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:45:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:45:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:45:42 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:45:42 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:45:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:45:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:45:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:45:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:45:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:45:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:45:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:45:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:45:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:45:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:45:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:45:43 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:45:43 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:45:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:45:43 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:45:43 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:45:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:45:43 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:11 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:11 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:11 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:11 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:13 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:47:16 --> company/index called
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:47:16 --> store/index called
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 19:47:16 --> brand/index called
INFO - 2016-06-24 19:47:16 --> user/index called
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:16 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:17 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 19:47:17 --> store/index called
DEBUG - 2016-06-24 19:47:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:17 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 19:47:17 --> brand/index called
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:47:17 --> company/index called
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:35 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:35 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:35 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:35 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:35 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:35 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:35 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:35 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:47:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:47:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:47:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:48:29 --> store/index called
INFO - 2016-06-24 19:48:29 --> brand/index called
INFO - 2016-06-24 19:48:29 --> company/index called
INFO - 2016-06-24 19:48:29 --> user/index called
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:29 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:48:29 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 19:48:29 --> store/index called
DEBUG - 2016-06-24 19:48:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:48:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:48:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:48:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:30 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 19:48:30 --> brand/index called
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:48:30 --> company/index called
DEBUG - 2016-06-24 19:48:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:48:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:48:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:48:37 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:48:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:48:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:48:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:48:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:48:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:48:38 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:51:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:51:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:51:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:51:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:51:16 --> brand/index called
INFO - 2016-06-24 19:51:16 --> company/index called
INFO - 2016-06-24 19:51:16 --> user/index called
INFO - 2016-06-24 19:51:16 --> store/index called
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:51:16 --> store/index called
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:51:16 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:51:16 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:51:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:51:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:51:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:51:16 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:51:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:51:16 --> company/index called
INFO - 2016-06-24 19:51:16 --> brand/index called
DEBUG - 2016-06-24 19:53:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:33 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:53:33 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:53:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:53:33 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:53:33 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:53:33 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:53:36 --> user/index called
INFO - 2016-06-24 19:53:36 --> store/index called
INFO - 2016-06-24 19:53:36 --> brand/index called
INFO - 2016-06-24 19:53:36 --> store/index called
INFO - 2016-06-24 19:53:36 --> company/index called
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:53:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:53:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:53:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:53:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:53:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:53:37 --> company/index called
INFO - 2016-06-24 19:53:37 --> brand/index called
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:53:41 --> store/index called
INFO - 2016-06-24 19:53:41 --> brand/index called
INFO - 2016-06-24 19:53:41 --> user/index called
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 19:53:41 --> company/index called
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:53:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 19:53:41 --> store/index called
DEBUG - 2016-06-24 19:53:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:53:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:53:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:53:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:53:42 --> brand/index called
INFO - 2016-06-24 19:53:42 --> company/index called
DEBUG - 2016-06-24 19:54:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:54:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:54:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:54:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:54:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:54:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:54:08 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:54:08 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:54:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:54:08 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:54:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:54:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:54:08 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:54:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:54:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:54:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:54:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:54:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:54:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:54:20 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:54:20 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:54:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:54:20 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:54:20 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:54:20 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:54:20 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:54:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:54:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:54:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:54:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:54:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:54:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:54:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:54:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:54:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:54:37 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:54:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:54:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:54:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:55:35 --> company/index called
INFO - 2016-06-24 19:55:35 --> user/index called
INFO - 2016-06-24 19:55:35 --> store/index called
INFO - 2016-06-24 19:55:35 --> brand/index called
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:55:35 --> store/index called
DEBUG - 2016-06-24 19:55:35 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:35 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:55:36 --> company/index called
INFO - 2016-06-24 19:55:36 --> brand/index called
DEBUG - 2016-06-24 19:55:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:55 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:55 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:55 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:55 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:55 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:55 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:56 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:56 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:56 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:56 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:57 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:58 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:55:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:55:59 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:56:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:17 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:56:17 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:56:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:56:17 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:56:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:56:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:56:17 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:56:18 --> user/index called
INFO - 2016-06-24 19:56:18 --> company/index called
INFO - 2016-06-24 19:56:18 --> brand/index called
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 19:56:18 --> store/index called
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:56:18 --> store/index called
DEBUG - 2016-06-24 19:56:18 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:56:18 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:56:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:56:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:56:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:18 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 19:56:18 --> brand/index called
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:56:18 --> company/index called
DEBUG - 2016-06-24 19:56:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:32 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:56:32 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:56:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:56:32 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:56:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:56:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:56:32 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:56:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:40 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:56:40 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:56:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:56:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:56:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:56:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:56:40 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:56:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:46 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:56:46 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:56:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:56:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:56:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:56:46 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:56:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:56:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:56:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:56:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:56:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:56:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:56:55 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:56:55 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:56:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:56:55 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:56:55 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:56:55 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:58:47 --> brand/index called
INFO - 2016-06-24 19:58:47 --> company/index called
INFO - 2016-06-24 19:58:47 --> store/index called
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 19:58:47 --> user/index called
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:58:47 --> store/index called
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:58:47 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:58:47 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:58:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:58:47 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:58:47 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:58:47 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 19:58:47 --> brand/index called
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:58:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 19:58:47 --> company/index called
DEBUG - 2016-06-24 19:59:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:59:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:59:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:59:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:59:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:59:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:59:12 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:59:12 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:59:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:59:12 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 19:59:12 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:59:12 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:59:12 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:59:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:59:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:59:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:59:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:59:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:59:14 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:59:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:59:14 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:59:14 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:59:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:59:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:59:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:59:15 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:59:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:59:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:59:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:59:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:59:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:59:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:59:17 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:59:17 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:59:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:59:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:59:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:59:17 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 19:59:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 19:59:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 19:59:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 19:59:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 19:59:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 19:59:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 19:59:21 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 19:59:21 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 19:59:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 19:59:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 19:59:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 19:59:21 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:00:02 --> user/index called
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:00:02 --> company/index called
INFO - 2016-06-24 20:00:02 --> brand/index called
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:00:02 --> store/index called
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:00:02 --> store/index called
DEBUG - 2016-06-24 20:00:02 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:00:02 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:00:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:00:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:00:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:02 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:00:02 --> brand/index called
INFO - 2016-06-24 20:00:02 --> company/index called
DEBUG - 2016-06-24 20:00:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:00:12 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:00:12 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:00:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:00:12 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:00:12 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:00:12 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:00:12 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:00:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:00:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:00:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:00:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:00:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:00:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:00:23 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:00:23 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:00:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:00:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:00:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:00:23 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:03:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:35 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:03:35 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:03:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:03:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:03:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:03:35 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:38 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
INFO - 2016-06-24 20:03:38 --> store/index called
DEBUG - 2016-06-24 20:03:38 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 20:03:38 --> brand/index called
INFO - 2016-06-24 20:03:38 --> store/index called
DEBUG - 2016-06-24 20:03:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:03:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
INFO - 2016-06-24 20:03:38 --> user/index called
INFO - 2016-06-24 20:03:38 --> company/index called
DEBUG - 2016-06-24 20:03:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:03:39 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:03:39 --> brand/index called
INFO - 2016-06-24 20:03:39 --> company/index called
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:03:41 --> company/index called
INFO - 2016-06-24 20:03:41 --> brand/index called
INFO - 2016-06-24 20:03:41 --> user/index called
INFO - 2016-06-24 20:03:41 --> store/index called
INFO - 2016-06-24 20:03:41 --> store/index called
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:03:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:03:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:03:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:03:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:03:41 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:03:41 --> brand/index called
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:03:41 --> company/index called
DEBUG - 2016-06-24 20:04:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:04:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:04:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:04:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:04:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:04:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:04:00 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:04:00 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:04:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:04:00 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:04:00 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:04:00 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:04:00 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:04:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:04:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:04:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:04:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:04:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:04:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:04:19 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:04:19 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:04:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:04:19 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:04:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:04:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:04:19 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:04:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:04:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:04:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:04:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:04:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:04:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:04:25 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:04:25 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:04:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:04:25 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:04:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:04:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:04:25 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:04:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:04:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:04:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:04:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:04:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:04:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:04:37 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:04:37 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:04:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:04:37 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:04:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:04:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:04:37 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:04:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:04:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:04:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:04:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:04:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:04:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:04:54 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:04:54 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:04:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:04:54 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:04:54 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:04:54 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:04:54 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:05:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:05:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:05:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:05:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:05:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:05:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:05:10 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:05:10 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:05:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:05:10 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:05:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:05:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:05:10 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:07:05 --> user/index called
INFO - 2016-06-24 20:07:05 --> store/index called
INFO - 2016-06-24 20:07:05 --> company/index called
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:07:05 --> brand/index called
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:07:05 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:07:05 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 20:07:05 --> store/index called
DEBUG - 2016-06-24 20:07:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:07:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:07:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:05 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:07:05 --> brand/index called
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:07:05 --> company/index called
DEBUG - 2016-06-24 20:07:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:07:25 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:07:25 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:07:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:07:25 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:07:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:07:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:07:25 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:07:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:07:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:07:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:07:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:07:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:07:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:07:31 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:07:31 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:07:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:07:31 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:07:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:07:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:07:31 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:08:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:08:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:08:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:08:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:08:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:08:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:08:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:08:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:08:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:08:41 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:08:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:08:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:08:41 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:11:48 --> user/index called
INFO - 2016-06-24 20:11:48 --> brand/index called
INFO - 2016-06-24 20:11:48 --> store/index called
INFO - 2016-06-24 20:11:48 --> company/index called
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:11:48 --> store/index called
DEBUG - 2016-06-24 20:11:48 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:11:48 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:11:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:11:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:11:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:11:48 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
INFO - 2016-06-24 20:11:48 --> brand/index called
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:11:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:11:48 --> company/index called
DEBUG - 2016-06-24 20:12:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:12:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:12:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:12:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:12:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:12:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:12:01 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:12:01 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:12:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:12:01 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:12:01 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:12:01 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:12:01 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:14:47 --> company/index called
INFO - 2016-06-24 20:14:47 --> user/index called
INFO - 2016-06-24 20:14:47 --> brand/index called
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:14:47 --> store/index called
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:14:47 --> store/index called
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:14:47 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:14:47 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:14:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:14:47 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:14:47 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:14:47 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:14:47 --> brand/index called
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:14:47 --> company/index called
DEBUG - 2016-06-24 20:14:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:14:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:14:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:14:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:14:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:14:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:14:53 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:14:53 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:14:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:14:53 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:14:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:14:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:14:53 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:15:55 --> user/index called
INFO - 2016-06-24 20:15:55 --> store/index called
INFO - 2016-06-24 20:15:55 --> company/index called
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:15:55 --> brand/index called
DEBUG - 2016-06-24 20:15:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:15:56 --> store/index called
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:15:56 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:15:56 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:15:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:15:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:15:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:15:56 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:15:56 --> brand/index called
INFO - 2016-06-24 20:15:56 --> company/index called
DEBUG - 2016-06-24 20:15:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:15:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:15:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:15:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:15:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:15:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:15:59 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:15:59 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:15:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:15:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:15:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:15:59 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:16:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:16:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:16:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:16:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:16:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:16:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:16:10 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:16:10 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:16:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:16:10 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:16:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:16:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:16:10 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:16:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:16:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:16:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:16:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:16:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:16:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:16:19 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:16:19 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:16:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:16:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:16:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:16:19 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:17:20 --> store/index called
INFO - 2016-06-24 20:17:20 --> user/index called
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:17:20 --> company/index called
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:17:20 --> brand/index called
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:17:20 --> store/index called
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:21 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:17:21 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:17:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:17:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:17:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:17:21 --> brand/index called
INFO - 2016-06-24 20:17:21 --> company/index called
DEBUG - 2016-06-24 20:17:21 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:17:22 --> brand/index called
INFO - 2016-06-24 20:17:22 --> company/index called
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:17:22 --> store/index called
INFO - 2016-06-24 20:17:22 --> user/index called
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:22 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:17:22 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 20:17:22 --> store/index called
DEBUG - 2016-06-24 20:17:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:17:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:17:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:17:22 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:17:22 --> company/index called
INFO - 2016-06-24 20:17:22 --> brand/index called
DEBUG - 2016-06-24 20:17:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:44 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:17:44 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:17:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:17:44 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:17:44 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:17:44 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:17:44 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:17:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:17:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:17:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:17:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:17:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:17:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:17:59 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:17:59 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:17:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:17:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:17:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:17:59 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:11 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:11 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:11 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:24 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:24 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:24 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:18:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:24 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:28 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:28 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:28 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:42 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:42 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:18:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:18:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:18:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:18:53 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:25:03 --> store/index called
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
INFO - 2016-06-24 20:25:03 --> company/index called
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
INFO - 2016-06-24 20:25:03 --> user/index called
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:25:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:25:03 --> brand/index called
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:25:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:25:07 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:25:07 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 20:25:07 --> brand/index called
INFO - 2016-06-24 20:25:07 --> company/index called
DEBUG - 2016-06-24 20:25:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:25:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:25:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-24 20:25:07 --> store/index called
DEBUG - 2016-06-24 20:25:07 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:26:51 --> company/index called
INFO - 2016-06-24 20:26:51 --> user/index called
INFO - 2016-06-24 20:26:51 --> brand/index called
INFO - 2016-06-24 20:26:51 --> store/index called
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:26:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:26:51 --> store/index called
DEBUG - 2016-06-24 20:26:51 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:26:51 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:26:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:26:51 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:26:51 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:26:52 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:26:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:26:52 --> brand/index called
INFO - 2016-06-24 20:26:52 --> company/index called
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:27:39 --> brand/index called
INFO - 2016-06-24 20:27:39 --> user/index called
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:27:39 --> company/index called
INFO - 2016-06-24 20:27:39 --> store/index called
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:27:39 --> store/index called
DEBUG - 2016-06-24 20:27:39 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:27:39 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:27:39 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:27:39 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:27:39 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:39 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:27:39 --> company/index called
INFO - 2016-06-24 20:27:39 --> brand/index called
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:27:55 --> brand/index called
INFO - 2016-06-24 20:27:55 --> user/index called
INFO - 2016-06-24 20:27:55 --> store/index called
INFO - 2016-06-24 20:27:55 --> company/index called
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:27:56 --> store/index called
DEBUG - 2016-06-24 20:27:56 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:27:56 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:27:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:27:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:27:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:56 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:27:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:27:56 --> brand/index called
INFO - 2016-06-24 20:27:56 --> company/index called
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:30:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:30:16 --> company/index called
INFO - 2016-06-24 20:30:16 --> store/index called
INFO - 2016-06-24 20:30:17 --> user/index called
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:30:17 --> brand/index called
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:30:17 --> store/index called
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:30:17 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:30:17 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:30:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:30:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:30:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:30:17 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:30:17 --> brand/index called
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:30:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:30:17 --> company/index called
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:40:54 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-24 20:40:54 --> user/index called
INFO - 2016-06-24 20:40:54 --> store/index called
DEBUG - 2016-06-24 20:40:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:40:54 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
INFO - 2016-06-24 20:40:54 --> brand/index called
DEBUG - 2016-06-24 20:40:54 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-24 20:40:54 --> store/index called
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:40:54 --> company/index called
DEBUG - 2016-06-24 20:40:54 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:40:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:40:54 --> company/index called
INFO - 2016-06-24 20:40:54 --> brand/index called
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:41:41 --> company/index called
INFO - 2016-06-24 20:41:41 --> brand/index called
INFO - 2016-06-24 20:41:41 --> store/index called
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-24 20:41:41 --> user/index called
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:41:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:41:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:41:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:41:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:41:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:41:41 --> store/index called
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:41:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:41:42 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:41:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:41:42 --> brand/index called
INFO - 2016-06-24 20:41:42 --> company/index called
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:42:38 --> user/index called
INFO - 2016-06-24 20:42:38 --> brand/index called
INFO - 2016-06-24 20:42:38 --> company/index called
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:42:38 --> store/index called
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:42:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:42:38 --> store/index called
DEBUG - 2016-06-24 20:42:38 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:42:38 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:42:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:42:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:42:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:42:39 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:42:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:42:39 --> brand/index called
INFO - 2016-06-24 20:42:39 --> company/index called
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:43:12 --> company/index called
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:43:12 --> store/index called
INFO - 2016-06-24 20:43:12 --> brand/index called
INFO - 2016-06-24 20:43:12 --> user/index called
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:43:12 --> store/index called
DEBUG - 2016-06-24 20:43:12 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:43:12 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:43:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:43:12 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:43:12 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:43:12 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:43:12 --> brand/index called
INFO - 2016-06-24 20:43:12 --> company/index called
DEBUG - 2016-06-24 20:43:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:43:16 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:43:16 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:43:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:43:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:43:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:43:16 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:43:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:43:24 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:43:24 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:43:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:43:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:43:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:43:24 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:43:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:43:28 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:43:28 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:43:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:43:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:43:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:43:28 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:43:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:43:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:43:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:43:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:43:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:43:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:43:34 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:43:34 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:43:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:43:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:43:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:43:34 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:44:28 --> user/index called
INFO - 2016-06-24 20:44:28 --> store/index called
INFO - 2016-06-24 20:44:28 --> brand/index called
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:44:28 --> company/index called
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:44:28 --> store/index called
DEBUG - 2016-06-24 20:44:28 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:44:28 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:44:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:44:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:44:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:28 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:44:28 --> brand/index called
INFO - 2016-06-24 20:44:28 --> company/index called
DEBUG - 2016-06-24 20:44:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:44:36 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:44:36 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:44:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:44:36 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:44:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:44:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:44:36 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:44:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:44:40 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:44:40 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:44:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:44:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:44:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:44:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:44:40 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:44:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:44:41 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:44:41 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:44:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:44:41 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:44:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:44:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:44:41 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:44:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:44:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:44:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:44:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:44:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:44:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:44:46 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:44:46 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:44:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:44:46 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:44:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:44:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:44:46 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:45:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:45:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:45:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:45:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:45:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:45:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:45:07 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:45:07 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:45:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:45:07 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:45:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:45:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:45:07 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:45:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:45:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:45:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:45:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:45:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:45:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:45:09 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:45:09 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:45:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:45:09 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:45:09 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:45:09 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:45:09 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:45:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:45:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:45:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:45:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:45:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:45:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:45:17 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:45:17 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:45:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:45:17 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-24 20:45:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:45:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:45:17 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:46:16 --> user/index called
INFO - 2016-06-24 20:46:16 --> brand/index called
INFO - 2016-06-24 20:46:16 --> company/index called
INFO - 2016-06-24 20:46:16 --> store/index called
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:16 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:46:16 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:46:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
INFO - 2016-06-24 20:46:16 --> store/index called
DEBUG - 2016-06-24 20:46:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:46:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:46:16 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-24 20:46:16 --> brand/index called
INFO - 2016-06-24 20:46:16 --> company/index called
DEBUG - 2016-06-24 20:46:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:18 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:46:18 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:46:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:46:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:46:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:46:18 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:46:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:22 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:46:22 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:46:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:46:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:46:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:46:22 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:46:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:25 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:46:25 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:46:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:46:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:46:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:46:25 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:46:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:27 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:46:27 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:46:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:46:27 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:46:27 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:46:27 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-24 20:46:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-24 20:46:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-24 20:46:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-24 20:46:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-24 20:46:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-24 20:46:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-24 20:46:32 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-24 20:46:32 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-24 20:46:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-24 20:46:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-24 20:46:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-24 20:46:32 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
