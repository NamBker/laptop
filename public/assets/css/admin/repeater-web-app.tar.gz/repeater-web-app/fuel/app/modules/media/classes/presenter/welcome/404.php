<?php
namespace Media;
class Presenter_404 extends \Presenter
{

	public function view()
	{
		\Additional_Log::debug("start.");
	}

}
