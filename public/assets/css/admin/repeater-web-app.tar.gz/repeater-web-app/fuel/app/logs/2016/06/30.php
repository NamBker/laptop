<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-06-30 00:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:22:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-30 00:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:22:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:22:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-30 00:22:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:22:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:22:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:23:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:23:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:23:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:25:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:26:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:26:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:26:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:27:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:27:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:27:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:27:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:27:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:27:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:27:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:27:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:28:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:28:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:28:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:28:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:28:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:28:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:31:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:32:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:32:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:32:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:33:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:33:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:33:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:33:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:33:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:33:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:33:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:33:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:33:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:42:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:42:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:42:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:42:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:42:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:42:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:43:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:43:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:43:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:43:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:43:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:43:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:44:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:44:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:44:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:44:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:44:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:44:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:44:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:44:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:44:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:44:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:44:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:44:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:50:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:50:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:50:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:50:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:51:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:51:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:51:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:51:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:51:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:51:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:51:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:51:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:51:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:51:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:51:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:51:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:51:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:51:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:51:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:55:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:55:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:55:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:55:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:55:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:55:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:55:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:55:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 00:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 00:56:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 00:56:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:56:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:56:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:56:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 00:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 01:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:02:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 01:02:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 01:02:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 01:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:03:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:03:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 01:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 01:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:04:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 01:04:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 01:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 01:05:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:05:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:05:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:05:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:05:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:05:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:06:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:06:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:06:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:06:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:06:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:06:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:10:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:10:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:10:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:10:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:10:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:10:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 01:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 01:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 01:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:44:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-30 10:44:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-30 10:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:44:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:44:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:44:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:46:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:46:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:47:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:47:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:47:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:47:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:47:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:47:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:55:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:55:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:55:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:55:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:55:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:56:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:56:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 10:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 10:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 10:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 10:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 10:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:08:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:08:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:08:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:08:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:08:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:08:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:08:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:08:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:08:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:08:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:08:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:08:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:08:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:08:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:08:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:08:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:08:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:08:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:11:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:11:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:11:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:11:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:11:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:11:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:11:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:11:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:12:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:12:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:13:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:13:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:13:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:13:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:13:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:13:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:14:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:14:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:14:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:14:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:15:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:15:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:15:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:15:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:15:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:15:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:16:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:16:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:16:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:16:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:16:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:16:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:16:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:16:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:16:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:16:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:16:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:16:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:16:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:17:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:17:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:17:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:18:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:18:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:18:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:18:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:19:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:19:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:19:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:19:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:19:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:19:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:21:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:22:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:22:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:22:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:22:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:22:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:22:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:23:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:23:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:23:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:23:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:23:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:23:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:23:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:23:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:23:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:24:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:24:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:24:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:24:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:24:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:24:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:24:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:24:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:24:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:37:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:37:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:37:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:37:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:37:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:37:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:37:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:37:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:37:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:37:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:37:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:40:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:40:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:40:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:40:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:41:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:41:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:42:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:42:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:42:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:42:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:42:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:42:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:42:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:42:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:42:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:43:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:43:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:43:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:46:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:46:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:47:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:47:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:47:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:47:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:49:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:49:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:49:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:49:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:49:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:51:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:51:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:51:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 11:51:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 11:51:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:02:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:02:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:02:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:02:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:02:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:05:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:05:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:08:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:08:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:08:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:08:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:08:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:08:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:08:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:08:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:08:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:08:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:08:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:08:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:08:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:08:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:08:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:10:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:10:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:10:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:10:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:10:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:10:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:10:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:10:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:10:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:10:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:10:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:10:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:10:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:10:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:10:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:11:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:11:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:11:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:11:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:11:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:11:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:14:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:14:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:14:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:15:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:15:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:15:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:16:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:16:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:16:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:16:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:16:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:16:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:18:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:18:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:18:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:18:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:18:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:21:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:21:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:21:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:21:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:21:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:21:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:28:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:28:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:28:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:28:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:30:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:30:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:30:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:31:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:31:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:31:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:31:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:31:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:32:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:32:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:32:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:32:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:32:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:32:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:32:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:32:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:32:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:32:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:32:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:32:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:32:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:32:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:32:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:32:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:32:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:33:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:33:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:33:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:37:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:37:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:37:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:37:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:42:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:42:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:42:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:42:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:43:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:43:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:43:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:43:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:43:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:43:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:43:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:44:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:44:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:49:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:49:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:49:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:49:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:49:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:49:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:49:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:49:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:49:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:50:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:50:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:50:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:50:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:50:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:50:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:50:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:50:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:50:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:50:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:50:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:50:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:50:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:50:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:50:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:58:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:58:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:58:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:58:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:58:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:58:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:58:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:59:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 12:59:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:59:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 12:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 12:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 12:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 12:59:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:59:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 12:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:59:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:59:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:59:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 12:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 12:59:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:00:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:00:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:00:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:02:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:02:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:02:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:02:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:02:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:04:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:04:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:06:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:06:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:06:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:07:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:07:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:07:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:07:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:07:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:07:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:07:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:08:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:08:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:08:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:08:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:09:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:09:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:09:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:17:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:17:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:24:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:24:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:24:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:24:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:24:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:29:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:29:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:29:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:29:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:29:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:29:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:31:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:31:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:31:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:31:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:31:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:31:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:31:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:31:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:31:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:55:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:55:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:55:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:55:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:55:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:55:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:55:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:55:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:55:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 13:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 13:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 13:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 13:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:00:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:00:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:00:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:00:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:00:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:00:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:00:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:00:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:01:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:02:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:02:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:02:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:02:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:02:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:02:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:03:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:03:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:03:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:03:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:04:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:04:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:04:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:04:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:04:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:04:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:04:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:04:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:04:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:04:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:04:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:04:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:10:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:10:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:10:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:10:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:10:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:11:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:11:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:11:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:11:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:12:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:12:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:12:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:15:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:15:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:15:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:15:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:15:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:15:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:16:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:16:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:16:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:25:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:26:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:26:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:26:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:26:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:26:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:26:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:26:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:26:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:26:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:26:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:26:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:26:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:27:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:27:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:27:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:27:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:27:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:27:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:28:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:28:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:28:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:28:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:28:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:28:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:28:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:28:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:28:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:28:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:28:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:28:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:28:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:29:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:29:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:29:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:29:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:32:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 14:32:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:32:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:32:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 14:32:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:32:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:32:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 14:32:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:35:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:35:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:35:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:37:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:37:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:37:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:37:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:38:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:38:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:44:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:44:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:45:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:50:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:50:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:50:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:50:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:50:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:50:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:50:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:56:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:57:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:57:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:57:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:57:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:59:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 15:59:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:59:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 15:59:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:00:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:01:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:02:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:02:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:02:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:02:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:04:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:05:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:05:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:05:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:12:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:12:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:12:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:12:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:13:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:13:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:13:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:14:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:14:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:14:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:14:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:15:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:15:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:15:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:18:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:19:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:19:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:19:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:19:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:19:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:21:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:21:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:21:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:22:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:22:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:22:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:23:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:23:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:23:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:23:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:23:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:24:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:24:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:24:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:24:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:24:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:24:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:25:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:25:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:25:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:26:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:26:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:27:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:27:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:27:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:27:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:27:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:27:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:32:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:32:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:32:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:33:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:33:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:33:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:33:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:33:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:33:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:33:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:33:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:33:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:33:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:33:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:33:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:33:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:33:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:33:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:33:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:33:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:33:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:37:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:37:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:37:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-30 16:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:39:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:41:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:41:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:41:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:41:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:42:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:42:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:42:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:42:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:42:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:42:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:42:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:42:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:42:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:42:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:42:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:42:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:42:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:42:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:42:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:43:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:43:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:43:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:44:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:44:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:44:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:53:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 16:53:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:53:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:53:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:53:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 16:59:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 16:59:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 16:59:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:01:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:01:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:01:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:01:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:01:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:01:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:05:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:05:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:05:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:12:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:12:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:12:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:12:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:12:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:12:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:13:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:13:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:13:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:13:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:14:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:14:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:14:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:15:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:15:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:15:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:15:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:17:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:17:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:17:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:17:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:25:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:31:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:32:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:32:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:32:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:36:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:36:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:36:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:36:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:37:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:37:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:37:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:37:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:37:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:37:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:37:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:39:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:39:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:39:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:40:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:40:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:40:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:40:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:40:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:46:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:46:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:49:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:49:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:49:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:51:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:51:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:51:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:54:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:54:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:54:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:54:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:54:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:55:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:55:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:55:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:56:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:56:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 17:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 17:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 17:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:25:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:25:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:25:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:25:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:25:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:25:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:25:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:26:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:26:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:26:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:28:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:45:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:45:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:45:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:46:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:48:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:48:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:48:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:48:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:48:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:48:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:48:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 18:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:03:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:03:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:19:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:19:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:14 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-06-30 19:19:16 --> Session update failed, session record recovered using previous id. Lost rotation data?
INFO - 2016-06-30 19:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:19:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:19:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:23:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:25:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:25:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:32:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:32:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:32:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:47:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:47:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:47:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:47:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:50:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:50:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:50:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:53:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:53:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:53:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:59:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:59:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:59:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 19:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 19:59:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 19:59:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 19:59:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 19:59:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 19:59:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 19:59:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 19:59:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:48:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 23:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-30 23:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-30 23:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 23:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 23:49:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:49:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 23:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 23:50:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 23:50:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-30 23:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 23:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 23:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 23:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:51:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 23:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:55:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 23:55:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:55:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:55:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-30 23:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-30 23:56:44 --> Fuel\Core\Request::execute - Setting main Request
