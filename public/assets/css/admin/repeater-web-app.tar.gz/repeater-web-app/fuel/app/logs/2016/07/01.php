<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-01 00:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:02:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:04:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:11:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:11:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:11:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:11:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:12:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:12:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:12:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:12:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:14:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:15:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:23:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:27:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:27:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:27:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:27:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:29:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:29:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:29:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:30:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:34:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:40:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:40:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:40:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:40:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:40:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:42:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:42:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:42:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:45:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:45:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:45:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:45:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:46:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:46:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:47:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:47:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:47:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:49:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:50:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:50:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:50:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 00:53:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:53:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:53:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 00:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 00:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 00:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:00:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:00:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:00:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:00:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:02:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:02:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:02:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:03:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:05:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:05:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:05:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:06:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:06:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:06:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:07:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:07:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:07:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:08:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:08:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:08:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:10:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:11:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:11:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:12:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:12:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:12:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:13:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:13:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:13:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:13:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:16:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:16:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:16:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:17:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:18:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:18:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:19:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:19:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:19:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:19:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:19:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:19:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:19:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:20:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:20:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:20:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:20:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:21:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:21:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:21:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:23:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:23:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:26:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:26:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:26:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:26:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:26:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:26:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 01:30:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:30:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:31:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:31:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:31:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:31:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:31:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:31:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:31:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:32:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:33:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:33:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:33:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:33:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:34:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:34:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:34:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:34:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:35:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:35:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:35:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:35:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:35:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:36:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:36:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:36:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:37:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:37:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:37:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:37:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:37:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:37:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:38:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:38:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:38:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:38:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:40:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:40:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:40:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:40:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:40:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:41:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:41:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:42:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:44:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:44:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:44:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:44:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:45:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:45:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:45:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:45:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:46:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:46:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:46:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:46:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:46:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:46:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:50:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:50:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:50:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:50:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:50:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 01:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:51:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:51:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:51:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:51:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:51:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:54:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:54:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:54:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 01:56:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 01:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:56:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:56:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:56:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 01:59:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 01:59:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 01:59:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:00:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:00:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:00:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:00:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:07:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:07:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:07:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:11:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:11:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:11:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:15:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:15:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:15:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:15:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:18:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:19:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:19:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:19:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:20:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 02:20:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:20:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:20:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:20:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:24:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:24:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:27:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:27:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:27:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 02:27:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:28:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:28:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:28:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:28:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 02:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 02:29:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 02:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 02:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 10:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 10:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:46:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 10:46:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:46:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:46:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 10:46:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:46:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:46:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 10:46:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 10:46:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:52:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 10:52:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:52:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 10:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 10:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:53:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:53:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 10:53:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:53:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 10:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 10:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 10:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 10:59:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:02:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:02:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:02:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:10:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:11:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:11:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:11:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:12:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:12:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:13:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:21:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:21:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:22:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:22:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:23:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:24:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:26:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:26:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:26:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:27:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:27:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:27:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:28:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:28:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:28:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:29:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:29:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:29:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:30:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:30:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:30:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:30:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:30:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:34:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:34:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:41:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:43:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:43:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:44:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:55:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:55:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 11:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:56:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:56:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 11:56:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 11:56:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 11:56:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:08:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:08:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:09:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:09:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:09:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:09:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:10:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:10:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:10:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:10:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:11:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:11:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:11:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:11:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:11:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:11:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:11:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:11:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:11:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:11:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:12:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:12:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:12:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:12:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:12:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:12:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:12:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:12:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:12:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:13:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:13:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:13:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:13:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:13:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:13:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:13:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:13:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:14:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:14:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:14:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:14:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:14:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:14:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:16:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:16:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:16:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:16:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:16:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:16:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:17:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:17:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:18:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:18:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:18:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:36:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:36:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:59:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 12:59:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:59:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 12:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:00:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:00:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:02:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:02:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:02:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:02:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:03:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:03:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:03:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:04:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:04:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:04:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:04:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:04:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:04:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:07:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:07:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:07:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:08:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:08:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:08:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:08:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:08:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:08:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:08:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:09:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:09:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:09:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:09:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:09:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:09:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:09:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:09:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:09:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:09:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:09:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:11:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:11:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:11:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:11:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:11:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:11:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:11:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:11:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:11:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:14:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:14:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:14:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:14:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:14:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:15:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:15:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:15:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:19:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:19:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:19:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:19:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:21:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:21:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:35:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:35:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:37:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:37:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:51:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:51:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:51:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:58:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:58:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:58:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:58:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:58:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 13:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 13:59:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:01:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:02:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:02:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:02:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:25:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:25:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:25:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:25:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:35:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:35:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:35:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:45:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:45:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:45:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 14:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 14:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:07:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:08:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:12:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:15:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:20:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:30:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:30:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:30:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:33:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:33:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:33:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:33:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:33:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:33:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:33:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:33:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:36:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:36:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:36:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:36:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:41:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:41:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:43:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:43:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:48:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:55:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:56:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:56:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:56:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:57:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:57:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:57:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:58:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:58:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:58:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 15:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 15:59:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:06:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:06:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:06:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:07:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:10:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:10:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:11:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:11:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:15:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:15:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:15:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:15:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-01 16:16:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:16:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:16:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:16:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:16:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:16:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:16:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:16:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:16:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:16:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:16:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:23:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:23:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:23:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:23:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:24:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:24:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:25:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:25:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:25:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:28:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:28:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:28:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:29:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:29:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:29:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:29:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:30:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:30:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:30:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:30:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:32:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:32:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:32:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:34:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:34:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:34:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:35:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:35:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:35:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:36:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:36:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:37:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:39:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:40:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:40:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:40:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:42:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:45:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:49:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:49:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:53:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:53:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:54:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:54:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:54:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:58:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 16:58:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:58:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 16:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 16:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 16:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:00:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:00:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:00:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:00:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:03:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:03:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:04:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:04:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:04:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:04:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:08:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:12:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:12:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:12:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:14:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:14:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:14:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:14:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:14:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:14:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:15:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:15:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:15:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:16:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:18:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:18:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:18:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:18:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:19:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:19:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:20:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:20:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:20:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:20:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:20:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:20:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:29:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:29:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:30:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:37:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:37:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:37:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:37:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:37:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:37:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:38:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:40:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:40:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:40:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:41:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:41:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:43:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:43:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:43:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:44:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:44:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:44:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:46:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:46:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:46:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:46:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:48:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:48:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:48:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:54:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:54:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:54:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:54:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:54:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:54:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:54:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:54:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:55:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:55:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:55:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:55:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:55:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:55:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:55:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:56:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:56:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:56:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:57:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:57:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:57:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:57:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:58:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 17:58:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 17:58:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 17:58:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:00:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:00:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:02:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:03:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:03:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:03:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information/1"
INFO - 2016-07-01 18:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-01 18:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:08:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:09:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web"
INFO - 2016-07-01 18:09:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web"
INFO - 2016-07-01 18:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:34:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:34:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:34:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:52:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:52:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:52:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:53:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:53:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:53:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:54:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:54:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:54:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:57:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:57:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:57:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:59:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:59:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:59:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:59:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:59:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:59:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 18:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 18:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 18:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:01:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:01:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:01:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:01:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:01:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:01:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:03:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:03:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:06:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:06:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:06:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:07:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:07:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:08:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:08:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:16:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:16:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:16:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:16:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:16:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:17:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:17:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:17:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:25:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:25:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:25:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:26:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:26:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:26:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:30:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:30:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:30:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:31:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:31:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:31:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:32:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:32:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:32:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:36:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:36:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:36:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:44:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:45:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:45:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:45:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:45:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:45:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:45:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:48:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:48:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:48:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:49:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:49:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:49:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:49:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:49:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:49:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:49:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:49:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:49:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:50:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:50:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:50:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:50:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:50:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:50:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:50:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:52:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:55:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-01 19:55:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:55:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-01 19:55:31 --> Fuel\Core\Request::execute - Setting main Request
