<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-07-26 10:47:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-07-26 10:47:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 10:47:51 --> Migrate class initialized
WARNING - 2016-07-26 10:48:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 10:48:38 --> Migrate class initialized
INFO - 2016-07-26 10:48:38 --> Migrating to version: 36
INFO - 2016-07-26 10:48:38 --> Migrating to version: 37
INFO - 2016-07-26 10:48:38 --> Migrating to version: 38
INFO - 2016-07-26 10:48:38 --> Migrating to version: 39
INFO - 2016-07-26 10:48:38 --> Migrating to version: 40
INFO - 2016-07-26 10:48:38 --> Migrated to 40 successfully.
INFO - 2016-07-26 10:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 10:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-26 10:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-26 10:58:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 10:58:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 10:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 10:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 10:58:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:11:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:11:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:11:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:12:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:12:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:12:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:14:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:14:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:14:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:14:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:14:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:15:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:16:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:16:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:16:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:18:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:19:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:19:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:20:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:20:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:20:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:20:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:20:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:20:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:23:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:23:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:25:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:25:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:26:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:27:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:31:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:31:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:31:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:31:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:31:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:32:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:32:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:32:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:32:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:32:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:33:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:33:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:33:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:37:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:37:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:37:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:37:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:37:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:38:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:38:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:38:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:38:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:38:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:46:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:46:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:46:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:46:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:46:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:47:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:47:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:47:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:47:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:47:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:49:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:49:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:49:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:49:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:49:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:49:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:49:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:49:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:49:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:51:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:51:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:52:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:52:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:52:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-26 11:52:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:52:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:52:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:52:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:54:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:54:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 11:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:54:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 11:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 11:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 11:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:00:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:00:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:00:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:01:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:01:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:01:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:01:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-26 12:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-26 12:18:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:18:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:18:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:18:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:18:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:19:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:19:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:19:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:19:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:19:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:19:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:22:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:22:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:36:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:36:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:38:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:38:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:38:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:38:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:38:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:38:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:39:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:39:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:39:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:43:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:43:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:43:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:44:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:44:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:51:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:51:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:51:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:55:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:55:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:55:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:56:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:56:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:56:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 12:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 12:57:11 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-26 13:03:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:03:19 --> Migrate class initialized
INFO - 2016-07-26 13:03:19 --> Migrating to version: 41
WARNING - 2016-07-26 13:05:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:05:44 --> Migrate class initialized
INFO - 2016-07-26 13:05:44 --> Migrating to version: 40
INFO - 2016-07-26 13:05:45 --> Migrated to 40 successfully.
WARNING - 2016-07-26 13:05:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:05:50 --> Migrate class initialized
INFO - 2016-07-26 13:05:50 --> Migrating to version: 39
INFO - 2016-07-26 13:05:50 --> Migrated to 39 successfully.
WARNING - 2016-07-26 13:05:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:05:54 --> Migrate class initialized
INFO - 2016-07-26 13:05:54 --> Migrating to version: 0
INFO - 2016-07-26 13:05:54 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:05:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:05:55 --> Migrate class initialized
INFO - 2016-07-26 13:05:56 --> Migrating to version: 0
INFO - 2016-07-26 13:05:56 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:05:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:05:57 --> Migrate class initialized
INFO - 2016-07-26 13:05:57 --> Migrating to version: 0
WARNING - 2016-07-26 13:07:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:07:19 --> Migrate class initialized
INFO - 2016-07-26 13:07:19 --> Migrating to version: 40
INFO - 2016-07-26 13:07:19 --> Migrated to 40 successfully.
INFO - 2016-07-26 13:08:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 13:08:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 13:08:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 13:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:08:26 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-26 13:09:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:09:42 --> Migrate class initialized
INFO - 2016-07-26 13:09:42 --> Migrating to version: 39
INFO - 2016-07-26 13:09:42 --> Migrated to 39 successfully.
WARNING - 2016-07-26 13:09:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:09:43 --> Migrate class initialized
INFO - 2016-07-26 13:09:43 --> Migrating to version: 38
INFO - 2016-07-26 13:09:43 --> Migrated to 38 successfully.
WARNING - 2016-07-26 13:09:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:09:43 --> Migrate class initialized
INFO - 2016-07-26 13:09:43 --> Migrating to version: 37
INFO - 2016-07-26 13:09:43 --> Migrated to 37 successfully.
WARNING - 2016-07-26 13:09:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:09:44 --> Migrate class initialized
INFO - 2016-07-26 13:09:44 --> Migrating to version: 35
INFO - 2016-07-26 13:09:44 --> Migrated to 35 successfully.
WARNING - 2016-07-26 13:09:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:09:44 --> Migrate class initialized
INFO - 2016-07-26 13:09:44 --> Migrating to version: 34
INFO - 2016-07-26 13:09:44 --> Migrated to 34 successfully.
WARNING - 2016-07-26 13:09:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:09:45 --> Migrate class initialized
INFO - 2016-07-26 13:09:45 --> Migrating to version: 33
INFO - 2016-07-26 13:09:45 --> Migrated to 33 successfully.
WARNING - 2016-07-26 13:09:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:09:50 --> Migrate class initialized
INFO - 2016-07-26 13:09:50 --> Migrating to version: 0
INFO - 2016-07-26 13:09:50 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:10:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:10:00 --> Migrate class initialized
INFO - 2016-07-26 13:10:00 --> Migrating to version: 37
INFO - 2016-07-26 13:10:00 --> Migrated to 37 successfully.
WARNING - 2016-07-26 13:10:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:10:02 --> Migrate class initialized
INFO - 2016-07-26 13:10:02 --> Migrating to version: 31
INFO - 2016-07-26 13:10:02 --> Migrated to 31 successfully.
WARNING - 2016-07-26 13:10:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:10:02 --> Migrate class initialized
INFO - 2016-07-26 13:10:02 --> Migrating to version: 30
INFO - 2016-07-26 13:10:03 --> Migrated to 30 successfully.
WARNING - 2016-07-26 13:10:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:10:10 --> Migrate class initialized
INFO - 2016-07-26 13:10:10 --> Migrating to version: 0
INFO - 2016-07-26 13:10:10 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:10:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:10:11 --> Migrate class initialized
INFO - 2016-07-26 13:10:11 --> Migrating to version: 0
INFO - 2016-07-26 13:10:11 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:10:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:10:12 --> Migrate class initialized
INFO - 2016-07-26 13:10:12 --> Migrating to version: 0
INFO - 2016-07-26 13:10:12 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:10:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:10:13 --> Migrate class initialized
INFO - 2016-07-26 13:10:13 --> Migrating to version: 0
INFO - 2016-07-26 13:10:13 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:10:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:10:14 --> Migrate class initialized
INFO - 2016-07-26 13:10:14 --> Migrating to version: 0
WARNING - 2016-07-26 13:12:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:24 --> Migrate class initialized
INFO - 2016-07-26 13:12:24 --> Migrating to version: 40
INFO - 2016-07-26 13:12:24 --> Migrated to 40 successfully.
WARNING - 2016-07-26 13:12:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:27 --> Migrate class initialized
INFO - 2016-07-26 13:12:27 --> Migrating to version: 39
INFO - 2016-07-26 13:12:27 --> Migrated to 39 successfully.
WARNING - 2016-07-26 13:12:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:27 --> Migrate class initialized
INFO - 2016-07-26 13:12:28 --> Migrating to version: 38
INFO - 2016-07-26 13:12:28 --> Migrated to 38 successfully.
WARNING - 2016-07-26 13:12:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:28 --> Migrate class initialized
INFO - 2016-07-26 13:12:28 --> Migrating to version: 37
INFO - 2016-07-26 13:12:28 --> Migrated to 37 successfully.
WARNING - 2016-07-26 13:12:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:29 --> Migrate class initialized
INFO - 2016-07-26 13:12:29 --> Migrating to version: 29
INFO - 2016-07-26 13:12:29 --> Migrated to 29 successfully.
WARNING - 2016-07-26 13:12:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:38 --> Migrate class initialized
INFO - 2016-07-26 13:12:38 --> Migrating to version: 29
INFO - 2016-07-26 13:12:38 --> Migrating to version: 30
INFO - 2016-07-26 13:12:38 --> Migrating to version: 31
INFO - 2016-07-26 13:12:38 --> Migrating to version: 32
WARNING - 2016-07-26 13:12:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:48 --> Migrate class initialized
INFO - 2016-07-26 13:12:48 --> Migrating to version: 0
INFO - 2016-07-26 13:12:48 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:12:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:54 --> Migrate class initialized
INFO - 2016-07-26 13:12:54 --> Migrating to version: 0
INFO - 2016-07-26 13:12:54 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:12:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:55 --> Migrate class initialized
INFO - 2016-07-26 13:12:55 --> Migrating to version: 0
INFO - 2016-07-26 13:12:55 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:12:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:56 --> Migrate class initialized
INFO - 2016-07-26 13:12:56 --> Migrating to version: 0
INFO - 2016-07-26 13:12:56 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:12:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:12:57 --> Migrate class initialized
INFO - 2016-07-26 13:12:57 --> Migrating to version: 0
INFO - 2016-07-26 13:14:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 13:14:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 13:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:14:29 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-26 13:15:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:15:17 --> Migrate class initialized
INFO - 2016-07-26 13:15:18 --> Migrating to version: 32
WARNING - 2016-07-26 13:15:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:15:22 --> Migrate class initialized
INFO - 2016-07-26 13:15:22 --> Migrating to version: 41
INFO - 2016-07-26 13:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 13:18:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:18:55 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-26 13:26:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:14 --> Migrate class initialized
INFO - 2016-07-26 13:26:14 --> Migrating to version: 40
INFO - 2016-07-26 13:26:14 --> Migrated to 40 successfully.
WARNING - 2016-07-26 13:26:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:15 --> Migrate class initialized
INFO - 2016-07-26 13:26:15 --> Migrating to version: 39
INFO - 2016-07-26 13:26:15 --> Migrated to 39 successfully.
WARNING - 2016-07-26 13:26:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:15 --> Migrate class initialized
INFO - 2016-07-26 13:26:16 --> Migrating to version: 38
INFO - 2016-07-26 13:26:16 --> Migrated to 38 successfully.
WARNING - 2016-07-26 13:26:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:16 --> Migrate class initialized
INFO - 2016-07-26 13:26:16 --> Migrating to version: 37
INFO - 2016-07-26 13:26:16 --> Migrated to 37 successfully.
WARNING - 2016-07-26 13:26:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:17 --> Migrate class initialized
INFO - 2016-07-26 13:26:17 --> Migrating to version: 31
INFO - 2016-07-26 13:26:17 --> Migrated to 31 successfully.
WARNING - 2016-07-26 13:26:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:18 --> Migrate class initialized
INFO - 2016-07-26 13:26:18 --> Migrating to version: 30
INFO - 2016-07-26 13:26:18 --> Migrated to 30 successfully.
WARNING - 2016-07-26 13:26:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:19 --> Migrate class initialized
INFO - 2016-07-26 13:26:19 --> Migrating to version: 29
INFO - 2016-07-26 13:26:19 --> Migrated to 29 successfully.
WARNING - 2016-07-26 13:26:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:19 --> Migrate class initialized
INFO - 2016-07-26 13:26:19 --> Migrating to version: 28
INFO - 2016-07-26 13:26:19 --> Migrated to 28 successfully.
WARNING - 2016-07-26 13:26:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:20 --> Migrate class initialized
INFO - 2016-07-26 13:26:20 --> Migrating to version: 27
INFO - 2016-07-26 13:26:20 --> Migrated to 27 successfully.
WARNING - 2016-07-26 13:26:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:20 --> Migrate class initialized
INFO - 2016-07-26 13:26:20 --> Migrating to version: 26
INFO - 2016-07-26 13:26:20 --> Migrated to 26 successfully.
WARNING - 2016-07-26 13:26:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:20 --> Migrate class initialized
INFO - 2016-07-26 13:26:20 --> Migrating to version: 25
INFO - 2016-07-26 13:26:20 --> Migrated to 25 successfully.
WARNING - 2016-07-26 13:26:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:22 --> Migrate class initialized
INFO - 2016-07-26 13:26:22 --> Migrating to version: 24
INFO - 2016-07-26 13:26:22 --> Migrated to 24 successfully.
WARNING - 2016-07-26 13:26:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:27 --> Migrate class initialized
INFO - 2016-07-26 13:26:27 --> Migrating to version: 23
WARNING - 2016-07-26 13:26:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:44 --> Migrate class initialized
INFO - 2016-07-26 13:26:44 --> Migrating to version: 23
WARNING - 2016-07-26 13:26:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:45 --> Migrate class initialized
INFO - 2016-07-26 13:26:45 --> Migrating to version: 23
WARNING - 2016-07-26 13:26:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:46 --> Migrate class initialized
INFO - 2016-07-26 13:26:46 --> Migrating to version: 23
WARNING - 2016-07-26 13:26:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:46 --> Migrate class initialized
INFO - 2016-07-26 13:26:46 --> Migrating to version: 23
WARNING - 2016-07-26 13:26:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:26:47 --> Migrate class initialized
INFO - 2016-07-26 13:26:47 --> Migrating to version: 23
WARNING - 2016-07-26 13:27:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:27:25 --> Migrate class initialized
INFO - 2016-07-26 13:27:25 --> Migrating to version: 37
INFO - 2016-07-26 13:27:25 --> Migrating to version: 38
INFO - 2016-07-26 13:27:25 --> Migrating to version: 39
INFO - 2016-07-26 13:27:25 --> Migrating to version: 40
INFO - 2016-07-26 13:27:25 --> Migrating to version: 41
WARNING - 2016-07-26 13:28:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:28:11 --> Migrate class initialized
INFO - 2016-07-26 13:28:11 --> Migrating to version: 41
WARNING - 2016-07-26 13:28:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:28:32 --> Migrate class initialized
INFO - 2016-07-26 13:28:32 --> Migrating to version: 1
INFO - 2016-07-26 13:28:33 --> Migrating to version: 2
INFO - 2016-07-26 13:28:33 --> Migrating to version: 3
INFO - 2016-07-26 13:28:33 --> Migrating to version: 4
INFO - 2016-07-26 13:28:33 --> Migrating to version: 5
INFO - 2016-07-26 13:28:33 --> Migrating to version: 6
INFO - 2016-07-26 13:28:33 --> Migrating to version: 7
INFO - 2016-07-26 13:28:33 --> Migrating to version: 8
INFO - 2016-07-26 13:28:33 --> Migrating to version: 9
INFO - 2016-07-26 13:28:33 --> Migrating to version: 10
INFO - 2016-07-26 13:28:33 --> Migrating to version: 11
INFO - 2016-07-26 13:28:33 --> Migrating to version: 12
INFO - 2016-07-26 13:28:33 --> Migrating to version: 13
INFO - 2016-07-26 13:28:33 --> Migrating to version: 14
INFO - 2016-07-26 13:28:33 --> Migrating to version: 15
INFO - 2016-07-26 13:28:33 --> Migrating to version: 16
INFO - 2016-07-26 13:28:33 --> Migrating to version: 17
INFO - 2016-07-26 13:28:33 --> Migrating to version: 18
INFO - 2016-07-26 13:28:34 --> Migrating to version: 19
INFO - 2016-07-26 13:28:34 --> Migrating to version: 20
INFO - 2016-07-26 13:28:34 --> Migrating to version: 21
INFO - 2016-07-26 13:28:34 --> Migrating to version: 22
INFO - 2016-07-26 13:28:34 --> Migrating to version: 23
INFO - 2016-07-26 13:28:34 --> Migrating to version: 24
INFO - 2016-07-26 13:28:34 --> Migrating to version: 25
INFO - 2016-07-26 13:28:34 --> Migrating to version: 26
INFO - 2016-07-26 13:28:34 --> Migrating to version: 27
INFO - 2016-07-26 13:28:34 --> Migrating to version: 28
INFO - 2016-07-26 13:28:34 --> Migrating to version: 29
INFO - 2016-07-26 13:28:34 --> Migrating to version: 30
INFO - 2016-07-26 13:28:34 --> Migrating to version: 31
INFO - 2016-07-26 13:28:34 --> Migrating to version: 32
INFO - 2016-07-26 13:28:34 --> Migrating to version: 33
INFO - 2016-07-26 13:28:34 --> Migrating to version: 34
INFO - 2016-07-26 13:28:34 --> Migrating to version: 35
INFO - 2016-07-26 13:28:34 --> Migrating to version: 36
INFO - 2016-07-26 13:28:34 --> Migrating to version: 37
INFO - 2016-07-26 13:28:34 --> Migrating to version: 38
INFO - 2016-07-26 13:28:34 --> Migrating to version: 39
INFO - 2016-07-26 13:28:34 --> Migrating to version: 40
INFO - 2016-07-26 13:28:34 --> Migrated to 40 successfully.
INFO - 2016-07-26 13:35:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 13:35:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:35:00 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-07-26 13:35:00 --> 1146 - Table 'repeater.sessions' doesn't exist [ SELECT * FROM `sessions` WHERE `session_id` = '7c61d550c2a482833e86d3f0caff63f5' ] in /var/www/local.gmorepeater.jp/fuel/core/classes/database/mysqli/connection.php on line 292
WARNING - 2016-07-26 13:44:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:44:14 --> Migrate class initialized
WARNING - 2016-07-26 13:44:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:44:46 --> Migrate class initialized
INFO - 2016-07-26 13:44:47 --> Migrating to version: 41
WARNING - 2016-07-26 13:45:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:45:49 --> Migrate class initialized
WARNING - 2016-07-26 13:45:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:45:52 --> Migrate class initialized
WARNING - 2016-07-26 13:45:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:45:55 --> Migrate class initialized
INFO - 2016-07-26 13:45:55 --> Migrating to version: 0
WARNING - 2016-07-26 13:46:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:30 --> Migrate class initialized
WARNING - 2016-07-26 13:46:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:34 --> Migrate class initialized
INFO - 2016-07-26 13:46:34 --> Migrating to version: 1
INFO - 2016-07-26 13:46:34 --> Migrating to version: 2
INFO - 2016-07-26 13:46:34 --> Migrating to version: 3
INFO - 2016-07-26 13:46:34 --> Migrating to version: 4
INFO - 2016-07-26 13:46:34 --> Migrating to version: 5
INFO - 2016-07-26 13:46:34 --> Migrating to version: 6
INFO - 2016-07-26 13:46:34 --> Migrating to version: 7
INFO - 2016-07-26 13:46:35 --> Migrating to version: 8
INFO - 2016-07-26 13:46:35 --> Migrating to version: 9
INFO - 2016-07-26 13:46:35 --> Migrating to version: 10
INFO - 2016-07-26 13:46:35 --> Migrating to version: 11
INFO - 2016-07-26 13:46:35 --> Migrating to version: 12
INFO - 2016-07-26 13:46:35 --> Migrating to version: 13
INFO - 2016-07-26 13:46:35 --> Migrating to version: 14
INFO - 2016-07-26 13:46:35 --> Migrating to version: 15
INFO - 2016-07-26 13:46:35 --> Migrating to version: 16
INFO - 2016-07-26 13:46:35 --> Migrating to version: 17
INFO - 2016-07-26 13:46:35 --> Migrating to version: 18
INFO - 2016-07-26 13:46:35 --> Migrating to version: 19
INFO - 2016-07-26 13:46:35 --> Migrating to version: 20
INFO - 2016-07-26 13:46:35 --> Migrating to version: 21
INFO - 2016-07-26 13:46:35 --> Migrating to version: 22
INFO - 2016-07-26 13:46:35 --> Migrating to version: 23
INFO - 2016-07-26 13:46:35 --> Migrating to version: 24
INFO - 2016-07-26 13:46:35 --> Migrating to version: 25
INFO - 2016-07-26 13:46:35 --> Migrating to version: 26
INFO - 2016-07-26 13:46:35 --> Migrating to version: 27
INFO - 2016-07-26 13:46:35 --> Migrating to version: 28
INFO - 2016-07-26 13:46:35 --> Migrating to version: 29
INFO - 2016-07-26 13:46:35 --> Migrating to version: 30
INFO - 2016-07-26 13:46:36 --> Migrating to version: 31
INFO - 2016-07-26 13:46:36 --> Migrating to version: 32
INFO - 2016-07-26 13:46:36 --> Migrating to version: 33
INFO - 2016-07-26 13:46:36 --> Migrating to version: 34
INFO - 2016-07-26 13:46:36 --> Migrating to version: 35
INFO - 2016-07-26 13:46:36 --> Migrating to version: 36
INFO - 2016-07-26 13:46:36 --> Migrating to version: 37
INFO - 2016-07-26 13:46:36 --> Migrating to version: 38
INFO - 2016-07-26 13:46:36 --> Migrating to version: 39
INFO - 2016-07-26 13:46:36 --> Migrating to version: 40
INFO - 2016-07-26 13:46:36 --> Migrated to 40 successfully.
WARNING - 2016-07-26 13:46:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:41 --> Migrate class initialized
INFO - 2016-07-26 13:46:41 --> Migrating to version: 40
INFO - 2016-07-26 13:46:41 --> Migrated to 40 successfully.
WARNING - 2016-07-26 13:46:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:42 --> Migrate class initialized
INFO - 2016-07-26 13:46:42 --> Migrating to version: 39
INFO - 2016-07-26 13:46:42 --> Migrated to 39 successfully.
WARNING - 2016-07-26 13:46:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:42 --> Migrate class initialized
INFO - 2016-07-26 13:46:42 --> Migrating to version: 38
INFO - 2016-07-26 13:46:42 --> Migrated to 38 successfully.
WARNING - 2016-07-26 13:46:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:43 --> Migrate class initialized
INFO - 2016-07-26 13:46:43 --> Migrating to version: 37
INFO - 2016-07-26 13:46:43 --> Migrated to 37 successfully.
WARNING - 2016-07-26 13:46:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:43 --> Migrate class initialized
INFO - 2016-07-26 13:46:43 --> Migrating to version: 36
INFO - 2016-07-26 13:46:43 --> Migrated to 36 successfully.
WARNING - 2016-07-26 13:46:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:43 --> Migrate class initialized
INFO - 2016-07-26 13:46:43 --> Migrating to version: 35
INFO - 2016-07-26 13:46:43 --> Migrated to 35 successfully.
WARNING - 2016-07-26 13:46:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:44 --> Migrate class initialized
INFO - 2016-07-26 13:46:44 --> Migrating to version: 34
INFO - 2016-07-26 13:46:44 --> Migrated to 34 successfully.
WARNING - 2016-07-26 13:46:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:44 --> Migrate class initialized
INFO - 2016-07-26 13:46:44 --> Migrating to version: 33
INFO - 2016-07-26 13:46:44 --> Migrated to 33 successfully.
WARNING - 2016-07-26 13:46:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:44 --> Migrate class initialized
INFO - 2016-07-26 13:46:44 --> Migrating to version: 32
INFO - 2016-07-26 13:46:44 --> Migrated to 32 successfully.
WARNING - 2016-07-26 13:46:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:46 --> Migrate class initialized
INFO - 2016-07-26 13:46:46 --> Migrating to version: 31
INFO - 2016-07-26 13:46:46 --> Migrated to 31 successfully.
WARNING - 2016-07-26 13:46:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:47 --> Migrate class initialized
INFO - 2016-07-26 13:46:47 --> Migrating to version: 30
INFO - 2016-07-26 13:46:47 --> Migrated to 30 successfully.
WARNING - 2016-07-26 13:46:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:48 --> Migrate class initialized
INFO - 2016-07-26 13:46:48 --> Migrating to version: 29
INFO - 2016-07-26 13:46:48 --> Migrated to 29 successfully.
WARNING - 2016-07-26 13:46:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:48 --> Migrate class initialized
INFO - 2016-07-26 13:46:48 --> Migrating to version: 28
INFO - 2016-07-26 13:46:48 --> Migrated to 28 successfully.
WARNING - 2016-07-26 13:46:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:49 --> Migrate class initialized
INFO - 2016-07-26 13:46:49 --> Migrating to version: 27
INFO - 2016-07-26 13:46:49 --> Migrated to 27 successfully.
WARNING - 2016-07-26 13:46:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:49 --> Migrate class initialized
INFO - 2016-07-26 13:46:49 --> Migrating to version: 26
INFO - 2016-07-26 13:46:49 --> Migrated to 26 successfully.
WARNING - 2016-07-26 13:46:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:50 --> Migrate class initialized
INFO - 2016-07-26 13:46:50 --> Migrating to version: 25
INFO - 2016-07-26 13:46:50 --> Migrated to 25 successfully.
WARNING - 2016-07-26 13:46:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:51 --> Migrate class initialized
INFO - 2016-07-26 13:46:51 --> Migrating to version: 24
INFO - 2016-07-26 13:46:51 --> Migrated to 24 successfully.
WARNING - 2016-07-26 13:46:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:51 --> Migrate class initialized
INFO - 2016-07-26 13:46:51 --> Migrating to version: 23
WARNING - 2016-07-26 13:46:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:46:53 --> Migrate class initialized
INFO - 2016-07-26 13:46:53 --> Migrating to version: 23
WARNING - 2016-07-26 13:47:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:47:03 --> Migrate class initialized
INFO - 2016-07-26 13:47:03 --> Migrating to version: 24
INFO - 2016-07-26 13:47:03 --> Migrating to version: 25
INFO - 2016-07-26 13:47:03 --> Migrating to version: 26
INFO - 2016-07-26 13:47:03 --> Migrating to version: 27
INFO - 2016-07-26 13:47:03 --> Migrating to version: 28
INFO - 2016-07-26 13:47:03 --> Migrating to version: 29
INFO - 2016-07-26 13:47:03 --> Migrating to version: 30
INFO - 2016-07-26 13:47:03 --> Migrating to version: 31
INFO - 2016-07-26 13:47:03 --> Migrating to version: 32
INFO - 2016-07-26 13:47:03 --> Migrating to version: 33
INFO - 2016-07-26 13:47:03 --> Migrating to version: 34
INFO - 2016-07-26 13:47:03 --> Migrating to version: 35
INFO - 2016-07-26 13:47:03 --> Migrating to version: 36
INFO - 2016-07-26 13:47:03 --> Migrating to version: 37
INFO - 2016-07-26 13:47:03 --> Migrating to version: 38
INFO - 2016-07-26 13:47:03 --> Migrating to version: 39
INFO - 2016-07-26 13:47:03 --> Migrating to version: 40
INFO - 2016-07-26 13:47:03 --> Migrating to version: 41
INFO - 2016-07-26 13:47:03 --> Migrated to 41 successfully.
INFO - 2016-07-26 13:54:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 13:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:54:24 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-07-26 13:54:24 --> 1146 - Table 'repeater.sessions' doesn't exist [ SELECT * FROM `sessions` WHERE `session_id` = '7c61d550c2a482833e86d3f0caff63f5' ] in /var/www/local.gmorepeater.jp/fuel/core/classes/database/mysqli/connection.php on line 292
INFO - 2016-07-26 13:55:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 13:55:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 13:55:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-07-26 13:55:38 --> 1054 - Unknown column 'previous_id' in 'where clause' [ SELECT * FROM `sessions` WHERE `previous_id` = '7c61d550c2a482833e86d3f0caff63f5' ] in /var/www/local.gmorepeater.jp/fuel/core/classes/database/mysqli/connection.php on line 292
WARNING - 2016-07-26 13:56:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:12 --> Migrate class initialized
INFO - 2016-07-26 13:56:12 --> Migrating to version: 41
INFO - 2016-07-26 13:56:13 --> Migrated to 41 successfully.
WARNING - 2016-07-26 13:56:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:20 --> Migrate class initialized
INFO - 2016-07-26 13:56:20 --> Migrating to version: 0
INFO - 2016-07-26 13:56:20 --> Migrated to 0 successfully.
WARNING - 2016-07-26 13:56:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:28 --> Migrate class initialized
INFO - 2016-07-26 13:56:29 --> Migrating to version: 41
INFO - 2016-07-26 13:56:29 --> Migrated to 41 successfully.
WARNING - 2016-07-26 13:56:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:30 --> Migrate class initialized
INFO - 2016-07-26 13:56:30 --> Migrating to version: 40
INFO - 2016-07-26 13:56:30 --> Migrated to 40 successfully.
WARNING - 2016-07-26 13:56:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:30 --> Migrate class initialized
INFO - 2016-07-26 13:56:30 --> Migrating to version: 39
INFO - 2016-07-26 13:56:30 --> Migrated to 39 successfully.
WARNING - 2016-07-26 13:56:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:31 --> Migrate class initialized
INFO - 2016-07-26 13:56:31 --> Migrating to version: 38
INFO - 2016-07-26 13:56:31 --> Migrated to 38 successfully.
WARNING - 2016-07-26 13:56:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:32 --> Migrate class initialized
INFO - 2016-07-26 13:56:32 --> Migrating to version: 37
INFO - 2016-07-26 13:56:32 --> Migrated to 37 successfully.
WARNING - 2016-07-26 13:56:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:33 --> Migrate class initialized
INFO - 2016-07-26 13:56:33 --> Migrating to version: 36
INFO - 2016-07-26 13:56:33 --> Migrated to 36 successfully.
WARNING - 2016-07-26 13:56:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:33 --> Migrate class initialized
INFO - 2016-07-26 13:56:33 --> Migrating to version: 35
INFO - 2016-07-26 13:56:33 --> Migrated to 35 successfully.
WARNING - 2016-07-26 13:56:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:35 --> Migrate class initialized
INFO - 2016-07-26 13:56:35 --> Migrating to version: 34
INFO - 2016-07-26 13:56:35 --> Migrated to 34 successfully.
WARNING - 2016-07-26 13:56:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:36 --> Migrate class initialized
INFO - 2016-07-26 13:56:36 --> Migrating to version: 33
INFO - 2016-07-26 13:56:36 --> Migrated to 33 successfully.
WARNING - 2016-07-26 13:56:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:36 --> Migrate class initialized
INFO - 2016-07-26 13:56:36 --> Migrating to version: 32
INFO - 2016-07-26 13:56:36 --> Migrated to 32 successfully.
WARNING - 2016-07-26 13:56:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:37 --> Migrate class initialized
INFO - 2016-07-26 13:56:37 --> Migrating to version: 31
INFO - 2016-07-26 13:56:37 --> Migrated to 31 successfully.
WARNING - 2016-07-26 13:56:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:38 --> Migrate class initialized
INFO - 2016-07-26 13:56:38 --> Migrating to version: 30
INFO - 2016-07-26 13:56:38 --> Migrated to 30 successfully.
WARNING - 2016-07-26 13:56:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:38 --> Migrate class initialized
INFO - 2016-07-26 13:56:38 --> Migrating to version: 29
INFO - 2016-07-26 13:56:38 --> Migrated to 29 successfully.
WARNING - 2016-07-26 13:56:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:39 --> Migrate class initialized
INFO - 2016-07-26 13:56:39 --> Migrating to version: 28
INFO - 2016-07-26 13:56:39 --> Migrated to 28 successfully.
WARNING - 2016-07-26 13:56:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:40 --> Migrate class initialized
INFO - 2016-07-26 13:56:40 --> Migrating to version: 27
INFO - 2016-07-26 13:56:40 --> Migrated to 27 successfully.
WARNING - 2016-07-26 13:56:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:40 --> Migrate class initialized
INFO - 2016-07-26 13:56:40 --> Migrating to version: 26
INFO - 2016-07-26 13:56:40 --> Migrated to 26 successfully.
WARNING - 2016-07-26 13:56:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:41 --> Migrate class initialized
INFO - 2016-07-26 13:56:41 --> Migrating to version: 25
INFO - 2016-07-26 13:56:41 --> Migrated to 25 successfully.
WARNING - 2016-07-26 13:56:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:42 --> Migrate class initialized
INFO - 2016-07-26 13:56:42 --> Migrating to version: 24
INFO - 2016-07-26 13:56:42 --> Migrated to 24 successfully.
WARNING - 2016-07-26 13:56:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:56:42 --> Migrate class initialized
INFO - 2016-07-26 13:56:42 --> Migrating to version: 23
WARNING - 2016-07-26 13:57:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:57:18 --> Migrate class initialized
INFO - 2016-07-26 13:57:18 --> Migrating to version: 23
WARNING - 2016-07-26 13:57:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:57:59 --> Migrate class initialized
INFO - 2016-07-26 13:57:59 --> Migrating to version: 23
INFO - 2016-07-26 13:57:59 --> Migrated to 23 successfully.
WARNING - 2016-07-26 13:58:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:01 --> Migrate class initialized
INFO - 2016-07-26 13:58:01 --> Migrating to version: 22
INFO - 2016-07-26 13:58:01 --> Migrated to 22 successfully.
WARNING - 2016-07-26 13:58:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:02 --> Migrate class initialized
INFO - 2016-07-26 13:58:02 --> Migrating to version: 21
INFO - 2016-07-26 13:58:02 --> Migrated to 21 successfully.
WARNING - 2016-07-26 13:58:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:03 --> Migrate class initialized
INFO - 2016-07-26 13:58:03 --> Migrating to version: 20
INFO - 2016-07-26 13:58:03 --> Migrated to 20 successfully.
WARNING - 2016-07-26 13:58:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:03 --> Migrate class initialized
INFO - 2016-07-26 13:58:03 --> Migrating to version: 19
INFO - 2016-07-26 13:58:03 --> Migrated to 19 successfully.
WARNING - 2016-07-26 13:58:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:04 --> Migrate class initialized
INFO - 2016-07-26 13:58:04 --> Migrating to version: 18
INFO - 2016-07-26 13:58:04 --> Migrated to 18 successfully.
WARNING - 2016-07-26 13:58:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:04 --> Migrate class initialized
INFO - 2016-07-26 13:58:04 --> Migrating to version: 17
INFO - 2016-07-26 13:58:04 --> Migrated to 17 successfully.
WARNING - 2016-07-26 13:58:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:05 --> Migrate class initialized
INFO - 2016-07-26 13:58:05 --> Migrating to version: 16
INFO - 2016-07-26 13:58:05 --> Migrated to 16 successfully.
WARNING - 2016-07-26 13:58:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:05 --> Migrate class initialized
INFO - 2016-07-26 13:58:05 --> Migrating to version: 15
INFO - 2016-07-26 13:58:05 --> Migrated to 15 successfully.
WARNING - 2016-07-26 13:58:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:06 --> Migrate class initialized
INFO - 2016-07-26 13:58:06 --> Migrating to version: 14
INFO - 2016-07-26 13:58:06 --> Migrated to 14 successfully.
WARNING - 2016-07-26 13:58:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:06 --> Migrate class initialized
INFO - 2016-07-26 13:58:06 --> Migrating to version: 13
INFO - 2016-07-26 13:58:06 --> Migrated to 13 successfully.
WARNING - 2016-07-26 13:58:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:07 --> Migrate class initialized
INFO - 2016-07-26 13:58:07 --> Migrating to version: 12
INFO - 2016-07-26 13:58:07 --> Migrated to 12 successfully.
WARNING - 2016-07-26 13:58:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:07 --> Migrate class initialized
INFO - 2016-07-26 13:58:07 --> Migrating to version: 11
INFO - 2016-07-26 13:58:07 --> Migrated to 11 successfully.
WARNING - 2016-07-26 13:58:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:07 --> Migrate class initialized
INFO - 2016-07-26 13:58:08 --> Migrating to version: 10
INFO - 2016-07-26 13:58:08 --> Migrated to 10 successfully.
WARNING - 2016-07-26 13:58:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:08 --> Migrate class initialized
INFO - 2016-07-26 13:58:08 --> Migrating to version: 9
INFO - 2016-07-26 13:58:08 --> Migrated to 9 successfully.
WARNING - 2016-07-26 13:58:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:09 --> Migrate class initialized
INFO - 2016-07-26 13:58:09 --> Migrating to version: 8
INFO - 2016-07-26 13:58:09 --> Migrated to 8 successfully.
WARNING - 2016-07-26 13:58:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:09 --> Migrate class initialized
INFO - 2016-07-26 13:58:09 --> Migrating to version: 7
INFO - 2016-07-26 13:58:09 --> Migrated to 7 successfully.
WARNING - 2016-07-26 13:58:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:10 --> Migrate class initialized
INFO - 2016-07-26 13:58:10 --> Migrating to version: 6
INFO - 2016-07-26 13:58:10 --> Migrated to 6 successfully.
WARNING - 2016-07-26 13:58:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:10 --> Migrate class initialized
INFO - 2016-07-26 13:58:10 --> Migrating to version: 5
INFO - 2016-07-26 13:58:10 --> Migrated to 5 successfully.
WARNING - 2016-07-26 13:58:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:10 --> Migrate class initialized
INFO - 2016-07-26 13:58:11 --> Migrating to version: 4
INFO - 2016-07-26 13:58:11 --> Migrated to 4 successfully.
WARNING - 2016-07-26 13:58:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:11 --> Migrate class initialized
INFO - 2016-07-26 13:58:11 --> Migrating to version: 3
INFO - 2016-07-26 13:58:11 --> Migrated to 3 successfully.
WARNING - 2016-07-26 13:58:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:12 --> Migrate class initialized
INFO - 2016-07-26 13:58:12 --> Migrating to version: 2
INFO - 2016-07-26 13:58:12 --> Migrated to 2 successfully.
WARNING - 2016-07-26 13:58:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:12 --> Migrate class initialized
INFO - 2016-07-26 13:58:12 --> Migrating to version: 1
INFO - 2016-07-26 13:58:13 --> Migrated to 1 successfully.
WARNING - 2016-07-26 13:58:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:58:13 --> Migrate class initialized
WARNING - 2016-07-26 13:59:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 13:59:23 --> Migrate class initialized
INFO - 2016-07-26 13:59:23 --> Migrating to version: 1
INFO - 2016-07-26 13:59:23 --> Migrating to version: 2
INFO - 2016-07-26 13:59:24 --> Migrating to version: 3
INFO - 2016-07-26 13:59:24 --> Migrating to version: 4
INFO - 2016-07-26 13:59:24 --> Migrating to version: 5
INFO - 2016-07-26 13:59:24 --> Migrating to version: 6
INFO - 2016-07-26 13:59:24 --> Migrating to version: 7
INFO - 2016-07-26 13:59:24 --> Migrating to version: 8
INFO - 2016-07-26 13:59:24 --> Migrating to version: 9
INFO - 2016-07-26 13:59:24 --> Migrating to version: 10
INFO - 2016-07-26 13:59:24 --> Migrating to version: 11
INFO - 2016-07-26 13:59:24 --> Migrating to version: 12
INFO - 2016-07-26 13:59:24 --> Migrating to version: 13
INFO - 2016-07-26 13:59:24 --> Migrating to version: 14
INFO - 2016-07-26 13:59:24 --> Migrating to version: 15
INFO - 2016-07-26 13:59:24 --> Migrating to version: 16
INFO - 2016-07-26 13:59:24 --> Migrating to version: 17
INFO - 2016-07-26 13:59:24 --> Migrating to version: 18
INFO - 2016-07-26 13:59:24 --> Migrating to version: 19
INFO - 2016-07-26 13:59:24 --> Migrating to version: 20
INFO - 2016-07-26 13:59:24 --> Migrating to version: 21
INFO - 2016-07-26 13:59:24 --> Migrating to version: 22
INFO - 2016-07-26 13:59:24 --> Migrating to version: 23
INFO - 2016-07-26 13:59:24 --> Migrating to version: 24
INFO - 2016-07-26 13:59:24 --> Migrating to version: 25
INFO - 2016-07-26 13:59:25 --> Migrating to version: 26
INFO - 2016-07-26 13:59:25 --> Migrating to version: 27
INFO - 2016-07-26 13:59:25 --> Migrating to version: 28
INFO - 2016-07-26 13:59:25 --> Migrating to version: 29
INFO - 2016-07-26 13:59:25 --> Migrating to version: 30
INFO - 2016-07-26 13:59:25 --> Migrating to version: 31
INFO - 2016-07-26 13:59:25 --> Migrating to version: 32
INFO - 2016-07-26 13:59:25 --> Migrating to version: 33
INFO - 2016-07-26 13:59:25 --> Migrating to version: 34
INFO - 2016-07-26 13:59:25 --> Migrating to version: 35
INFO - 2016-07-26 13:59:25 --> Migrating to version: 36
INFO - 2016-07-26 13:59:25 --> Migrating to version: 37
INFO - 2016-07-26 13:59:25 --> Migrating to version: 38
INFO - 2016-07-26 13:59:25 --> Migrating to version: 39
INFO - 2016-07-26 13:59:25 --> Migrating to version: 40
INFO - 2016-07-26 13:59:25 --> Migrating to version: 41
INFO - 2016-07-26 13:59:25 --> Migrated to 41 successfully.
WARNING - 2016-07-26 14:00:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 14:00:44 --> Migrate class initialized
WARNING - 2016-07-26 14:00:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 14:00:56 --> Migrate class initialized
WARNING - 2016-07-26 14:01:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 14:01:01 --> Migrate class initialized
WARNING - 2016-07-26 14:01:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 14:01:10 --> Migrate class initialized
WARNING - 2016-07-26 14:01:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-26 14:01:24 --> Migrate class initialized
INFO - 2016-07-26 14:01:24 --> Migrating to version: 1
INFO - 2016-07-26 14:01:25 --> Migrating to version: 2
INFO - 2016-07-26 14:01:25 --> Migrating to version: 3
INFO - 2016-07-26 14:01:25 --> Migrating to version: 4
INFO - 2016-07-26 14:01:25 --> Migrating to version: 5
INFO - 2016-07-26 14:01:25 --> Migrating to version: 6
INFO - 2016-07-26 14:01:25 --> Migrating to version: 7
INFO - 2016-07-26 14:01:25 --> Migrating to version: 8
INFO - 2016-07-26 14:01:25 --> Migrating to version: 9
INFO - 2016-07-26 14:01:25 --> Migrating to version: 10
INFO - 2016-07-26 14:01:25 --> Migrating to version: 11
INFO - 2016-07-26 14:01:25 --> Migrating to version: 12
INFO - 2016-07-26 14:01:25 --> Migrating to version: 13
INFO - 2016-07-26 14:01:25 --> Migrating to version: 14
INFO - 2016-07-26 14:01:25 --> Migrating to version: 15
INFO - 2016-07-26 14:01:25 --> Migrating to version: 16
INFO - 2016-07-26 14:01:25 --> Migrating to version: 17
INFO - 2016-07-26 14:01:25 --> Migrating to version: 18
INFO - 2016-07-26 14:01:26 --> Migrating to version: 19
INFO - 2016-07-26 14:01:26 --> Migrating to version: 20
INFO - 2016-07-26 14:01:26 --> Migrating to version: 21
INFO - 2016-07-26 14:01:26 --> Migrating to version: 22
INFO - 2016-07-26 14:01:26 --> Migrating to version: 23
INFO - 2016-07-26 14:01:26 --> Migrating to version: 24
INFO - 2016-07-26 14:01:26 --> Migrating to version: 25
INFO - 2016-07-26 14:01:26 --> Migrating to version: 26
INFO - 2016-07-26 14:01:26 --> Migrating to version: 27
INFO - 2016-07-26 14:01:26 --> Migrating to version: 28
INFO - 2016-07-26 14:01:26 --> Migrating to version: 29
INFO - 2016-07-26 14:01:26 --> Migrating to version: 30
INFO - 2016-07-26 14:01:26 --> Migrating to version: 31
INFO - 2016-07-26 14:01:26 --> Migrating to version: 32
INFO - 2016-07-26 14:01:26 --> Migrating to version: 33
INFO - 2016-07-26 14:01:26 --> Migrating to version: 34
INFO - 2016-07-26 14:01:26 --> Migrating to version: 35
INFO - 2016-07-26 14:01:26 --> Migrating to version: 36
INFO - 2016-07-26 14:01:26 --> Migrating to version: 37
INFO - 2016-07-26 14:01:26 --> Migrating to version: 38
INFO - 2016-07-26 14:01:26 --> Migrating to version: 39
INFO - 2016-07-26 14:01:26 --> Migrating to version: 40
INFO - 2016-07-26 14:01:26 --> Migrating to version: 41
INFO - 2016-07-26 14:01:26 --> Migrated to 41 successfully.
INFO - 2016-07-26 14:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 14:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 14:29:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-07-26 14:29:07 --> 1146 - Table 'repeater.sessions' doesn't exist [ SELECT * FROM `sessions` WHERE `session_id` = '7c61d550c2a482833e86d3f0caff63f5' ] in /var/www/local.gmorepeater.jp/fuel/core/classes/database/mysqli/connection.php on line 292
WARNING - 2016-07-26 15:38:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-07-26 15:39:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 15:39:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:39:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:39:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-26 15:39:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:39:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:39:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-26 15:39:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:39:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:39:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-26 15:39:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:39:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-26 15:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 15:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 15:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 15:56:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 15:56:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 15:56:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 16:23:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 16:23:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 16:23:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 16:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:38:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 16:38:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:38:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 16:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 16:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 16:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 16:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 16:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:00:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:00:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:00:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:00:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:00:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:01:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:01:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:01:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:02:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:03:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:04:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:04:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:04:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:04:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:04:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:04:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:04:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 17:04:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:04:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:57:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 17:57:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:57:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 17:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 18:10:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 18:10:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 18:10:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 18:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 19:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 19:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 19:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 19:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:00:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:00:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:01:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:02:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:03:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-26 20:10:15 --> Fuel\Core\Request::execute - Setting main Request
