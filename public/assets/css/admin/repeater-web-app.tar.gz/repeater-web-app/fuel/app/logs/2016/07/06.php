<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-06 00:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 00:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 00:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 00:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:39:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:39:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:39:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 00:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:50:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 00:50:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:50:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 00:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 00:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:56:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:57:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 00:57:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:57:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 00:57:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 00:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 00:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:00:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:00:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:00:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:00:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:05:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:05:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:05:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:07:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:07:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:07:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:07:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:07:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:07:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:07:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:10:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:10:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:10:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:11:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:11:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:11:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:11:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:12:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:12:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:12:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:12:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:12:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:12:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:12:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:12:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:12:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:13:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:13:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:13:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:13:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:13:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:13:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:14:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:14:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:14:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:31:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:31:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:32:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:32:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:32:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:34:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:34:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:36:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:36:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:36:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:37:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:37:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:40:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:40:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:40:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:40:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:40:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:40:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:40:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:40:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:42:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:42:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:43:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:43:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:43:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:48:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:51:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:52:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:52:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:52:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:53:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:53:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:53:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:53:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:54:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:54:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:54:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:54:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:54:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:54:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:54:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:54:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:54:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:55:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:55:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:55:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:57:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 01:57:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:57:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:57:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 01:57:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 01:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 01:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:01:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 02:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:03:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 02:03:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:03:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 02:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:08:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:08:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:08:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:10:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:10:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:10:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:10:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:12:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:12:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:12:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:14:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:21:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:21:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:21:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:23:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:23:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:23:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:24:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:24:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:24:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:24:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:25:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:25:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:25:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:25:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:25:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:26:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:26:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:26:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:28:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:28:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:28:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:28:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:29:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:29:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:29:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:31:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:31:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:31:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:32:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:32:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:32:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:32:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:34:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:34:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:34:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:37:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:37:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:39:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:39:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:39:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:40:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:41:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:43:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:44:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:44:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:44:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:47:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:48:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:48:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:49:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:49:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:49:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:49:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:49:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:49:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:50:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:50:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:50:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:50:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:51:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:51:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:51:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:52:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:52:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:52:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:52:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:53:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:53:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:53:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:56:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:56:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:58:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:58:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:58:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:58:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 02:59:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 02:59:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 02:59:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 02:59:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:00:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:00:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:00:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:04:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:05:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:05:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:05:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:14:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:14:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:14:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:14:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:14:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:14:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:16:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:16:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:16:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:17:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:17:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:17:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:18:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:18:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:19:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:20:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:20:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:22:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:22:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:22:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:23:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:23:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:23:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 03:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:24:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:24:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:24:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:24:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 03:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 03:26:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 03:26:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 03:26:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 10:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 10:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:44:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 10:44:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:44:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:44:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:44:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:44:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:44:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 10:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:47:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:47:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:47:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:47:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:47:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:47:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:47:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:47:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:47:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:47:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:47:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:47:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:47:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:47:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:47:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:54:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:54:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:54:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:55:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:55:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:55:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:55:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:55:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:55:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:55:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:55:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:55:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:56:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:56:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:56:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:58:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:58:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:58:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:58:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:58:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:58:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:58:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 10:59:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 10:59:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:59:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 10:59:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 10:59:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 10:59:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:02:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:02:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:02:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:03:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:03:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:03:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:04:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:04:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:04:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:05:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:05:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:05:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:06:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:06:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:06:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:08:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:08:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:08:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:08:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:08:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:08:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:08:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:08:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:08:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:09:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:09:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:09:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:15:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 11:15:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:15:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:15:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:15:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:15:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:19:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:19:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:19:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:20:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:20:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:20:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:20:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:21:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:21:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:22:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:22:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:22:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:22:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:22:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:22:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 11:29:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:29:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:30:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:30:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:30:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:33:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:33:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:34:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:34:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:34:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:35:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:35:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:35:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:35:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:35:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:35:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:35:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:36:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:36:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:36:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:36:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:36:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:36:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 11:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:48:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:48:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:48:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:50:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 11:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 11:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:01:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:05:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:05:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:05:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 12:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:16:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:18:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:18:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:18:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:21:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:21:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:21:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:21:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:28:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:28:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:31:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:31:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:31:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:31:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:34:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:34:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:34:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:34:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:35:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:35:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:35:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:35:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:36:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:36:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:36:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:38:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:38:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:38:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:38:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:39:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:39:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:41:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:42:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:42:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:42:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:43:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:43:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:43:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:44:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:44:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:44:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:44:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 12:44:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:44:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:44:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:44:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:44:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:47:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:47:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:47:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:47:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:47:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:49:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:49:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:49:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:49:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:49:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:51:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 12:51:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:51:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:52:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:52:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:52:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 12:52:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 12:52:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 12:52:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-07-06 13:16:43 --> Parsing Error - syntax error, unexpected ';', expecting ')' in /var/www/local.gmorepeater.jp/fuel/app/config/routes.php on line 165
ERROR - 2016-07-06 13:16:54 --> Parsing Error - syntax error, unexpected ';', expecting ')' in /var/www/local.gmorepeater.jp/fuel/app/config/routes.php on line 165
INFO - 2016-07-06 13:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:18:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:18:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-06 13:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:18:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 13:18:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 13:18:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:18:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:18:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:18:50 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-06 13:19:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-06 13:19:37 --> Migrate class initialized
WARNING - 2016-07-06 13:20:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-06 13:20:56 --> Migrate class initialized
INFO - 2016-07-06 13:20:56 --> Migrating to version: 24
INFO - 2016-07-06 13:20:56 --> Migrating to version: 25
INFO - 2016-07-06 13:20:56 --> Migrating to version: 26
INFO - 2016-07-06 13:20:57 --> Migrating to version: 27
INFO - 2016-07-06 13:20:57 --> Migrating to version: 28
INFO - 2016-07-06 13:20:57 --> Migrating to version: 29
INFO - 2016-07-06 13:20:57 --> Migrating to version: 30
INFO - 2016-07-06 13:20:57 --> Migrated to 30 successfully.
INFO - 2016-07-06 13:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:21:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:21:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:21:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:21:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:21:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:21:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:21:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:21:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:21:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:21:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:21:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:21:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:21:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:23:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:23:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:23:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:23:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 13:23:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:23:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:28:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:28:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:28:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:29:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 13:29:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 13:29:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 13:29:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:30:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:30:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:30:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:30:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:30:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 13:30:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:30:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 13:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 13:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 13:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 13:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 13:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 14:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 14:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:42:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 14:42:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:42:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:42:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 14:42:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:42:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:42:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 14:42:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:42:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 14:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:42:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 14:42:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:42:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:42:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 14:42:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:42:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 14:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:43:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 14:43:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:43:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 14:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 14:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 14:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 15:29:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:29:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:29:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:29:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:30:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:30:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:30:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:31:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:32:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:32:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-07-06 15:32:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-07-06 15:32:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 15:32:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:32:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:32:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:32:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:32:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-06 15:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:34:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:35:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:35:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:35:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:35:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:35:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:35:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:35:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:41:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:41:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:41:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:41:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:44:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:44:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:44:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:44:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:44:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:45:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:45:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:45:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:45:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 15:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 15:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 15:53:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 15:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 16:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:18:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:20:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupon"
INFO - 2016-07-06 16:20:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:20:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:20:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-06 16:20:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:20:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:20:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupon"
INFO - 2016-07-06 16:20:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:20:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:20:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-06 16:20:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:20:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:20:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:20:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:20:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:20:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:20:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:20:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:21:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:21:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:21:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:21:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:21:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:21:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:21:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:21:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:21:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:22:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 16:32:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 16:32:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 16:32:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 16:32:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:13:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:13:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:14:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-06 18:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:14:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:14:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-06 18:15:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:15:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:15:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:15:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 18:15:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:15:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:16:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:16:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:16:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:46:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 18:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 18:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:46:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 18:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:46:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:46:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:46:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:54:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:54:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:54:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupon"
INFO - 2016-07-06 18:54:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:54:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-06 18:54:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:54:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 18:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:56:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:56:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupon"
INFO - 2016-07-06 18:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-06 18:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupon"
INFO - 2016-07-06 18:56:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-06 18:56:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupon"
INFO - 2016-07-06 18:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-06 18:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupon"
INFO - 2016-07-06 18:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-06 18:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:56:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:57:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:57:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:57:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:57:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:57:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:58:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:58:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:58:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 18:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 18:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 18:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:03:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:03:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:03:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:07:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:07:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:07:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 19:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 19:08:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:08:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:09:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:09:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:09:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:09:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:09:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:09:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:13:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:13:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:13:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:13:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:13:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:13:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:13:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:13:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:13:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:14:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 19:14:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:14:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 19:14:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:14:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:18:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:18:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:20:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:20:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:20:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:20:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:20:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:20:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:20:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:20:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:20:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:21:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:21:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:21:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:21:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:21:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:21:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:21:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:21:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:21:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:21:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-06 19:23:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:23:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:23:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:23:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:23:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:26:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:26:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:26:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:28:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:28:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:28:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:29:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:30:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:30:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:30:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:32:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:34:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:34:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:34:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:39:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:39:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:39:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:39:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:42:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:46:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:46:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:46:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:47:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:47:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:47:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 19:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:48:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:48:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-06 19:48:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-06 19:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-06 19:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-06 19:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-06 19:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-06 19:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-06 19:49:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-06 19:49:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-06 19:49:16 --> Fuel\Core\Request::execute - Setting main Request
