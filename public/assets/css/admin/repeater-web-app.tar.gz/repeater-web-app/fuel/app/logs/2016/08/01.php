<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-08-01 00:03:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:03:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:03:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:03:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:03:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:03:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:03:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:04:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:04:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:05:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:05:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:05:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:05:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:17:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:17:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:22:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:22:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:22:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:29:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:29:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:29:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:31:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:35:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:35:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:35:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:53:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 00:53:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:53:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 00:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 00:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 00:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:04:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:04:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:04:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:07:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:07:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:08:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:08:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:08:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:08:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:08:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:10:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:10:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:17:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:17:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:17:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:21:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:21:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:27:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:27:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:27:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:27:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:27:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:27:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:31:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:31:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:31:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:31:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:31:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:40:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:40:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:40:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:41:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:49:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:49:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:49:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:49:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:49:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 01:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 01:56:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 01:56:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 01:56:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-01 10:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-01 10:41:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-01 10:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:42:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:42:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:45:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:45:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:45:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:51:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:51:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:51:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:53:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:57:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:57:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:57:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:57:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:57:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:57:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:57:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:57:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:58:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:58:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:58:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:59:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:59:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 10:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 10:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:00:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:00:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:00:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:00:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:01:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:03:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:03:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:03:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:03:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:04:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:04:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:04:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:04:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:04:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:04:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:05:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:05:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:05:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:05:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:06:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:06:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:06:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:06:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:06:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:06:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:08:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:08:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:08:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:09:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:09:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:12:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:12:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:12:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:12:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:12:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:12:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:12:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:13:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:13:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:13:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:14:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:14:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:14:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:14:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:14:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:15:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:15:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:16:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:16:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:16:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:16:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:20:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:20:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:20:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:23:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:24:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:24:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:26:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:26:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:26:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:26:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:29:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:29:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:29:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:29:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:29:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:29:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:30:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:30:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:30:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:30:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:30:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:30:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:30:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:31:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:31:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:31:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:31:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:31:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:31:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:32:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:32:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:32:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:33:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:33:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:33:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:33:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:33:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:34:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:34:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:34:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:39:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:39:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:39:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:39:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:39:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:39:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:40:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:40:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:40:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:41:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:41:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:41:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:41:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:41:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:41:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:42:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:42:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:42:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:42:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:42:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:42:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:43:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:44:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:45:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:45:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:45:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:45:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:45:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:46:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:46:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:46:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:52:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:52:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:52:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:54:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:54:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:54:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:54:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:54:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:54:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:55:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 11:55:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:55:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 11:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 11:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 11:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:04:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:05:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:05:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:05:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:05:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:05:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:08:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:08:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:08:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:08:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:08:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:08:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:08:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:08:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:13:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:13:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:13:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:13:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:14:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:14:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:14:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:14:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:14:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:15:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:15:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:15:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:16:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:16:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:16:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:16:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:16:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:16:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:17:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:20:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:23:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:23:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:23:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:25:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:25:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:25:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:27:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:27:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:27:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:27:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:27:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:27:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:27:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:28:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:28:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:28:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:28:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:40:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:40:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 12:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:40:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:40:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:40:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:41:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:47:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 12:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 12:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 12:52:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 12:52:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:52:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 12:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 12:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 12:53:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 12:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 12:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 12:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 12:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 12:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:03:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:03:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:05:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:05:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:13:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:13:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:13:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:14:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:14:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:14:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:17:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:17:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:18:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:19:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:21:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:23:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:24:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:24:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:24:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:24:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:25:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:26:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:26:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:26:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:29:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:33:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:33:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:33:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:33:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:33:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:33:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:34:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:36:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:38:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:38:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:38:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:38:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:39:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:39:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:40:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:43:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:43:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:43:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:44:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:44:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:44:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:44:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:44:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:44:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:45:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:46:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:46:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:58:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:58:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:58:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:58:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 13:59:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 13:59:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 13:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 13:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 13:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 13:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 14:00:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 14:00:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 14:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:42:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 14:42:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:42:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 14:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:29:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 15:29:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:29:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 15:31:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 15:31:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 15:31:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 15:31:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:31:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:31:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 15:32:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:32:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-01 15:32:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:32:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:32:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:32:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:32:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 15:33:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 15:33:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 15:33:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:07:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:07:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:07:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-08-01 16:07:53 --> Parsing Error - syntax error, unexpected ')' in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/store.php on line 246
INFO - 2016-08-01 16:08:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
ERROR - 2016-08-01 16:08:00 --> Parsing Error - syntax error, unexpected ')' in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/store.php on line 246
INFO - 2016-08-01 16:08:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:08:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:08:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:09:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 16:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 16:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:10:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:10:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:10:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/3"
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/5"
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/6"
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/4"
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/9"
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/undefined"
INFO - 2016-08-01 16:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-08-01 16:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/undefined"
INFO - 2016-08-01 16:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-08-01 16:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:25:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:25:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:25:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:26:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:26:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:27:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:27:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:27:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:29:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:29:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:31:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:31:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:31:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:31:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:31:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:31:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:31:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:33:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:33:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:33:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:34:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:34:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:34:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:35:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:35:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:35:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:35:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:35:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:36:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:36:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:36:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:37:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:37:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:37:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:37:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:37:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:37:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:42:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:42:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:42:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:42:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:42:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:42:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:44:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:44:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:44:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:44:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:47:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:47:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:48:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:49:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:49:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:49:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:49:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:49:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:49:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:49:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:49:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:50:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:50:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:50:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:50:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:50:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:51:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:51:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:51:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:52:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:54:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:54:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:54:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:55:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:55:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:55:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:55:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:55:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:55:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:55:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:55:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:56:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:58:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:58:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:58:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:59:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 16:59:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 16:59:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 16:59:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 16:59:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 16:59:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:00:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 17:00:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:00:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:02:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 17:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:02:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:02:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:02:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:02:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:05:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 17:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:05:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:06:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:06:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:07:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:07:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:07:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:07:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:07:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:07:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:08:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:10:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:10:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:10:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:14:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:14:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:14:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:14:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:17:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:17:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:17:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:18:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:18:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:18:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:18:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:18:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:19:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:19:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:19:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:19:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:20:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:20:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:20:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:22:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:22:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:22:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:22:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:24:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:25:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:25:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:25:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:25:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:25:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:25:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:35:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:35:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:36:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:36:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:36:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:37:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:37:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:37:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:37:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:37:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:37:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:37:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:38:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:39:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:39:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:39:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:39:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:39:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:39:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 17:39:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:39:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:40:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 17:40:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:40:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:40:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:40:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:40:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:41:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:42:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:42:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:42:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:42:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:42:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:43:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:43:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:43:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:44:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:44:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:44:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:44:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:44:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:44:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:44:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:44:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:44:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:45:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:45:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:45:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:45:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:45:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:45:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:45:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:45:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:45:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:45:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:45:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:45:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:45:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:45:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:45:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:45:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:45:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:46:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:46:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:46:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:46:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:47:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:47:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:47:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:47:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:47:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:48:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:48:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 17:50:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:50:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 17:50:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:50:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:51:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:51:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:51:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 17:51:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 17:51:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 17:51:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:03:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:03:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:03:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:03:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:03:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:03:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:03:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:03:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:03:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:04:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:04:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:04:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:04:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:04:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:04:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:05:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:05:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:05:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:05:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:05:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:05:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:05:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:09:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:09:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:09:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:09:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:09:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:09:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:17:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:17:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:20:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:20:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:20:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:20:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:20:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:20:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:20:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:20:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 18:20:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:20:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 18:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:23:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 18:23:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:23:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:23:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 18:23:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:23:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:24:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:25:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:25:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:25:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:25:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:25:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:37:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:40:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:49:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:49:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:49:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:50:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 18:50:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:50:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:51:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:51:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 18:51:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:51:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:52:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 18:52:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:52:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 18:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 18:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 18:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-01 19:02:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:02:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:02:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:02:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 19:02:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:02:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:04:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:04:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:04:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:04:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:04:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:06:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:06:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:06:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:09:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:09:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:09:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:09:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:09:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:09:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:09:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-01 19:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:10:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:10:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:10:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:10:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:10:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:11:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:11:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:11:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:16:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:16:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:16:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:18:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:18:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:20:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:20:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:20:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:20:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:21:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:21:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:21:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 19:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:21:56 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-08-01 19:25:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-08-01 19:25:53 --> Migrate class initialized
INFO - 2016-08-01 19:25:53 --> Migrating to version: 42
INFO - 2016-08-01 19:25:53 --> Migrating to version: 43
INFO - 2016-08-01 19:25:53 --> Migrating to version: 44
INFO - 2016-08-01 19:25:53 --> Migrating to version: 45
INFO - 2016-08-01 19:25:53 --> Migrated to 45 successfully.
INFO - 2016-08-01 19:32:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:32:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:32:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:32:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:32:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:32:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:32:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:37:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:37:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-01 19:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:38:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:38:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:38:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:38:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 19:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:39:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:39:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:39:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:39:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:40:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 19:40:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 19:40:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:40:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 19:40:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:40:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:41:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-01 19:41:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:41:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:41:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:41:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:41:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:41:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:43:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:43:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:43:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:43:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:43:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:43:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:43:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:45:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-01 19:45:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:45:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:45:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-01 19:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:45:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:45:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:45:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-01 19:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-01 19:56:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-01 19:56:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-01 19:56:03 --> Fuel\Core\Request::execute - Setting main Request
