<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-08-11 12:11:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:11:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-11 12:11:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-11 12:11:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:11:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-08-11 12:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/analysis"
INFO - 2016-08-11 12:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 12:13:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:13:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:13:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:13:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:13:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:13:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:14:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 12:14:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:14:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 12:14:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:14:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 12:14:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:14:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:28:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:28:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 12:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-08-11 12:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 12:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-08-11 12:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:54:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-11 12:54:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-08-11 12:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-08-11 12:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-08-11 12:54:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-08-11 12:54:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-08-11 12:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 12:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 12:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-08-11 12:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 12:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:36:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:36:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:36:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-11 15:36:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:36:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-11 15:37:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:37:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/analysis"
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-08-11 15:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/1/store/0"
INFO - 2016-08-11 15:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:37:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/1/store/0"
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:37:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:37:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:37:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/1/store/0"
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:38:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/1/store/0"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:43:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/1/store/0"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:43:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:44:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:46:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:46:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:46:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 15:48:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:48:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:50:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/map"
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:55:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 15:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:03:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:04:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:04:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:06:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:07:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:07:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:07:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:07:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:08:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "media/1/brand_code_1/xvbgnghh/example"
INFO - 2016-08-11 16:08:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:08:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "media/coupon"
INFO - 2016-08-11 16:10:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:10:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:19:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/3"
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-11 16:37:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-11 16:37:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:37:55 --> Fuel\Core\Request::execute - Setting main Request
