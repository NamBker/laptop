<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-10 23:08:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:08:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-10 23:08:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-10 23:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-10 23:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:08:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:29:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:29:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:29:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:29:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:32:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:32:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:32:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:32:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:32:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:32:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:35:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-10 23:49:56 --> Fuel\Core\Request::execute - Setting main Request
