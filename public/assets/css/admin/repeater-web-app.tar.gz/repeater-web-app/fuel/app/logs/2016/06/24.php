<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-06-24 16:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-24 16:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-24 16:02:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:02:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:03:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:03:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:03:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:04:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:04:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:05:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:05:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:05:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:05:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:06:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:06:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-24 16:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-24 16:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-24 16:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:06:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:06:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:06:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:06:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:06:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-24 16:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:07:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-24 16:07:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:07:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-24 16:09:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-24 16:09:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-24 16:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-24 16:09:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:09:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:15:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-24 16:15:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:15:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:15:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:20:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:20:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:20:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:22:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:22:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:34:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:34:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:34:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:34:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:34:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:34:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:34:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:34:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:34:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:56:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:56:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:56:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 16:57:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 16:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 16:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 16:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 17:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:03:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:03:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:03:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 17:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 17:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 17:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 17:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 17:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/daily/store"
INFO - 2016-06-24 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-06-24 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:33:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/daily/store"
INFO - 2016-06-24 18:33:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:33:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:33:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-06-24 18:33:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:33:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:34:03 --> Compile Error - Cannot redeclare class Api\Controller_DailyStore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:34:53 --> Compile Error - Cannot redeclare class Api\Controller_DailyStore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:36:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:36:11 --> Compile Error - Cannot redeclare class Api\Controller_DailyStore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:38:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:38:39 --> Compile Error - Cannot redeclare class Api\Controller_DailyStore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:38:42 --> Compile Error - Cannot redeclare class Api\Controller_DailyStore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:40:53 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:41:30 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:42:41 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:42:41 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:42:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:42:42 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:42:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:42:43 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:42:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:42:58 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:42:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:42:59 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:42:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:42:59 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:00 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:42 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:43 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:43 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:43 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:43 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:45 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:46 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:43:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
ERROR - 2016-06-24 18:43:52 --> Compile Error - Cannot redeclare class Api\Controller_Dailystore in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/daily/store.php on line 0
INFO - 2016-06-24 18:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-24 18:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-24 18:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:49:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:49:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:49:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-24 18:50:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:50:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-24 18:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 18:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 18:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 18:57:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 18:57:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 18:57:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:57:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:57:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:57:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:57:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:58:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:58:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:58:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:58:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:58:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:58:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:58:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 18:58:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 18:58:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 18:58:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:09:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:09:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:09:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:09:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:09:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:09:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:13:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:13:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:13:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:13:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:16:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:16:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:16:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:17:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:17:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:17:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:20:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:20:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:20:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:22:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:22:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:22:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:22:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:22:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:22:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:22:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:26:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:26:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:26:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:27:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:27:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:27:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:27:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:35:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:35:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:38:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:39:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:39:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:39:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:39:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:39:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:39:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:44:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:44:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:44:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:44:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:44:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:45:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:45:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:47:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:51:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:53:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:53:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:55:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:55:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:56:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:56:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:56:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 19:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:59:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:59:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:59:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:59:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:59:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:59:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 19:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 19:59:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 19:59:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:00:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:00:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:00:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:00:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:00:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:03:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:04:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:04:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:04:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:07:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:07:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:07:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:07:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:07:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:08:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:08:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:08:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:15:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:15:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:16:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:16:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:16:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:16:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:16:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:17:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-24 20:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:26:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:27:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:27:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:30:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:42:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:42:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:42:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:42:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:43:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:43:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:44:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:45:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:45:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:45:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-24 20:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:46:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:46:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:46:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-24 20:46:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-24 20:46:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-24 20:46:32 --> Fuel\Core\Request::execute - Setting main Request
