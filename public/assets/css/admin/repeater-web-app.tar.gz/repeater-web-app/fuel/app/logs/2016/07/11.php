<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-11 00:09:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 00:09:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:09:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires/1"
INFO - 2016-07-11 00:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-07-11 00:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 00:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:09:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 00:09:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:09:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 00:13:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 00:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 00:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 00:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:04:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:04:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:05:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:12:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:21:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 01:21:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:21:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires/3"
INFO - 2016-07-11 01:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-07-11 01:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 01:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:25:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:25:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:30:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:32:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:32:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:32:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:32:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:32:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:32:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:33:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:41:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:47:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:47:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:48:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:49:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:53:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:55:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 01:55:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:55:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:55:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires/11"
INFO - 2016-07-11 01:55:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-07-11 01:55:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:55:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 01:55:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 01:55:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:00:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 02:00:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:00:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 02:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:02:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 02:02:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:02:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 02:03:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 02:03:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:42:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-11 10:42:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-11 10:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:42:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 10:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 10:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 10:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 10:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 10:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:53:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:53:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:53:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:54:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:54:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:54:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:57:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 10:57:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:05:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:12:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:12:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:12:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:12:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:17:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:31:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:31:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:32:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:32:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:32:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:32:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:39:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:39:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:39:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:39:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:39:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:39:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:39:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:39:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:40:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:55:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:57:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:57:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:57:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:58:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:58:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:58:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 11:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 12:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires/1"
INFO - 2016-07-11 12:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-07-11 12:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 12:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:03:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:03:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:21:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:21:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:21:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:29:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:29:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:29:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:33:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:35:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires/3"
INFO - 2016-07-11 12:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-07-11 12:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:37:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:37:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:37:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:38:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:38:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:38:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:38:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:38:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:38:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:51:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:51:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:51:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:52:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:52:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:53:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:54:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:54:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:54:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:55:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:55:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:55:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:55:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:55:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:59:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:59:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 12:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:00:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:00:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:00:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:02:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:02:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:03:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:03:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:03:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:03:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:04:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:04:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:04:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:07:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:07:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:09:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:13:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:13:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:13:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:25:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:25:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:25:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:25:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:34:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:34:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:34:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:37:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:37:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:37:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:37:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:49:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:49:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:49:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:50:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:50:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:50:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:51:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:51:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:53:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:53:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:53:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:57:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:57:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:57:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:57:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:57:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:57:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:59:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:59:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 13:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 13:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 13:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 13:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 14:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 14:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 14:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 14:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 15:27:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:27:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:27:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 15:27:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:27:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:41:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 15:41:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:41:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 15:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:56:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 15:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 16:32:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 16:32:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 16:32:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 16:32:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:23:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:23:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:23:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:31:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:31:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:31:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:32:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:32:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:32:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:32:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:33:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:33:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:33:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:34:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:34:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:34:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:36:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:36:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:36:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:48:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:48:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:48:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:48:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:52:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:52:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:52:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 18:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:01:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:07:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:27:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:29:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:29:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:29:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:41:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:54:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:54:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:54:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:55:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:55:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:55:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:55:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:57:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:59:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:59:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:59:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:59:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:59:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 19:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 19:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 19:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 19:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 19:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 19:59:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 19:59:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 19:59:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:00:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 20:00:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 20:01:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:01:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:01:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 20:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:01:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:02:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-11 20:03:06 --> Fuel\Core\Request::execute - Setting main Request
