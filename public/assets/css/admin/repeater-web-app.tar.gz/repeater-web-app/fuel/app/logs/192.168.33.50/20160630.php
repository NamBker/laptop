<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

DEBUG - 2016-06-30 00:22:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:22:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:22:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:22:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:22:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:22:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:22:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:22:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:22:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:22:16 --> brand/index called
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:22:17 --> store/index called
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:22:17 --> user/index called
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:22:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:22:17 --> company/index called
DEBUG - 2016-06-30 00:23:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:23:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:23:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:23:32 --> brand/index called
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:23:32 --> user/index called
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:23:32 --> company/index called
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:23:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:23:32 --> store/index called
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:25:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:25:46 --> company/index called
INFO - 2016-06-30 00:25:46 --> user/index called
INFO - 2016-06-30 00:25:46 --> brand/index called
INFO - 2016-06-30 00:25:46 --> store/index called
DEBUG - 2016-06-30 00:26:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:26:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:26:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:26:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:26:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:26:31 --> company/index called
INFO - 2016-06-30 00:26:31 --> brand/index called
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:26:31 --> store/index called
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:26:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:26:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:26:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:26:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:26:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:26:31 --> user/index called
DEBUG - 2016-06-30 00:26:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:27:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
INFO - 2016-06-30 00:27:25 --> user/index called
DEBUG - 2016-06-30 00:27:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:27:25 --> company/index called
INFO - 2016-06-30 00:27:25 --> brand/index called
INFO - 2016-06-30 00:27:25 --> store/index called
DEBUG - 2016-06-30 00:27:25 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:27:25 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:27:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:27:26 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:27:26 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:27:28 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:27:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:27:37 --> user/index called
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:27:37 --> company/index called
INFO - 2016-06-30 00:27:37 --> brand/index called
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:27:38 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:27:38 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:27:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:27:38 --> store/index called
DEBUG - 2016-06-30 00:27:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:27:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:27:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:27:38 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:28:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:28:06 --> store/index called
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:28:06 --> user/index called
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:28:06 --> company/index called
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:28:06 --> brand/index called
DEBUG - 2016-06-30 00:28:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:28:08 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:28:08 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:28:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:28:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:28:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:28:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:28:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:28:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:28:46 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 00:28:46 --> user/index called
DEBUG - 2016-06-30 00:28:46 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 00:28:46 --> company/index called
DEBUG - 2016-06-30 00:28:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:28:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
INFO - 2016-06-30 00:28:46 --> brand/index called
DEBUG - 2016-06-30 00:28:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:28:48 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:28:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:28:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:28:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:28:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:28:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:28:50 --> store/index called
DEBUG - 2016-06-30 00:31:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:31:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:31:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:31:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:31:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:31:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:31:34 --> brand/index called
INFO - 2016-06-30 00:31:34 --> store/index called
DEBUG - 2016-06-30 00:31:34 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:31:34 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 00:31:34 --> user/index called
INFO - 2016-06-30 00:31:34 --> company/index called
DEBUG - 2016-06-30 00:31:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:31:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:31:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:31:35 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:32:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:32:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:32:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:32:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:32:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:32:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:32:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:32:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:32:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:32:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:32:33 --> brand/index called
INFO - 2016-06-30 00:32:33 --> user/index called
INFO - 2016-06-30 00:32:33 --> company/index called
INFO - 2016-06-30 00:32:33 --> store/index called
DEBUG - 2016-06-30 00:32:33 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:32:33 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:32:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:32:33 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:32:33 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:32:35 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:33:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:33:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:33:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:33:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:33:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:33:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:33:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:33:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:33:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:33:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:33:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:33:20 --> brand/index called
DEBUG - 2016-06-30 00:33:20 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 00:33:20 --> user/index called
INFO - 2016-06-30 00:33:20 --> company/index called
DEBUG - 2016-06-30 00:33:20 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 00:33:20 --> store/index called
DEBUG - 2016-06-30 00:33:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:33:20 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:33:20 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:33:22 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:42:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:42:15 --> brand/index called
INFO - 2016-06-30 00:42:15 --> store/index called
DEBUG - 2016-06-30 00:42:15 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 00:42:15 --> user/index called
DEBUG - 2016-06-30 00:42:15 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 00:42:15 --> company/index called
DEBUG - 2016-06-30 00:42:15 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:42:15 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:42:15 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:42:16 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:42:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:42:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:42:35 --> user/index called
INFO - 2016-06-30 00:42:35 --> store/index called
INFO - 2016-06-30 00:42:35 --> brand/index called
INFO - 2016-06-30 00:42:35 --> company/index called
DEBUG - 2016-06-30 00:42:35 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:42:35 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:42:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:42:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:42:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:42:37 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:43:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:43:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:43:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:43:45 --> user/index called
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:43:45 --> company/index called
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:43:45 --> store/index called
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:43:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:43:45 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:43:45 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:43:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:43:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:43:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:43:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:43:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:43:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:43:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:43:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:43:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:43:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:43:47 --> brand/index called
DEBUG - 2016-06-30 00:44:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:44:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:44:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:44:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:44:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:44:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:44:02 --> user/index called
DEBUG - 2016-06-30 00:44:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:44:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:44:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:44:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:44:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:44:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:44:04 --> company/index called
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:44:05 --> store/index called
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:44:05 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:44:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:44:05 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 00:44:05 --> brand/index called
DEBUG - 2016-06-30 00:44:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:44:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:44:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:44:07 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:50:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:50:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:50:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:50:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:50:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:50:51 --> store/index called
INFO - 2016-06-30 00:50:51 --> user/index called
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:50:51 --> company/index called
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:50:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:50:51 --> brand/index called
DEBUG - 2016-06-30 00:51:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:51:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:51:22 --> brand/index called
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:51:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:51:22 --> company/index called
DEBUG - 2016-06-30 00:51:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:51:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:51:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:51:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:51:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:51:23 --> user/index called
DEBUG - 2016-06-30 00:51:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:51:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:51:24 --> store/index called
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:51:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:51:24 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:51:24 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:51:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:51:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:51:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:51:25 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:53:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:53:00 --> user/index called
INFO - 2016-06-30 00:53:00 --> company/index called
DEBUG - 2016-06-30 00:53:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:53:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:53:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:53:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:53:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:53:01 --> brand/index called
DEBUG - 2016-06-30 00:53:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:53:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:53:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:53:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:53:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:53:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:53:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:53:02 --> store/index called
DEBUG - 2016-06-30 00:53:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:53:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:53:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:53:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:53:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:53:03 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:53:03 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:53:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:53:03 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:53:03 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:53:04 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:55:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:55:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:55:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:55:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:55:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:55:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:55:23 --> user/index called
INFO - 2016-06-30 00:55:23 --> store/index called
INFO - 2016-06-30 00:55:23 --> brand/index called
DEBUG - 2016-06-30 00:55:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 00:55:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 00:55:23 --> company/index called
DEBUG - 2016-06-30 00:55:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:55:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:55:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:55:24 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 00:56:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:56:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:56:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:56:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:56:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 00:56:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:56:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:56:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:56:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:56:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 00:56:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 00:56:22 --> company/index called
INFO - 2016-06-30 00:56:22 --> brand/index called
INFO - 2016-06-30 00:56:22 --> user/index called
DEBUG - 2016-06-30 00:56:22 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 00:56:22 --> store/index called
DEBUG - 2016-06-30 00:56:22 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 00:56:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 00:56:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 00:56:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 00:56:24 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:02:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:02:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:02:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:02:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:02:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:02:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 01:02:39 --> store/index called
DEBUG - 2016-06-30 01:02:39 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:02:39 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 01:02:39 --> brand/index called
INFO - 2016-06-30 01:02:39 --> company/index called
INFO - 2016-06-30 01:02:39 --> user/index called
DEBUG - 2016-06-30 01:02:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:02:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:02:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:02:43 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:03:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:03:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:03:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:03:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:03:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:03:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:03:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:03:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:03:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:03:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:03:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 01:03:53 --> company/index called
INFO - 2016-06-30 01:03:53 --> store/index called
INFO - 2016-06-30 01:03:53 --> user/index called
INFO - 2016-06-30 01:03:53 --> brand/index called
DEBUG - 2016-06-30 01:03:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:03:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:03:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:03:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:03:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:03:54 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:04:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:04:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:04:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:04:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:04:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:04:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:04:22 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:04:22 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:04:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:04:22 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:04:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:04:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:04:22 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:04:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 01:04:26 --> brand/index called
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 01:04:26 --> user/index called
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:04:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 01:04:26 --> store/index called
DEBUG - 2016-06-30 01:04:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:04:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:04:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:04:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:04:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:04:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:04:27 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:04:27 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:04:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:04:27 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:04:27 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:04:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:04:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:04:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:04:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:04:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 01:04:28 --> company/index called
DEBUG - 2016-06-30 01:04:29 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:04:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:04:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:04:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:04:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:04:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:04:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:04:55 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:04:55 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:04:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:04:55 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:04:55 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:04:55 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:04:55 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:05:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 01:05:02 --> user/index called
INFO - 2016-06-30 01:05:02 --> company/index called
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:02 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:05:02 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:05:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:05:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 01:05:02 --> store/index called
INFO - 2016-06-30 01:05:02 --> brand/index called
DEBUG - 2016-06-30 01:05:03 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:05:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:12 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:05:12 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:05:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:05:12 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:05:12 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:05:12 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:05:13 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:05:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:20 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:05:20 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:05:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:05:20 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:05:20 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:05:20 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:05:20 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:05:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:27 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:05:27 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:05:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:05:27 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:05:27 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:05:27 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:05:27 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:05:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:40 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:05:40 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:05:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:05:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:05:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:05:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:05:40 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:05:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:45 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:05:45 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:05:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:05:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:05:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:05:45 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:05:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:05:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:05:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:05:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:05:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:05:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:05:57 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:05:57 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:05:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:05:57 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:05:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:05:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:05:58 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:06:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:06:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:06:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:06:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:06:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:06:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:06:06 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:06:06 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:06:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:06:06 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:06:06 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:06:06 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:06:07 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:06:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:06:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:06:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:06:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:06:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:06:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:06:15 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:06:15 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:06:15 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:06:15 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:06:15 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:06:15 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:06:15 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:06:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:06:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:06:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:06:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:06:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:06:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:06:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:06:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:06:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:06:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:06:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:06:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:06:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:06:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:06:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:06:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:06:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:06:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:06:41 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:06:41 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:06:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:06:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:06:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:06:42 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:10:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:10:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:10:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:10:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:10:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:10:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:10:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:10:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:10:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:10:18 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:10:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:10:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:10:19 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:10:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:10:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:10:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:10:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:10:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:10:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:10:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:10:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:10:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:10:31 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 01:10:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:10:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:10:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:10:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:10:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:10:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:10:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:10:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:10:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:10:38 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:10:38 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:10:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:10:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:10:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:10:38 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:10:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:10:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:10:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:10:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:10:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:10:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:10:44 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:10:44 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:10:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:10:44 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:10:44 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:10:44 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 01:10:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 01:10:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 01:10:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 01:10:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 01:10:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 01:10:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 01:10:50 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 01:10:50 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 01:10:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 01:10:50 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 01:10:50 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 01:10:50 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:44:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:44:40 --> brand/index called
INFO - 2016-06-30 10:44:40 --> store/index called
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:44:40 --> user/index called
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:44:40 --> company/index called
DEBUG - 2016-06-30 10:44:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:44:48 --> user/index called
INFO - 2016-06-30 10:44:48 --> brand/index called
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:44:48 --> company/index called
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:44:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 10:44:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:44:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:44:48 --> store/index called
DEBUG - 2016-06-30 10:44:49 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:44:49 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:44:49 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 10:44:49 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:45:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:45:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:45:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:45:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:45:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:45:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:45:05 --> store/index called
INFO - 2016-06-30 10:45:05 --> user/index called
INFO - 2016-06-30 10:45:05 --> brand/index called
INFO - 2016-06-30 10:45:05 --> company/index called
DEBUG - 2016-06-30 10:45:06 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 10:45:07 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 10:45:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:45:09 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:45:09 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 10:45:11 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:46:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:46:16 --> company/index called
INFO - 2016-06-30 10:46:16 --> store/index called
INFO - 2016-06-30 10:46:16 --> brand/index called
INFO - 2016-06-30 10:46:16 --> user/index called
INFO - 2016-06-30 10:46:16 --> store/index called
DEBUG - 2016-06-30 10:46:16 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 10:46:16 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 10:46:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:46:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:46:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 10:46:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:46:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:46:20 --> brand/index called
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:46:20 --> company/index called
DEBUG - 2016-06-30 10:46:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:46:38 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 10:46:38 --> brand/index called
INFO - 2016-06-30 10:46:38 --> user/index called
DEBUG - 2016-06-30 10:46:38 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 10:46:38 --> store/index called
INFO - 2016-06-30 10:46:38 --> company/index called
INFO - 2016-06-30 10:46:38 --> store/index called
DEBUG - 2016-06-30 10:46:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:46:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:46:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 10:46:41 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:46:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:46:43 --> brand/index called
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:46:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:46:43 --> company/index called
DEBUG - 2016-06-30 10:47:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:47:10 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 10:47:10 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:47:10 --> store/index called
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:47:10 --> brand/index called
DEBUG - 2016-06-30 10:47:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:47:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:47:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:47:10 --> user/index called
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:47:10 --> company/index called
DEBUG - 2016-06-30 10:47:12 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:47:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:47:52 --> store/index called
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:47:52 --> company/index called
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:47:53 --> brand/index called
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:47:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:47:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 10:47:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 10:47:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:47:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:47:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 10:47:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:47:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:47:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:47:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:47:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:47:54 --> user/index called
DEBUG - 2016-06-30 10:47:54 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:55:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:55:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:55:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:55:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:55:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:55:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:55:27 --> user/index called
INFO - 2016-06-30 10:55:27 --> company/index called
DEBUG - 2016-06-30 10:55:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:55:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:55:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:55:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:55:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:55:27 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 10:55:27 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 10:55:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:55:27 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:55:27 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 10:55:27 --> store/index called
INFO - 2016-06-30 10:55:27 --> brand/index called
DEBUG - 2016-06-30 10:55:28 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:56:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:56:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:56:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:56:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:56:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:57:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:57:10 --> user/index called
INFO - 2016-06-30 10:57:10 --> store/index called
DEBUG - 2016-06-30 10:57:10 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 10:57:10 --> company/index called
DEBUG - 2016-06-30 10:57:10 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 10:57:11 --> brand/index called
DEBUG - 2016-06-30 10:57:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:57:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:57:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 10:57:12 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 10:58:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:58:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:58:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:58:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:58:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:58:29 --> user/index called
INFO - 2016-06-30 10:58:29 --> company/index called
DEBUG - 2016-06-30 10:58:29 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 10:58:29 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:58:29 --> store/index called
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 10:58:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 10:58:29 --> brand/index called
DEBUG - 2016-06-30 10:58:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 10:58:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 10:58:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 10:58:30 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:08:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:08:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:08:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:08:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:08:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:08:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:08:44 --> store/index called
INFO - 2016-06-30 11:08:44 --> company/index called
INFO - 2016-06-30 11:08:44 --> user/index called
INFO - 2016-06-30 11:08:44 --> brand/index called
DEBUG - 2016-06-30 11:08:44 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:08:44 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:08:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:08:44 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:08:44 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:08:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:11:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:11:38 --> store/index called
INFO - 2016-06-30 11:11:38 --> brand/index called
INFO - 2016-06-30 11:11:38 --> user/index called
INFO - 2016-06-30 11:11:38 --> company/index called
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:11:38 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:11:38 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:11:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:11:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:11:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:11:41 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:11:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:11:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:11:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:11:58 --> company/index called
INFO - 2016-06-30 11:11:58 --> user/index called
INFO - 2016-06-30 11:11:58 --> store/index called
INFO - 2016-06-30 11:11:58 --> brand/index called
DEBUG - 2016-06-30 11:12:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:12:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:12:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:12:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:12:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:12:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:12:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:12:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:12:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:12:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:12:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:12:12 --> user/index called
INFO - 2016-06-30 11:12:12 --> brand/index called
INFO - 2016-06-30 11:12:12 --> store/index called
INFO - 2016-06-30 11:12:12 --> company/index called
DEBUG - 2016-06-30 11:12:12 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:12:12 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:12:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:12:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:12:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:12:19 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:13:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:13:18 --> store/index called
INFO - 2016-06-30 11:13:18 --> user/index called
INFO - 2016-06-30 11:13:18 --> brand/index called
DEBUG - 2016-06-30 11:13:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:13:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 11:13:18 --> company/index called
DEBUG - 2016-06-30 11:13:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:13:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:13:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:13:20 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:13:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:13:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:13:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:13:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:13:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:13:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:13:57 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:13:57 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:13:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:13:57 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:13:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:13:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:13:58 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:14:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:14:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:14:07 --> company/index called
INFO - 2016-06-30 11:14:07 --> store/index called
INFO - 2016-06-30 11:14:07 --> user/index called
INFO - 2016-06-30 11:14:07 --> brand/index called
DEBUG - 2016-06-30 11:14:07 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:14:07 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:14:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:14:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:14:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:14:09 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:14:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:14:17 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:14:17 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:14:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:14:17 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:14:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:14:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:14:17 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:14:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:14:28 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:14:28 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:14:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:14:28 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:14:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:14:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:14:28 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:14:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:14:40 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:14:40 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:14:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:14:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:14:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:14:40 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:14:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:14:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:14:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:14:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:14:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:14:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:14:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:14:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:14:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:14:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:14:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:14:54 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:15:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:15:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:15:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:15:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:15:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:15:35 --> brand/index called
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:15:35 --> store/index called
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:15:35 --> user/index called
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:15:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:15:35 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 11:15:35 --> company/index called
DEBUG - 2016-06-30 11:15:35 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:15:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:15:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:15:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:15:36 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:15:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:15:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:15:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:15:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:15:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:15:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:15:42 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:15:42 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:15:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:15:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:15:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:15:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:15:42 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:16:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:16:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:16:30 --> user/index called
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:16:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:16:30 --> company/index called
DEBUG - 2016-06-30 11:16:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:16:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:16:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:16:33 --> store/index called
INFO - 2016-06-30 11:16:33 --> brand/index called
DEBUG - 2016-06-30 11:16:33 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:16:33 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:16:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:16:33 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:16:33 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:16:34 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:16:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:16:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:16:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:16:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:16:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:16:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:16:40 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:16:40 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:16:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:16:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:16:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:16:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:16:40 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:16:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:16:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:16:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:16:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:16:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:16:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:16:47 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:16:47 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:16:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:16:47 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:16:47 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:16:47 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:18:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:18:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:18:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:18:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:18:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:18:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:18:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:18:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:18:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:18:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:18:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:18:23 --> store/index called
INFO - 2016-06-30 11:18:23 --> user/index called
INFO - 2016-06-30 11:18:23 --> company/index called
DEBUG - 2016-06-30 11:18:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 11:18:23 --> brand/index called
DEBUG - 2016-06-30 11:18:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:18:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:18:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:18:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:18:41 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:18:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:18:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:18:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:18:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:18:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:18:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:18:43 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:18:43 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:18:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:18:43 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:18:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:18:44 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:18:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:18:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:18:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:18:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:18:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:18:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:18:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:18:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:18:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:18:53 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:18:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:18:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:18:53 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:19:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:19:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:19:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:19:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:19:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:19:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:19:00 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:19:00 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:19:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:19:00 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:19:00 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:19:00 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:19:01 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:19:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:19:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:19:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:19:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:19:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:19:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:19:02 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:19:02 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:19:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:19:02 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:19:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:19:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:19:03 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:21:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:21:36 --> user/index called
DEBUG - 2016-06-30 11:21:36 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:21:36 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 11:21:36 --> brand/index called
INFO - 2016-06-30 11:21:36 --> company/index called
INFO - 2016-06-30 11:21:36 --> store/index called
DEBUG - 2016-06-30 11:21:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:21:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:21:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:21:37 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:21:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:21:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:21:54 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 11:21:54 --> brand/index called
INFO - 2016-06-30 11:21:54 --> company/index called
INFO - 2016-06-30 11:21:54 --> store/index called
DEBUG - 2016-06-30 11:21:54 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 11:21:54 --> user/index called
DEBUG - 2016-06-30 11:21:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:21:54 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:21:54 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:21:56 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:22:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:22:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:22:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:22:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:22:23 --> brand/index called
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:22:23 --> user/index called
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:22:23 --> company/index called
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:22:23 --> store/index called
DEBUG - 2016-06-30 11:22:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:22:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:22:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:22:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:22:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:22:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:22:24 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:22:24 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:22:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:22:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:22:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:22:25 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:22:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:23:00 --> company/index called
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:23:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:23:00 --> user/index called
DEBUG - 2016-06-30 11:23:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:23:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:23:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:23:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:23:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:23:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:23:01 --> store/index called
DEBUG - 2016-06-30 11:23:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:23:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:23:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:23:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:23:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:23:02 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:23:02 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:23:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:23:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:23:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:23:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:23:03 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:23:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:23:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:23:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:23:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:23:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:23:03 --> brand/index called
DEBUG - 2016-06-30 11:23:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:23:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:23:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:23:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:23:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:23:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:23:11 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:23:11 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:23:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:23:11 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:23:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:23:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:23:11 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:23:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:23:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:23:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:23:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:23:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:23:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:23:20 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:23:20 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:23:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:23:20 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:23:20 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:23:20 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:24:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:24:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:24:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:24:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:24:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:24:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:24:05 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:24:05 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:24:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:24:05 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:24:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:24:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:24:05 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:24:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:24:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:24:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:24:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:24:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:24:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:24:10 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:24:10 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:24:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:24:10 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:24:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:24:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:24:10 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:24:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:24:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:24:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:24:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:24:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:24:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:24:17 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:24:17 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:24:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:24:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:24:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:24:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:24:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:24:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:24:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:24:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:24:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:24:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:24:26 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:24:26 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:24:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:24:26 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:24:26 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:24:27 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:37:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:37:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:37:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:37:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:37:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:37:12 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:37:12 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:37:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:37:12 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:37:12 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:37:12 --> store/index called
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:37:12 --> brand/index called
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:37:12 --> company/index called
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:37:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:37:12 --> user/index called
DEBUG - 2016-06-30 11:37:15 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:40:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:40:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:40:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:40:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:40:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:40:31 --> store/index called
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:40:31 --> user/index called
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:40:31 --> brand/index called
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:40:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:40:31 --> company/index called
DEBUG - 2016-06-30 11:40:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:40:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:40:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:40:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:40:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:40:32 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:40:32 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:40:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:40:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:40:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:40:33 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:40:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:40:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:40:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:40:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:40:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:40:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:40:47 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:40:47 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:40:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:40:47 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:40:47 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:40:47 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:40:47 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:40:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:40:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:40:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:40:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:40:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:40:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:40:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:40:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:40:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:40:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:40:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:40:54 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:40:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:41:00 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:41:00 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:41:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:41:00 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:41:00 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:41:00 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:41:00 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:41:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:41:05 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:41:05 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:41:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:41:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:41:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:41:05 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:41:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:41:12 --> user/index called
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:41:13 --> brand/index called
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:41:13 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:41:13 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:41:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:41:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:41:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:41:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:41:14 --> store/index called
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:14 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:41:14 --> company/index called
DEBUG - 2016-06-30 11:41:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:41:29 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:41:29 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:41:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:41:29 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:41:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:41:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:41:29 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:41:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:41:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:41:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:41:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:41:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:41:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:41:34 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:41:34 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:41:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:41:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:41:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:41:34 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:42:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:42:24 --> user/index called
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:42:24 --> company/index called
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:42:24 --> store/index called
DEBUG - 2016-06-30 11:42:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:42:25 --> brand/index called
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:42:25 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:42:26 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:42:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:42:26 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:42:26 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:42:26 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:42:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:42:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:42:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:42:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:42:31 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:42:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:42:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:42:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:42:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:42:35 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:42:35 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:42:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:42:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:42:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:42:35 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:42:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:42:42 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:42:42 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:42:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:42:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:42:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:42:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:42:42 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:42:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:42:46 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:42:46 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:42:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:42:46 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:42:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:42:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:42:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:42:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:42:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:42:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:42:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:42:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:42:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:42:56 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:42:56 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:42:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:42:56 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:42:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:42:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:42:57 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:43:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:43:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:43:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:43:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:43:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:43:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:43:00 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:43:00 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:43:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:43:00 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:43:00 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:43:00 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:43:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:43:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:43:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:43:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:43:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:43:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:43:14 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:43:14 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:43:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:43:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 11:43:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:43:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:43:14 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:43:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:43:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:43:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:43:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:43:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:43:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:43:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:43:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:43:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:43:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:43:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:43:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:46:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:46:26 --> brand/index called
DEBUG - 2016-06-30 11:46:26 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:46:26 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 11:46:26 --> company/index called
INFO - 2016-06-30 11:46:27 --> user/index called
INFO - 2016-06-30 11:46:27 --> store/index called
DEBUG - 2016-06-30 11:46:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:46:27 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:46:27 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:46:28 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:46:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:46:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:46:50 --> store/index called
DEBUG - 2016-06-30 11:46:50 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:46:50 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 11:46:50 --> user/index called
INFO - 2016-06-30 11:46:50 --> company/index called
INFO - 2016-06-30 11:46:50 --> brand/index called
DEBUG - 2016-06-30 11:46:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:46:50 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:46:50 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:46:50 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:47:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:47:06 --> user/index called
INFO - 2016-06-30 11:47:06 --> store/index called
DEBUG - 2016-06-30 11:47:06 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:47:06 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 11:47:06 --> company/index called
INFO - 2016-06-30 11:47:06 --> brand/index called
DEBUG - 2016-06-30 11:47:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:47:06 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:47:06 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:47:07 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:47:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:47:30 --> user/index called
INFO - 2016-06-30 11:47:30 --> brand/index called
INFO - 2016-06-30 11:47:30 --> company/index called
INFO - 2016-06-30 11:47:30 --> store/index called
DEBUG - 2016-06-30 11:47:30 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:47:30 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:47:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:47:30 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:47:30 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:47:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:47:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:47:47 --> store/index called
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:47:47 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:47:47 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:47:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:47:47 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:47:47 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:47:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:47:48 --> user/index called
DEBUG - 2016-06-30 11:47:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:47:49 --> brand/index called
DEBUG - 2016-06-30 11:47:49 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:47:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:47:49 --> company/index called
DEBUG - 2016-06-30 11:49:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:49:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:49:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:49:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:49:10 --> company/index called
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:49:10 --> user/index called
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:49:10 --> store/index called
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:49:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:49:10 --> brand/index called
DEBUG - 2016-06-30 11:49:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:49:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:49:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:49:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:49:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:49:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:49:12 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:49:12 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:49:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:49:12 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:49:12 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:49:12 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:51:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:51:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:51:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:51:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:51:43 --> user/index called
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:51:43 --> company/index called
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:51:43 --> store/index called
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:51:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:51:44 --> brand/index called
DEBUG - 2016-06-30 11:51:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:51:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:51:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:51:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:51:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:51:44 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:51:44 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:51:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:51:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:51:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:51:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 11:51:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:51:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:51:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:52:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:52:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 11:52:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 11:52:07 --> user/index called
INFO - 2016-06-30 11:52:07 --> store/index called
INFO - 2016-06-30 11:52:07 --> brand/index called
INFO - 2016-06-30 11:52:07 --> company/index called
DEBUG - 2016-06-30 11:52:07 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 11:52:07 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 11:52:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 11:52:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 11:52:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 11:52:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:02:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:02:30 --> company/index called
DEBUG - 2016-06-30 12:02:30 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:02:30 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 12:02:30 --> brand/index called
INFO - 2016-06-30 12:02:30 --> store/index called
INFO - 2016-06-30 12:02:30 --> user/index called
DEBUG - 2016-06-30 12:02:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:02:30 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:02:30 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:02:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:02:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:02:51 --> user/index called
DEBUG - 2016-06-30 12:02:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:02:52 --> company/index called
DEBUG - 2016-06-30 12:02:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:02:53 --> brand/index called
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:02:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:02:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:02:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:02:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:02:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:02:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:02:53 --> store/index called
DEBUG - 2016-06-30 12:02:53 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:04:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:04:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:04:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:05:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:05:01 --> user/index called
DEBUG - 2016-06-30 12:05:01 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 12:05:01 --> company/index called
DEBUG - 2016-06-30 12:05:01 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 12:05:02 --> brand/index called
INFO - 2016-06-30 12:05:02 --> store/index called
DEBUG - 2016-06-30 12:05:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:05:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:05:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:05:04 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:05:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:05:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:05:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:05:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:05:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:06:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:06:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:06:03 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:06:03 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 12:06:03 --> store/index called
INFO - 2016-06-30 12:06:03 --> brand/index called
INFO - 2016-06-30 12:06:03 --> user/index called
INFO - 2016-06-30 12:06:03 --> company/index called
DEBUG - 2016-06-30 12:06:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:06:03 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:06:03 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:06:06 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:08:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:08:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:08:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:08:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:08:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:08:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:08:36 --> company/index called
DEBUG - 2016-06-30 12:08:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:08:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:08:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:08:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:08:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:08:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:08:37 --> user/index called
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:08:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:08:38 --> store/index called
INFO - 2016-06-30 12:08:38 --> brand/index called
DEBUG - 2016-06-30 12:08:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:08:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:08:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:08:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:08:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:08:39 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:08:39 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:08:39 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:08:39 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:08:39 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:08:40 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:10:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:10:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:10:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:10:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:10:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:10:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:10:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:10:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:10:39 --> brand/index called
DEBUG - 2016-06-30 12:10:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:10:41 --> company/index called
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:10:41 --> user/index called
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:10:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:10:41 --> store/index called
DEBUG - 2016-06-30 12:10:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:10:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:10:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:10:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:10:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:10:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:10:44 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:10:44 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:10:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:10:44 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:10:44 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:10:44 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:11:03 --> company/index called
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:11:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:11:03 --> user/index called
DEBUG - 2016-06-30 12:11:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:11:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:11:05 --> brand/index called
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:11:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:11:05 --> store/index called
DEBUG - 2016-06-30 12:11:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:11:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:11:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:11:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:11:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:11:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:11:20 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:11:20 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:11:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:11:20 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:11:20 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:11:20 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:14:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:14:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 12:14:50 --> company/index called
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:14:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:14:50 --> user/index called
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:14:51 --> store/index called
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:14:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:14:51 --> brand/index called
DEBUG - 2016-06-30 12:15:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:15:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:15:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:15:49 --> company/index called
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:15:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:15:49 --> brand/index called
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:15:50 --> user/index called
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:15:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:15:50 --> store/index called
DEBUG - 2016-06-30 12:16:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:16:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:16:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:16:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:16:25 --> user/index called
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:16:25 --> company/index called
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:16:25 --> brand/index called
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:16:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:16:25 --> store/index called
DEBUG - 2016-06-30 12:18:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:18:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:18:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:18:42 --> user/index called
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 12:18:42 --> company/index called
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:18:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:18:42 --> brand/index called
DEBUG - 2016-06-30 12:18:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:18:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:18:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:18:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:18:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:18:43 --> store/index called
DEBUG - 2016-06-30 12:19:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:19:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:19:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:19:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:19:21 --> company/index called
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:19:21 --> user/index called
INFO - 2016-06-30 12:19:21 --> store/index called
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:19:21 --> brand/index called
DEBUG - 2016-06-30 12:20:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:20:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:20:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:20:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:20:14 --> user/index called
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:20:14 --> brand/index called
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:20:14 --> store/index called
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:20:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:20:14 --> company/index called
DEBUG - 2016-06-30 12:20:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:20:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:20:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:20:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:20:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:20:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:20:45 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:20:45 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:20:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:20:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:20:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:20:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:21:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:21:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:21:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:21:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:21:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:21:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:21:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:21:24 --> user/index called
DEBUG - 2016-06-30 12:21:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:21:25 --> company/index called
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:21:25 --> store/index called
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:21:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:21:25 --> brand/index called
DEBUG - 2016-06-30 12:21:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:21:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:21:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:21:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:21:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:21:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:21:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:21:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:21:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:21:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:21:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:21:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:25:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:25:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:25:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:25:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:25:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:25:12 --> company/index called
INFO - 2016-06-30 12:25:12 --> brand/index called
INFO - 2016-06-30 12:25:12 --> store/index called
INFO - 2016-06-30 12:25:12 --> user/index called
DEBUG - 2016-06-30 12:28:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:28:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:28:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:28:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:28:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:28:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:28:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:28:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:28:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:28:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:28:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:28:54 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:29:03 --> company/index called
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:29:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:29:03 --> brand/index called
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:29:04 --> user/index called
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:29:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:29:04 --> store/index called
DEBUG - 2016-06-30 12:30:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:30:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:30:43 --> store/index called
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:30:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:30:43 --> user/index called
DEBUG - 2016-06-30 12:30:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:30:45 --> brand/index called
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:30:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:30:45 --> company/index called
DEBUG - 2016-06-30 12:30:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:30:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:30:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:30:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:30:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:30:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:30:49 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:30:49 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:30:49 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:30:49 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:30:49 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:30:49 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:31:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:31:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:31:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:31:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:31:33 --> brand/index called
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:31:33 --> store/index called
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:31:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:31:33 --> user/index called
DEBUG - 2016-06-30 12:31:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:31:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:31:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:31:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:31:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:31:34 --> company/index called
DEBUG - 2016-06-30 12:31:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:31:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:31:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:31:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:31:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:31:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:31:35 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:31:35 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:31:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:31:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:31:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:31:35 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:32:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:32:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:32:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:32:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:32:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:32:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:32:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:32:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:32:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:32:21 --> company/index called
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:32:22 --> user/index called
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:32:22 --> brand/index called
DEBUG - 2016-06-30 12:32:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:32:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:32:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:32:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:32:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:32:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:32:24 --> store/index called
DEBUG - 2016-06-30 12:32:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:32:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:32:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:32:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:32:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:32:25 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:32:25 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:32:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:32:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:32:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:32:27 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:33:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:33:03 --> company/index called
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:33:03 --> user/index called
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:33:03 --> brand/index called
DEBUG - 2016-06-30 12:33:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:33:04 --> store/index called
DEBUG - 2016-06-30 12:33:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:33:05 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:33:05 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:33:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:33:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:33:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:33:05 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:33:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:33:20 --> store/index called
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:33:20 --> company/index called
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:33:21 --> brand/index called
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:33:21 --> user/index called
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:33:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:33:21 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:33:21 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:33:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:33:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:33:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:33:23 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:37:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:37:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:37:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:37:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:37:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:37:34 --> company/index called
INFO - 2016-06-30 12:37:34 --> user/index called
INFO - 2016-06-30 12:37:34 --> brand/index called
INFO - 2016-06-30 12:37:34 --> store/index called
DEBUG - 2016-06-30 12:37:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:37:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:37:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:37:56 --> user/index called
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:37:56 --> company/index called
DEBUG - 2016-06-30 12:37:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:37:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:37:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:37:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:37:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:37:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:37:57 --> store/index called
DEBUG - 2016-06-30 12:37:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:37:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:37:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:37:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:37:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:37:58 --> brand/index called
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:41:00 --> store/index called
DEBUG - 2016-06-30 12:41:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:41:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:41:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:41:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:41:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:41:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:41:01 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:41:01 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:41:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:41:01 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:41:01 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:41:02 --> user/index called
INFO - 2016-06-30 12:41:02 --> company/index called
DEBUG - 2016-06-30 12:41:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:41:03 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:41:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:41:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:41:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:41:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:41:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:41:03 --> brand/index called
DEBUG - 2016-06-30 12:42:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:06 --> user/index called
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:06 --> store/index called
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:06 --> brand/index called
DEBUG - 2016-06-30 12:42:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:07 --> company/index called
DEBUG - 2016-06-30 12:42:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:42:08 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:42:08 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:42:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:42:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:42:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:42:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:42:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:23 --> company/index called
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:24 --> brand/index called
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:24 --> store/index called
DEBUG - 2016-06-30 12:42:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:25 --> user/index called
DEBUG - 2016-06-30 12:42:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:54 --> store/index called
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:54 --> company/index called
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:42:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:42:54 --> user/index called
INFO - 2016-06-30 12:42:54 --> brand/index called
DEBUG - 2016-06-30 12:43:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:43:14 --> user/index called
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:43:15 --> company/index called
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:43:15 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:43:15 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:43:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:43:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:43:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:43:16 --> brand/index called
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:43:16 --> store/index called
DEBUG - 2016-06-30 12:43:17 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:43:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:43:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:43:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:43:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:43:31 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 12:43:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:43:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:43:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:43:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 12:43:35 --> company/index called
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:43:35 --> user/index called
DEBUG - 2016-06-30 12:43:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:43:36 --> brand/index called
DEBUG - 2016-06-30 12:43:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:43:37 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:43:37 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:43:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:43:37 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:43:37 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:43:37 --> store/index called
DEBUG - 2016-06-30 12:43:37 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:43:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:43:42 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:43:42 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:43:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:43:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 12:43:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:43:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:43:43 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:43:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:43:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:43:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:43:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:43:48 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 12:43:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:43:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:43:48 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:43:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:43:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:43:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:43:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:43:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:43:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:43:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:43:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:43:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:43:53 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 12:43:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:43:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:43:53 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:44:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:44:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:44:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:44:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:44:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:44:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:44:00 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:44:00 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:44:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:44:00 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 12:44:00 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:44:00 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:44:00 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:44:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:44:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:44:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:44:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:44:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:44:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:44:08 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:44:08 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:44:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:44:08 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 12:44:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:44:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:44:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:48:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:48:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:48:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:48:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:48:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:48:44 --> company/index called
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:48:44 --> user/index called
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:48:44 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:48:44 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 12:48:44 --> brand/index called
DEBUG - 2016-06-30 12:48:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:48:44 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:48:44 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:48:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:48:44 --> store/index called
DEBUG - 2016-06-30 12:48:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:49:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:49:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:49:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:49:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:49:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:50:00 --> user/index called
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:50:00 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:50:00 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:50:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:50:00 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:50:00 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:50:00 --> store/index called
INFO - 2016-06-30 12:50:00 --> company/index called
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:50:00 --> brand/index called
DEBUG - 2016-06-30 12:50:02 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:50:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:50:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:50:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:50:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:50:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:50:30 --> store/index called
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:50:30 --> company/index called
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:50:30 --> brand/index called
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:50:31 --> user/index called
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:50:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:50:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:50:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:50:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:50:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:50:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:50:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:58:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:58:07 --> user/index called
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:58:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:58:07 --> company/index called
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:58:08 --> brand/index called
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:58:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:58:08 --> store/index called
DEBUG - 2016-06-30 12:58:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:58:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:58:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:58:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:58:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:58:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:58:10 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:58:10 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:58:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:58:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:58:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:58:10 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 12:59:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:59:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:59:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:59:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:59:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:59:23 --> user/index called
INFO - 2016-06-30 12:59:23 --> brand/index called
INFO - 2016-06-30 12:59:23 --> company/index called
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 12:59:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 12:59:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 12:59:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 12:59:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 12:59:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 12:59:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 12:59:24 --> store/index called
DEBUG - 2016-06-30 12:59:24 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:00:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:00:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:00:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:00:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:00:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:00:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:00:20 --> company/index called
DEBUG - 2016-06-30 13:00:20 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 13:00:20 --> store/index called
INFO - 2016-06-30 13:00:20 --> user/index called
INFO - 2016-06-30 13:00:20 --> brand/index called
DEBUG - 2016-06-30 13:00:20 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:00:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:00:20 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:00:20 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:00:23 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:02:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:02:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:02:55 --> company/index called
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:02:55 --> user/index called
DEBUG - 2016-06-30 13:02:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:02:56 --> store/index called
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:02:56 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:02:56 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:02:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:02:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:02:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:02:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:02:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:02:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:02:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:02:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:02:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:02:57 --> brand/index called
DEBUG - 2016-06-30 13:02:58 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:03:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:03:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:03:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:03:41 --> company/index called
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:03:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:03:41 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:03:41 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:03:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:03:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:03:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:03:42 --> user/index called
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:03:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:03:43 --> brand/index called
DEBUG - 2016-06-30 13:03:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:03:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:03:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:03:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:03:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:03:43 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
INFO - 2016-06-30 13:03:43 --> store/index called
DEBUG - 2016-06-30 13:04:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:04:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:04:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:04:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:04:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:04:58 --> company/index called
INFO - 2016-06-30 13:04:58 --> user/index called
INFO - 2016-06-30 13:04:58 --> store/index called
DEBUG - 2016-06-30 13:04:58 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:04:58 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 13:04:58 --> brand/index called
DEBUG - 2016-06-30 13:04:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:04:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:04:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:05:01 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:07:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:07:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:07:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:07:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:07:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:07:05 --> company/index called
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:07:05 --> store/index called
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:07:05 --> user/index called
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:07:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:07:05 --> brand/index called
DEBUG - 2016-06-30 13:07:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:07:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:07:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:07:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:07:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:07:07 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:07:07 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:07:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:07:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:07:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:07:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:08:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:08:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:08:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:08:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:08:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:08:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 13:08:31 --> store/index called
DEBUG - 2016-06-30 13:08:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:08:31 --> user/index called
DEBUG - 2016-06-30 13:08:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:08:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:08:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:08:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:08:31 --> company/index called
DEBUG - 2016-06-30 13:08:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:08:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:08:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:08:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:08:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:08:32 --> brand/index called
DEBUG - 2016-06-30 13:08:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:09:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:09:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:09:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:09:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:09:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:09:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:09:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:09:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:09:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:09:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:09:16 --> company/index called
DEBUG - 2016-06-30 13:09:16 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:09:16 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 13:09:16 --> store/index called
INFO - 2016-06-30 13:09:16 --> brand/index called
DEBUG - 2016-06-30 13:09:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:09:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:09:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:09:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:09:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:09:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:09:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:09:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:09:17 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
INFO - 2016-06-30 13:09:17 --> user/index called
DEBUG - 2016-06-30 13:17:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:17:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:17:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:17:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:17:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:17:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:17:30 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:17:30 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 13:17:30 --> user/index called
INFO - 2016-06-30 13:17:30 --> brand/index called
INFO - 2016-06-30 13:17:30 --> company/index called
INFO - 2016-06-30 13:17:30 --> store/index called
DEBUG - 2016-06-30 13:17:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:17:30 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:17:30 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:17:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:17:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:17:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:17:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:17:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:17:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:17:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:17:44 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:17:44 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:17:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:17:44 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:17:44 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:17:45 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:24:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:24:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:24:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:24:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:24:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:24:24 --> store/index called
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:24:24 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:24:24 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:24:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:24:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:24:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:24:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 13:24:24 --> brand/index called
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:24:25 --> company/index called
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:24:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:24:25 --> user/index called
DEBUG - 2016-06-30 13:24:26 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:24:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:24:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:24:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:24:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:24:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:24:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:24:55 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:24:55 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:24:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:24:56 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 13:24:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:24:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:24:56 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:29:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:29:12 --> brand/index called
INFO - 2016-06-30 13:29:12 --> company/index called
INFO - 2016-06-30 13:29:12 --> user/index called
INFO - 2016-06-30 13:29:12 --> store/index called
DEBUG - 2016-06-30 13:31:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:31:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:31:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:31:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:31:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:31:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:31:22 --> company/index called
INFO - 2016-06-30 13:31:22 --> user/index called
INFO - 2016-06-30 13:31:22 --> store/index called
DEBUG - 2016-06-30 13:31:22 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:31:22 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 13:31:22 --> brand/index called
DEBUG - 2016-06-30 13:31:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:31:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:31:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:31:26 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:55:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:55:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:55:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:55:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:55:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:55:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:55:59 --> user/index called
DEBUG - 2016-06-30 13:55:59 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:55:59 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 13:55:59 --> company/index called
INFO - 2016-06-30 13:55:59 --> store/index called
INFO - 2016-06-30 13:55:59 --> brand/index called
DEBUG - 2016-06-30 13:55:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:55:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:55:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:56:02 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:56:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:56:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:56:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:56:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:56:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:56:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:56:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:56:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:56:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:56:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:56:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:56:56 --> company/index called
INFO - 2016-06-30 13:56:56 --> store/index called
INFO - 2016-06-30 13:56:56 --> user/index called
INFO - 2016-06-30 13:56:56 --> brand/index called
DEBUG - 2016-06-30 13:56:56 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:56:56 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:56:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:56:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:56:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:56:59 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:58:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:58:25 --> company/index called
INFO - 2016-06-30 13:58:25 --> store/index called
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:58:25 --> user/index called
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:58:25 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:58:25 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:58:25 --> brand/index called
DEBUG - 2016-06-30 13:58:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:58:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:58:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 13:58:26 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 13:58:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:58:53 --> company/index called
DEBUG - 2016-06-30 13:58:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:58:54 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 13:58:54 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:58:54 --> user/index called
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 13:58:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 13:58:54 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 13:58:54 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 13:58:54 --> store/index called
DEBUG - 2016-06-30 13:58:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 13:58:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 13:58:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 13:58:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 13:58:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 13:58:55 --> brand/index called
DEBUG - 2016-06-30 13:58:56 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:00:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:00:57 --> brand/index called
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:00:57 --> company/index called
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:00:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:00:57 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:00:57 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:00:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:00:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:00:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:00:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:00:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:00:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:00:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:00:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:00:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:00:58 --> store/index called
DEBUG - 2016-06-30 14:00:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:00:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:00:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:00:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:00:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:00:59 --> user/index called
DEBUG - 2016-06-30 14:00:59 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:01:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:01:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:01:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:01:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:01:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:01:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:01:41 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 14:01:41 --> brand/index called
DEBUG - 2016-06-30 14:01:41 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 14:01:41 --> user/index called
DEBUG - 2016-06-30 14:01:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:01:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:01:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:01:41 --> company/index called
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:01:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:01:41 --> store/index called
DEBUG - 2016-06-30 14:01:43 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:02:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:02:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:02:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:02:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:02:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:02:24 --> company/index called
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:02:24 --> brand/index called
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:02:24 --> user/index called
DEBUG - 2016-06-30 14:02:24 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:02:24 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:02:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:02:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:02:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:02:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:02:24 --> store/index called
DEBUG - 2016-06-30 14:02:26 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:03:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:03:06 --> brand/index called
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:03:07 --> user/index called
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:03:07 --> store/index called
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:03:07 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 14:03:07 --> company/index called
DEBUG - 2016-06-30 14:03:07 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:03:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:03:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:03:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:03:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:03:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:03:46 --> user/index called
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:03:46 --> company/index called
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:03:47 --> store/index called
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:03:47 --> brand/index called
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:03:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:03:47 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:03:47 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:03:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:03:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:03:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:03:49 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:04:15 --> company/index called
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:04:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:04:16 --> user/index called
DEBUG - 2016-06-30 14:04:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:04:17 --> brand/index called
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:04:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:04:17 --> store/index called
DEBUG - 2016-06-30 14:04:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:04:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:04:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:04:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:04:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:04:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:04:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:04:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:04:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:04:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:04:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:10:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:10:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:10:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:10:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:11:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:11:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:11:02 --> company/index called
INFO - 2016-06-30 14:11:02 --> brand/index called
INFO - 2016-06-30 14:11:02 --> store/index called
DEBUG - 2016-06-30 14:11:02 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:11:02 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 14:11:02 --> user/index called
DEBUG - 2016-06-30 14:11:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:11:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:11:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:11:05 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:11:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:11:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:11:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:11:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:11:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:11:24 --> user/index called
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:11:24 --> store/index called
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:11:24 --> company/index called
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:11:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:11:24 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:11:24 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:11:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:11:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:11:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 14:11:24 --> brand/index called
DEBUG - 2016-06-30 14:11:27 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:12:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:12:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:12:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:12:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:12:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:12:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:12:14 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:12:14 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:12:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:12:14 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 14:12:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:12:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:12:14 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:12:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:12:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:12:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:12:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:12:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:12:52 --> company/index called
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:12:52 --> brand/index called
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:12:52 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:12:52 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:12:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:12:52 --> store/index called
DEBUG - 2016-06-30 14:12:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:12:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:12:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:12:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:12:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:12:53 --> user/index called
DEBUG - 2016-06-30 14:12:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:12:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:12:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:12:55 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:15:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:15:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:15:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:15:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:15:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:15:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 14:15:48 --> store/index called
INFO - 2016-06-30 14:15:48 --> brand/index called
DEBUG - 2016-06-30 14:15:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 14:15:48 --> company/index called
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:15:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:15:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
INFO - 2016-06-30 14:15:48 --> user/index called
DEBUG - 2016-06-30 14:15:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:15:50 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:17:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:17:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:17:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:17:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:17:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:17:10 --> user/index called
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:17:10 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:17:10 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 14:17:10 --> brand/index called
INFO - 2016-06-30 14:17:10 --> store/index called
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:17:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:17:10 --> company/index called
DEBUG - 2016-06-30 14:17:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:17:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:17:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:17:12 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:25:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:25:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:25:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:25:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:25:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:25:27 --> brand/index called
INFO - 2016-06-30 14:25:27 --> company/index called
INFO - 2016-06-30 14:25:27 --> user/index called
INFO - 2016-06-30 14:25:27 --> store/index called
DEBUG - 2016-06-30 14:26:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:26:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:26:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:26:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:26:15 --> user/index called
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:26:15 --> store/index called
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:26:15 --> company/index called
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:26:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:26:15 --> brand/index called
DEBUG - 2016-06-30 14:27:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:27:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:27:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:27:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:27:24 --> brand/index called
INFO - 2016-06-30 14:27:24 --> user/index called
DEBUG - 2016-06-30 14:27:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:27:25 --> store/index called
DEBUG - 2016-06-30 14:27:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:27:27 --> company/index called
DEBUG - 2016-06-30 14:27:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 14:27:42 --> company/index called
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:27:42 --> user/index called
DEBUG - 2016-06-30 14:27:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:27:45 --> store/index called
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:27:45 --> brand/index called
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:27:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:27:45 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:27:45 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:27:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:27:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:27:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:27:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:28:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:28:18 --> store/index called
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:28:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:28:19 --> brand/index called
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:28:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:28:19 --> user/index called
INFO - 2016-06-30 14:28:19 --> company/index called
DEBUG - 2016-06-30 14:29:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:29:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:29:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:29:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:29:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:29:21 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:29:21 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 14:29:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:29:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:29:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:29:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:29:21 --> user/index called
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:29:22 --> brand/index called
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:29:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:29:22 --> store/index called
DEBUG - 2016-06-30 14:29:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:29:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:29:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:29:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:29:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:29:23 --> company/index called
DEBUG - 2016-06-30 14:29:24 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 14:32:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:32:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:32:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:32:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:32:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 14:32:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 14:32:48 --> company/index called
INFO - 2016-06-30 14:32:48 --> store/index called
INFO - 2016-06-30 14:32:48 --> brand/index called
DEBUG - 2016-06-30 14:32:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 14:32:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 14:32:48 --> user/index called
DEBUG - 2016-06-30 14:32:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 14:32:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 14:32:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 14:32:50 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 15:15:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:15:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:15:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:15:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:15:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:15:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:15:55 --> user/index called
INFO - 2016-06-30 15:15:55 --> brand/index called
DEBUG - 2016-06-30 15:15:55 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 15:15:55 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 15:15:55 --> company/index called
INFO - 2016-06-30 15:15:55 --> store/index called
DEBUG - 2016-06-30 15:15:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 15:15:55 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 15:15:55 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 15:15:55 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 15:18:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:18:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:18:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:18:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:18:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:18:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:18:21 --> user/index called
INFO - 2016-06-30 15:18:21 --> brand/index called
INFO - 2016-06-30 15:18:21 --> store/index called
INFO - 2016-06-30 15:18:21 --> company/index called
DEBUG - 2016-06-30 15:18:21 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 15:18:21 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 15:18:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 15:18:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 15:18:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 15:18:21 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 15:35:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:35:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:35:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:35:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:35:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:35:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:35:07 --> store/index called
INFO - 2016-06-30 15:35:07 --> company/index called
DEBUG - 2016-06-30 15:35:07 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 15:35:07 --> user/index called
INFO - 2016-06-30 15:35:07 --> brand/index called
DEBUG - 2016-06-30 15:35:07 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 15:35:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 15:35:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 15:35:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 15:35:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 15:37:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:37:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:37:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:37:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:37:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:37:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:37:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 15:37:23 --> company/index called
INFO - 2016-06-30 15:37:23 --> store/index called
DEBUG - 2016-06-30 15:37:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 15:37:23 --> user/index called
INFO - 2016-06-30 15:37:23 --> brand/index called
DEBUG - 2016-06-30 15:37:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 15:37:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 15:37:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 15:37:23 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 15:38:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:38:08 --> company/index called
INFO - 2016-06-30 15:38:08 --> store/index called
DEBUG - 2016-06-30 15:38:08 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 15:38:08 --> user/index called
DEBUG - 2016-06-30 15:38:08 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 15:38:08 --> brand/index called
DEBUG - 2016-06-30 15:38:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 15:38:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 15:38:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 15:38:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 15:38:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:38:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:38:29 --> brand/index called
INFO - 2016-06-30 15:38:29 --> user/index called
DEBUG - 2016-06-30 15:38:29 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 15:38:29 --> store/index called
DEBUG - 2016-06-30 15:38:29 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 15:38:29 --> company/index called
DEBUG - 2016-06-30 15:38:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 15:38:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 15:38:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 15:38:30 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 15:44:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:44:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:44:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:44:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:44:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:44:08 --> brand/index called
INFO - 2016-06-30 15:44:08 --> company/index called
INFO - 2016-06-30 15:44:08 --> store/index called
INFO - 2016-06-30 15:44:08 --> user/index called
DEBUG - 2016-06-30 15:45:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:45:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:45:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:45:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:45:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:45:20 --> company/index called
INFO - 2016-06-30 15:45:20 --> brand/index called
INFO - 2016-06-30 15:45:20 --> user/index called
INFO - 2016-06-30 15:45:20 --> store/index called
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:50:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:50:46 --> brand/index called
INFO - 2016-06-30 15:50:46 --> company/index called
DEBUG - 2016-06-30 15:50:46 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 15:50:46 --> store/index called
DEBUG - 2016-06-30 15:50:46 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 15:50:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 15:50:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 15:50:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 15:50:47 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 15:50:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:50:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:50:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:50:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:50:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:50:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:50:49 --> user/index called
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:54:33 --> user/index called
INFO - 2016-06-30 15:54:33 --> brand/index called
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:54:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:54:33 --> store/index called
INFO - 2016-06-30 15:54:33 --> company/index called
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:55:10 --> brand/index called
INFO - 2016-06-30 15:55:10 --> user/index called
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:55:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:55:10 --> store/index called
INFO - 2016-06-30 15:55:10 --> company/index called
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:56:53 --> user/index called
INFO - 2016-06-30 15:56:53 --> company/index called
INFO - 2016-06-30 15:56:53 --> brand/index called
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:56:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:56:53 --> store/index called
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:57:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:57:14 --> user/index called
INFO - 2016-06-30 15:57:14 --> store/index called
INFO - 2016-06-30 15:57:14 --> brand/index called
INFO - 2016-06-30 15:57:14 --> company/index called
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:59:59 --> company/index called
INFO - 2016-06-30 15:59:59 --> brand/index called
INFO - 2016-06-30 15:59:59 --> store/index called
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 15:59:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 15:59:59 --> user/index called
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:00:42 --> user/index called
INFO - 2016-06-30 16:00:42 --> brand/index called
INFO - 2016-06-30 16:00:42 --> store/index called
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:00:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:00:42 --> company/index called
DEBUG - 2016-06-30 16:01:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:01:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:01:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:01:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:01:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:01:20 --> brand/index called
INFO - 2016-06-30 16:01:20 --> user/index called
INFO - 2016-06-30 16:01:20 --> company/index called
INFO - 2016-06-30 16:01:20 --> store/index called
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:02:12 --> store/index called
INFO - 2016-06-30 16:02:12 --> user/index called
INFO - 2016-06-30 16:02:12 --> brand/index called
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:02:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:02:12 --> company/index called
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:04:24 --> company/index called
INFO - 2016-06-30 16:04:24 --> store/index called
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:04:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:04:24 --> user/index called
INFO - 2016-06-30 16:04:24 --> brand/index called
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:04:57 --> store/index called
INFO - 2016-06-30 16:04:57 --> brand/index called
INFO - 2016-06-30 16:04:57 --> user/index called
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:04:57 --> company/index called
DEBUG - 2016-06-30 16:05:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:05:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:05:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:05:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:05:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:05:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:05:01 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:05:01 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:05:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:05:01 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:05:01 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:05:01 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:12:57 --> store/index called
INFO - 2016-06-30 16:12:57 --> brand/index called
INFO - 2016-06-30 16:12:57 --> user/index called
INFO - 2016-06-30 16:12:57 --> company/index called
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:12:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:12:57 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:12:57 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:12:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:12:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:12:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:12:57 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:13:03 --> company/index called
INFO - 2016-06-30 16:13:03 --> user/index called
INFO - 2016-06-30 16:13:03 --> brand/index called
INFO - 2016-06-30 16:13:03 --> store/index called
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:03 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:03 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:03 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:03 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:03 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:10 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:10 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:10 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:13:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:10 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:13:12 --> company/index called
INFO - 2016-06-30 16:13:12 --> store/index called
INFO - 2016-06-30 16:13:12 --> user/index called
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:13:12 --> brand/index called
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:12 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:12 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:12 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:12 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:13 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:13:18 --> brand/index called
INFO - 2016-06-30 16:13:18 --> user/index called
INFO - 2016-06-30 16:13:18 --> company/index called
INFO - 2016-06-30 16:13:18 --> store/index called
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:23 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:13:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:23 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:28 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:28 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:28 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:13:48 --> store/index called
INFO - 2016-06-30 16:13:48 --> company/index called
INFO - 2016-06-30 16:13:48 --> brand/index called
INFO - 2016-06-30 16:13:48 --> user/index called
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:48 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:53 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:13:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:53 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:13:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:13:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:13:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:13:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:13:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:13:58 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:13:58 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:13:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:13:58 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:13:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:13:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:13:58 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:14:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:14:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:14:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:14:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:14:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:14:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:14:02 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:14:02 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:14:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:14:02 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:14:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:14:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:14:02 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:14:16 --> brand/index called
INFO - 2016-06-30 16:14:16 --> store/index called
INFO - 2016-06-30 16:14:16 --> company/index called
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:14:16 --> user/index called
DEBUG - 2016-06-30 16:14:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:14:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:14:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:14:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:14:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:14:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:14:29 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:14:29 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:14:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:14:30 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:14:30 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:14:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:15:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:15:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:15:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:15:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:15:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:15:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:15:44 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:15:44 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:15:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:15:44 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:15:44 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:15:44 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:15:44 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:15:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:15:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:15:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:15:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:15:48 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:15:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:15:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:15:48 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:18:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:13 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:18:13 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:18:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:18:13 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:18:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:18:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:18:13 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:18:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:17 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:18:17 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:18:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:18:17 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:18:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:18:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:18:17 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:18:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:18:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:18:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:18:31 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:18:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:18:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:18:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:18:35 --> store/index called
INFO - 2016-06-30 16:18:35 --> user/index called
INFO - 2016-06-30 16:18:35 --> brand/index called
INFO - 2016-06-30 16:18:35 --> company/index called
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:35 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:18:35 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:18:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:18:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:18:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:18:35 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:18:52 --> brand/index called
INFO - 2016-06-30 16:18:52 --> company/index called
INFO - 2016-06-30 16:18:52 --> user/index called
INFO - 2016-06-30 16:18:52 --> store/index called
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:52 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:18:52 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:18:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:18:52 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:18:52 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:18:53 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:18:57 --> store/index called
INFO - 2016-06-30 16:18:57 --> user/index called
INFO - 2016-06-30 16:18:57 --> company/index called
INFO - 2016-06-30 16:18:57 --> brand/index called
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:18:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:18:57 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:18:57 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:18:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:18:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:18:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:18:57 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:19:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:01 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:19:01 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:19:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:19:01 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:19:01 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:19:01 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:19:01 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:19:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:06 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:19:06 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:19:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:19:06 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:19:06 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:19:06 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:19:06 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:19:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:09 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:19:09 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:19:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:19:09 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:19:09 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:19:10 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:19:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:14 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:19:14 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:19:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:19:14 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:19:14 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:19:15 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:19:36 --> company/index called
INFO - 2016-06-30 16:19:36 --> user/index called
INFO - 2016-06-30 16:19:36 --> store/index called
INFO - 2016-06-30 16:19:36 --> brand/index called
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:36 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:19:36 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:19:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:19:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:19:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:19:36 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:19:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:40 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:19:40 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:19:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:19:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:19:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:19:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:19:40 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:19:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:43 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:19:43 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:19:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:19:43 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:19:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:19:43 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:19:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:19:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:19:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:19:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:19:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:19:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:19:56 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:19:56 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:19:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:19:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:19:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:19:56 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:20:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:20:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:20:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:20:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:20:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:20:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:20:07 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:20:07 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:20:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:20:07 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:20:07 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:20:07 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:21:52 --> company/index called
INFO - 2016-06-30 16:21:52 --> user/index called
INFO - 2016-06-30 16:21:52 --> brand/index called
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:21:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:21:52 --> store/index called
DEBUG - 2016-06-30 16:21:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:21:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:21:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:21:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:21:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:21:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:21:57 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:21:57 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:21:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:21:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:21:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:21:57 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:23:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:04 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 16:23:04 --> store/index called
INFO - 2016-06-30 16:23:04 --> brand/index called
DEBUG - 2016-06-30 16:23:04 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:04 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:04 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 16:23:04 --> user/index called
INFO - 2016-06-30 16:23:04 --> company/index called
DEBUG - 2016-06-30 16:23:04 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:23:12 --> brand/index called
INFO - 2016-06-30 16:23:12 --> user/index called
INFO - 2016-06-30 16:23:12 --> company/index called
INFO - 2016-06-30 16:23:12 --> store/index called
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:12 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:23:12 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:23:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:23:12 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:23:12 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:23:12 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:23:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:23:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:23:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:23:23 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:23:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:23:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:23:23 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:23:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:32 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:23:32 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:23:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:23:32 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:23:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:23:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:23:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:23:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:23:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:23:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:23:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:23:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:23:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:23:46 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:23:46 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:23:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:23:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:23:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:23:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:24:16 --> store/index called
INFO - 2016-06-30 16:24:16 --> user/index called
INFO - 2016-06-30 16:24:16 --> brand/index called
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:24:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:24:16 --> company/index called
DEBUG - 2016-06-30 16:24:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:24:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:24:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:24:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:24:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:24:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:24:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:24:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:24:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:24:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:24:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:24:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:24:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:24:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:24:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:24:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:24:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:24:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:24:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:24:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:24:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:24:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:24:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:24:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:24:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:24:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:24:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:24:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:24:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:24:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:24:38 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:24:38 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:24:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:24:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:24:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:24:38 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:25:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:25:35 --> company/index called
INFO - 2016-06-30 16:25:35 --> store/index called
INFO - 2016-06-30 16:25:35 --> brand/index called
INFO - 2016-06-30 16:25:35 --> user/index called
DEBUG - 2016-06-30 16:25:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:25:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:25:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:25:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:25:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:25:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:25:36 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:25:36 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:25:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:25:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:25:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:25:36 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:26:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:26:16 --> brand/index called
INFO - 2016-06-30 16:26:16 --> user/index called
INFO - 2016-06-30 16:26:16 --> store/index called
INFO - 2016-06-30 16:26:16 --> company/index called
DEBUG - 2016-06-30 16:26:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:26:17 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:26:17 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:26:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:26:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:26:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:26:17 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:26:31 --> company/index called
INFO - 2016-06-30 16:26:31 --> brand/index called
INFO - 2016-06-30 16:26:31 --> user/index called
INFO - 2016-06-30 16:26:31 --> store/index called
DEBUG - 2016-06-30 16:26:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:26:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:26:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:26:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:26:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:26:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:26:32 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:26:32 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:26:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:26:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:26:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:26:33 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:27:13 --> company/index called
INFO - 2016-06-30 16:27:13 --> brand/index called
INFO - 2016-06-30 16:27:13 --> user/index called
INFO - 2016-06-30 16:27:13 --> store/index called
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:27:13 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:27:13 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:27:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:27:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:27:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:27:13 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:28:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:28:01 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 16:28:01 --> user/index called
INFO - 2016-06-30 16:28:01 --> brand/index called
DEBUG - 2016-06-30 16:28:01 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:28:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
INFO - 2016-06-30 16:28:01 --> company/index called
INFO - 2016-06-30 16:28:01 --> store/index called
DEBUG - 2016-06-30 16:28:01 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:28:01 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:28:01 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:32:29 --> user/index called
INFO - 2016-06-30 16:32:29 --> store/index called
INFO - 2016-06-30 16:32:29 --> brand/index called
INFO - 2016-06-30 16:32:29 --> company/index called
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:32:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:32:29 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:32:29 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:32:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:32:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:32:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:32:29 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:33:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:33:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:33:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:33:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:33:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:33:47 --> user/index called
INFO - 2016-06-30 16:33:47 --> brand/index called
INFO - 2016-06-30 16:33:47 --> store/index called
INFO - 2016-06-30 16:33:47 --> company/index called
DEBUG - 2016-06-30 16:33:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:33:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:33:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:33:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:33:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:33:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:33:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:33:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:33:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:33:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:33:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:33:49 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:37:19 --> user/index called
INFO - 2016-06-30 16:37:19 --> brand/index called
INFO - 2016-06-30 16:37:19 --> company/index called
INFO - 2016-06-30 16:37:19 --> store/index called
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:37:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:37:19 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:37:19 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:37:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:37:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:37:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:37:19 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:38:55 --> store/index called
INFO - 2016-06-30 16:38:55 --> company/index called
INFO - 2016-06-30 16:38:55 --> brand/index called
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:38:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:38:55 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-30 16:38:55 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-30 16:38:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:38:55 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:38:55 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:39:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:30 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 16:39:30 --> store/index called
DEBUG - 2016-06-30 16:39:30 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 16:39:30 --> company/index called
DEBUG - 2016-06-30 16:39:30 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
INFO - 2016-06-30 16:39:30 --> brand/index called
DEBUG - 2016-06-30 16:39:30 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-30 16:39:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:39:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:39:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:39:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:39:35 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:39:39 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:40 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:39:40 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:39:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:39:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:39:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:39:40 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:39:40 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:39:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:39:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:39:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:39:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:39:41 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:39:41 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:39:46 --> store/index called
DEBUG - 2016-06-30 16:39:46 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:39:46 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 16:39:46 --> company/index called
DEBUG - 2016-06-30 16:39:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:39:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:39:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:39:46 --> user/index called
INFO - 2016-06-30 16:39:46 --> brand/index called
DEBUG - 2016-06-30 16:39:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:39:50 --> store/index called
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:39:50 --> brand/index called
INFO - 2016-06-30 16:39:50 --> company/index called
DEBUG - 2016-06-30 16:39:50 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-30 16:39:50 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-30 16:39:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:39:50 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-30 16:39:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:39:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:39:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:39:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:39:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:39:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:39:57 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:39:57 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:39:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:39:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:39:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:39:57 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:08 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:08 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:08 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:18 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:22 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:22 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:22 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:25 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:25 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:25 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:25 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:29 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:29 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:29 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:29 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:29 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:29 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:34 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:34 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:34 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:34 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:38 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:38 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:38 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:38 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:38 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:39 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:42 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:42 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:42 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:42 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:42 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:50 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:50 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:50 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:50 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:50 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:50 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:40:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:40:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:40:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:40:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:40:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:40:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:40:57 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:40:57 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:40:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:40:57 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:40:57 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:40:57 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:40:57 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:41:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:41:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:41:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:41:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:41:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:41:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:41:02 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:41:02 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:41:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:41:02 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:41:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:41:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:41:02 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:41:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:41:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:41:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:41:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:41:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:41:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:41:06 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:41:06 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:41:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:41:06 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:41:06 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:41:06 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:41:06 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:41:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:41:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:41:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:41:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:41:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:41:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:41:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:41:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:41:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:41:18 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:41:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:41:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:41:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:42:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:42:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:42:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:42:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:42:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:42:58 --> brand/index called
DEBUG - 2016-06-30 16:42:58 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 16:42:58 --> user/index called
DEBUG - 2016-06-30 16:42:58 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:42:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:42:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:42:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:42:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:42:58 --> store/index called
INFO - 2016-06-30 16:42:58 --> company/index called
DEBUG - 2016-06-30 16:42:58 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:43:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:43:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:43:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:43:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:43:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:43:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:43:25 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:43:25 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:43:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:43:25 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:43:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:43:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:43:25 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:43:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:43:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:43:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:43:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:43:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:43:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:43:34 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:43:34 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:43:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:43:34 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:43:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:43:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:43:34 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:43:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:43:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:43:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:43:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:43:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:43:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:43:40 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:43:40 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:43:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:43:40 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:43:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:43:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:43:40 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:44:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:44:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:44:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:44:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:44:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:44:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:44:32 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:44:32 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:44:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:44:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:44:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:44:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:48:10 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:48:10 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:48:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:48:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:48:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:48:10 --> brand/index called
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:48:10 --> store/index called
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:48:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:48:10 --> company/index called
INFO - 2016-06-30 16:48:10 --> user/index called
DEBUG - 2016-06-30 16:48:10 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:53:11 --> user/index called
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 16:53:11 --> store/index called
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 16:53:11 --> company/index called
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:53:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:53:11 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:53:11 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:53:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
INFO - 2016-06-30 16:53:11 --> brand/index called
DEBUG - 2016-06-30 16:53:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:53:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:53:12 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:53:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:53:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:53:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:53:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:53:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:53:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:53:45 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:53:45 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:53:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:53:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:53:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:53:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:54:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:54:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:54:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:54:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:54:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:54:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:54:02 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:54:02 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:54:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:54:02 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:54:02 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:54:02 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:54:02 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:54:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:54:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:54:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:54:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:54:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:54:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:54:08 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:54:08 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:54:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:54:08 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:54:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:54:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:54:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:54:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:54:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:54:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:54:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:54:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:54:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:54:16 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:54:16 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:54:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:54:16 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:54:16 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:54:16 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 16:59:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 16:59:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 16:59:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 16:59:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 16:59:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 16:59:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 16:59:58 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 16:59:58 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 16:59:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 16:59:58 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 16:59:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 16:59:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 16:59:58 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:01:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:01:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:01:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:01:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:01:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:01:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:01:22 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:01:22 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:01:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:01:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:01:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:01:22 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:01:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:01:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:01:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:01:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:01:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:01:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:01:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:01:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:01:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:01:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:01:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:01:23 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:05:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:05:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:05:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:05:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:05:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:05:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:05:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:05:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:05:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:05:32 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 17:05:32 --> user/index called
INFO - 2016-06-30 17:05:32 --> brand/index called
INFO - 2016-06-30 17:05:32 --> company/index called
DEBUG - 2016-06-30 17:05:32 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 17:05:32 --> store/index called
DEBUG - 2016-06-30 17:05:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:05:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:05:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:05:34 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:12:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:12:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:12:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:12:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:12:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:12:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:12:54 --> user/index called
INFO - 2016-06-30 17:12:54 --> company/index called
INFO - 2016-06-30 17:12:54 --> brand/index called
DEBUG - 2016-06-30 17:12:54 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:12:54 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:12:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:12:54 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:12:54 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 17:12:54 --> store/index called
DEBUG - 2016-06-30 17:12:54 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:13:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:13:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:13:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:13:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:13:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:13:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:13:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 17:13:23 --> store/index called
DEBUG - 2016-06-30 17:13:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 17:13:23 --> brand/index called
INFO - 2016-06-30 17:13:23 --> user/index called
INFO - 2016-06-30 17:13:23 --> company/index called
DEBUG - 2016-06-30 17:13:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:13:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:13:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:13:24 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:14:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:14:05 --> store/index called
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:14:05 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:14:05 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:14:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:14:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:14:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:14:05 --> brand/index called
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:14:05 --> company/index called
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:14:05 --> user/index called
DEBUG - 2016-06-30 17:14:06 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:14:50 --> store/index called
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:14:50 --> company/index called
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:14:50 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:14:50 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 17:14:50 --> brand/index called
DEBUG - 2016-06-30 17:14:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:14:50 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:14:50 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:14:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:14:50 --> user/index called
DEBUG - 2016-06-30 17:14:50 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:15:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:15:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:15:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:15:18 --> brand/index called
INFO - 2016-06-30 17:15:18 --> store/index called
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:15:18 --> user/index called
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:15:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:15:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:15:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:15:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:15:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:15:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:15:18 --> company/index called
DEBUG - 2016-06-30 17:15:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:17:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:17:01 --> user/index called
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 17:17:01 --> store/index called
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:17:01 --> company/index called
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:17:01 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:17:01 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:17:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:17:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:17:01 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:17:01 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 17:17:01 --> brand/index called
DEBUG - 2016-06-30 17:17:01 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:17:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:17:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:17:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:17:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:17:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:17:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:17:26 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:17:26 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:17:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:17:26 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 17:17:26 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:17:26 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:17:26 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:17:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:17:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:17:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:17:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:17:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:17:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:17:34 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:17:34 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:17:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:17:34 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 17:17:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:17:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:17:34 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:17:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:17:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:17:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:17:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:17:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:17:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:17:52 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:17:52 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:17:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:17:52 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:17:52 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:17:52 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:18:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:18:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:18:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:18:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:18:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:18:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:18:11 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:18:11 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:18:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:18:11 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:18:11 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:18:11 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:24:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:24:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:24:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:24:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:24:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:24:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:24:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:24:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:24:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:24:54 --> user/index called
INFO - 2016-06-30 17:24:54 --> brand/index called
INFO - 2016-06-30 17:24:54 --> company/index called
INFO - 2016-06-30 17:24:54 --> store/index called
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:25:18 --> store/index called
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:25:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:25:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:25:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:25:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:25:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:25:18 --> user/index called
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:25:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:25:18 --> company/index called
DEBUG - 2016-06-30 17:25:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:25:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:25:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:25:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:25:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:25:19 --> brand/index called
DEBUG - 2016-06-30 17:25:19 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:26:06 --> user/index called
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:26:06 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:26:06 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:26:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:26:06 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:26:06 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:26:06 --> store/index called
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:26:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:26:06 --> company/index called
DEBUG - 2016-06-30 17:26:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:26:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:26:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:26:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:26:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:26:07 --> brand/index called
DEBUG - 2016-06-30 17:26:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:26:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:26:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:26:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:26:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:26:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:26:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:26:18 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 17:26:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:26:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:26:18 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 17:26:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:26:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:26:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:26:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:26:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:31:28 --> user/index called
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:31:28 --> brand/index called
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:31:28 --> store/index called
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:31:28 --> company/index called
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:31:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:31:28 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:31:28 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:31:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:31:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:31:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:31:28 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:32:18 --> company/index called
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:32:18 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:32:18 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:32:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:32:18 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:32:18 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:32:18 --> user/index called
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:32:18 --> brand/index called
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:32:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:32:18 --> store/index called
DEBUG - 2016-06-30 17:32:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:36:55 --> user/index called
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:36:55 --> company/index called
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:36:55 --> store/index called
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:36:55 --> brand/index called
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:36:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:36:55 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:36:55 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:36:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:36:55 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:36:55 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:36:55 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:37:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:37:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:37:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:37:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:37:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:37:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:37:13 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:37:13 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:37:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:37:13 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:37:13 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:37:14 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:37:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:37:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:37:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:37:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:37:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:37:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:37:17 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:37:17 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:37:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:37:17 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 17:37:17 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:37:17 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:37:18 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:37:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:37:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:37:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:37:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:37:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:37:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:37:41 --> user/index called
DEBUG - 2016-06-30 17:37:41 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 17:37:41 --> store/index called
DEBUG - 2016-06-30 17:37:41 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 17:37:41 --> brand/index called
INFO - 2016-06-30 17:37:41 --> company/index called
DEBUG - 2016-06-30 17:37:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:37:42 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:37:43 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:37:54 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:39:07 --> store/index called
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 17:39:07 --> brand/index called
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:39:07 --> user/index called
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:39:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:39:07 --> company/index called
DEBUG - 2016-06-30 17:39:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:39:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:39:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:39:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:39:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:39:08 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:39:08 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:39:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:39:08 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:39:08 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:39:08 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:40:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:40:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:40:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:40:41 --> company/index called
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:40:41 --> user/index called
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:40:41 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:40:41 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 17:40:41 --> store/index called
DEBUG - 2016-06-30 17:40:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:40:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:40:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:40:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:40:41 --> brand/index called
DEBUG - 2016-06-30 17:40:41 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:44:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:44:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:44:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:44:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:44:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:44:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:44:41 --> company/index called
INFO - 2016-06-30 17:44:41 --> user/index called
DEBUG - 2016-06-30 17:44:41 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 17:44:41 --> brand/index called
INFO - 2016-06-30 17:44:41 --> store/index called
DEBUG - 2016-06-30 17:44:41 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:44:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:44:41 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:44:41 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:44:42 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:46:50 --> brand/index called
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:46:50 --> company/index called
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:46:50 --> user/index called
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:46:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:46:51 --> store/index called
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:46:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:46:51 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:46:51 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:46:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:46:51 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:46:51 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:46:51 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:50:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:50:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:50:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:50:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:50:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:50:09 --> store/index called
INFO - 2016-06-30 17:50:09 --> brand/index called
INFO - 2016-06-30 17:50:09 --> company/index called
INFO - 2016-06-30 17:50:09 --> user/index called
DEBUG - 2016-06-30 17:51:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:51:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:51:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:51:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:51:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:51:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:51:48 --> brand/index called
INFO - 2016-06-30 17:51:48 --> user/index called
DEBUG - 2016-06-30 17:51:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
INFO - 2016-06-30 17:51:48 --> company/index called
INFO - 2016-06-30 17:51:48 --> store/index called
DEBUG - 2016-06-30 17:51:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:51:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:51:48 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:51:48 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:51:49 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:52:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:52:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:52:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:52:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:52:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:52:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:52:48 --> brand/index called
INFO - 2016-06-30 17:52:48 --> user/index called
DEBUG - 2016-06-30 17:52:48 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:52:48 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 17:52:48 --> store/index called
INFO - 2016-06-30 17:52:48 --> company/index called
DEBUG - 2016-06-30 17:52:49 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:52:50 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:52:50 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:52:51 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:54:24 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:54:24 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:54:24 --> store/index called
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:54:24 --> company/index called
DEBUG - 2016-06-30 17:54:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:54:24 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:54:24 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:54:30 --> brand/index called
INFO - 2016-06-30 17:54:30 --> user/index called
DEBUG - 2016-06-30 17:54:30 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:54:50 --> brand/index called
INFO - 2016-06-30 17:54:50 --> store/index called
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:54:50 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:54:50 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:54:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:54:50 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:54:50 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:54:50 --> user/index called
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:54:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:54:50 --> company/index called
DEBUG - 2016-06-30 17:54:50 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:55:31 --> user/index called
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:55:31 --> store/index called
DEBUG - 2016-06-30 17:55:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:55:32 --> brand/index called
INFO - 2016-06-30 17:55:32 --> company/index called
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:55:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:55:32 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:55:32 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:55:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:55:32 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:55:32 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:55:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:56:05 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:05 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:56:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:56:05 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:56:05 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 17:56:05 --> brand/index called
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:56:06 --> user/index called
DEBUG - 2016-06-30 17:56:06 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:56:06 --> company/index called
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:56:06 --> store/index called
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 17:56:15 --> user/index called
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 17:56:15 --> brand/index called
DEBUG - 2016-06-30 17:56:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:56:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:56:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:56:26 --> company/index called
DEBUG - 2016-06-30 17:56:26 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:56:26 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 17:56:26 --> store/index called
DEBUG - 2016-06-30 17:56:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:56:26 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:56:26 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:56:27 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 17:58:45 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 17:58:45 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 17:58:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 17:58:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 17:58:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:58:45 --> brand/index called
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:58:45 --> company/index called
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:58:45 --> store/index called
DEBUG - 2016-06-30 17:58:45 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 17:58:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 17:58:45 --> user/index called
DEBUG - 2016-06-30 18:24:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:24:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:24:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:24:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:24:45 --> brand/index called
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:24:45 --> company/index called
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:24:45 --> store/index called
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:24:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:24:46 --> user/index called
DEBUG - 2016-06-30 18:25:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:25:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:25:10 --> brand/index called
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:25:10 --> user/index called
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:25:10 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:25:10 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 18:25:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:25:10 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:25:10 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:25:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:25:10 --> store/index called
DEBUG - 2016-06-30 18:25:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:25:12 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 18:25:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:25:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:25:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:25:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:25:12 --> company/index called
DEBUG - 2016-06-30 18:26:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:26:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:26:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:26:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:26:58 --> user/index called
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:26:58 --> company/index called
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:26:58 --> store/index called
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:26:58 --> brand/index called
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:26:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:26:58 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:26:58 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 18:26:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:26:58 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:26:58 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:27:02 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 18:28:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:28:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:28:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:28:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:28:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:28:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:28:22 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:28:22 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 18:28:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:28:22 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 18:28:22 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:28:22 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:28:22 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 18:45:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:45:47 --> company/index called
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:45:47 --> brand/index called
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:45:47 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:45:47 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 18:45:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:45:47 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:45:47 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:45:47 --> store/index called
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:45:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:45:47 --> user/index called
DEBUG - 2016-06-30 18:45:48 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 18:46:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:46:36 --> user/index called
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:46:36 --> brand/index called
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:46:36 --> company/index called
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:46:36 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:46:36 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 18:46:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:46:36 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:46:36 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:46:36 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:46:36 --> store/index called
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:46:55 --> user/index called
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:46:55 --> company/index called
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:46:55 --> brand/index called
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:46:55 --> store/index called
DEBUG - 2016-06-30 18:46:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:46:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:46:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:46:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:46:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:46:56 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:46:56 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 18:46:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:46:56 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:46:56 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:46:56 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 18:48:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:48:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:48:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:48:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:48:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:48:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:48:39 --> user/index called
DEBUG - 2016-06-30 18:48:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:48:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:48:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:48:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:48:53 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:48:53 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 18:48:53 --> store/index called
INFO - 2016-06-30 18:48:53 --> brand/index called
DEBUG - 2016-06-30 18:48:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:48:53 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:48:53 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:48:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:48:53 --> company/index called
DEBUG - 2016-06-30 18:48:54 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:50:34 --> store/index called
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:50:34 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:50:34 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 18:50:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:50:34 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:50:34 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:50:34 --> user/index called
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:50:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:50:34 --> company/index called
INFO - 2016-06-30 18:50:34 --> brand/index called
DEBUG - 2016-06-30 18:50:34 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-30 18:51:31 --> company/index called
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:51:31 --> store/index called
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:51:31 --> brand/index called
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 18:51:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 18:51:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 18:51:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 18:51:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 18:51:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 18:51:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 18:51:31 --> user/index called
DEBUG - 2016-06-30 18:51:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:03:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:03:30 --> company/index called
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:03:30 --> store/index called
INFO - 2016-06-30 19:03:30 --> brand/index called
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:03:30 --> user/index called
DEBUG - 2016-06-30 19:03:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:03:46 --> user/index called
INFO - 2016-06-30 19:03:46 --> company/index called
INFO - 2016-06-30 19:03:46 --> brand/index called
INFO - 2016-06-30 19:03:46 --> store/index called
DEBUG - 2016-06-30 19:03:46 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:03:46 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 19:03:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:03:50 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:03:50 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:03:51 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:19:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:19:21 --> user/index called
INFO - 2016-06-30 19:19:21 --> store/index called
DEBUG - 2016-06-30 19:19:21 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:19:21 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 19:19:21 --> brand/index called
INFO - 2016-06-30 19:19:21 --> company/index called
DEBUG - 2016-06-30 19:19:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:19:21 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:19:21 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:19:21 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:19:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:19:45 --> brand/index called
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:19:45 --> user/index called
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:19:45 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:19:45 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 19:19:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:19:45 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:19:45 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:19:45 --> company/index called
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:19:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:19:45 --> store/index called
DEBUG - 2016-06-30 19:19:46 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:21:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:21:23 --> company/index called
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:21:23 --> brand/index called
DEBUG - 2016-06-30 19:21:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:21:23 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 19:21:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:21:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:21:23 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:21:23 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:21:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:21:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:21:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:21:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:21:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:21:24 --> user/index called
DEBUG - 2016-06-30 19:21:25 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:21:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:21:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:21:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:21:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:21:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:21:25 --> store/index called
DEBUG - 2016-06-30 19:23:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:23:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:23:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:23:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:23:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:24:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:24:02 --> brand/index called
INFO - 2016-06-30 19:24:02 --> user/index called
INFO - 2016-06-30 19:24:02 --> store/index called
DEBUG - 2016-06-30 19:24:02 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:24:02 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 19:24:02 --> company/index called
DEBUG - 2016-06-30 19:24:04 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:24:04 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:24:04 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:24:06 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:25:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:25:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:25:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:25:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:25:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:25:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:25:30 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:25:30 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 19:25:30 --> store/index called
DEBUG - 2016-06-30 19:25:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
INFO - 2016-06-30 19:25:30 --> brand/index called
INFO - 2016-06-30 19:25:30 --> company/index called
DEBUG - 2016-06-30 19:25:30 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:25:30 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 19:25:31 --> user/index called
DEBUG - 2016-06-30 19:25:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:32:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:32:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:32:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:32:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:32:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:32:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:32:19 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:32:19 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 19:32:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:32:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:32:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:32:20 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:46:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:46:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:46:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:46:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:46:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:46:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:46:59 --> store/index called
INFO - 2016-06-30 19:46:59 --> company/index called
INFO - 2016-06-30 19:46:59 --> user/index called
DEBUG - 2016-06-30 19:46:59 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:46:59 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 19:46:59 --> brand/index called
DEBUG - 2016-06-30 19:46:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:46:59 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:46:59 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:47:00 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:47:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:47:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:47:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:47:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:47:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:47:40 --> company/index called
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:47:40 --> brand/index called
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:47:40 --> user/index called
DEBUG - 2016-06-30 19:47:40 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:47:40 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:47:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:47:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:47:40 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:47:40 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 19:47:40 --> store/index called
DEBUG - 2016-06-30 19:47:41 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:50:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:50:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:50:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:50:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:50:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:50:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:50:23 --> company/index called
INFO - 2016-06-30 19:50:23 --> store/index called
INFO - 2016-06-30 19:50:23 --> brand/index called
DEBUG - 2016-06-30 19:50:23 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:50:24 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 19:50:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:50:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:50:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:50:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:50:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:50:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:50:25 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:50:25 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
INFO - 2016-06-30 19:50:25 --> user/index called
DEBUG - 2016-06-30 19:50:27 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:53:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:53:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:53:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:53:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:53:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:53:27 --> brand/index called
INFO - 2016-06-30 19:53:27 --> store/index called
DEBUG - 2016-06-30 19:53:27 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:53:27 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 19:53:27 --> user/index called
INFO - 2016-06-30 19:53:27 --> company/index called
DEBUG - 2016-06-30 19:53:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:53:27 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:53:27 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:53:28 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:59:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:59:35 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:59:35 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:59:35 --> company/index called
DEBUG - 2016-06-30 19:59:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:59:35 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:59:35 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:59:35 --> brand/index called
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:59:35 --> store/index called
DEBUG - 2016-06-30 19:59:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:36 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 19:59:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:59:36 --> user/index called
DEBUG - 2016-06-30 19:59:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:59:44 --> user/index called
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:59:44 --> brand/index called
DEBUG - 2016-06-30 19:59:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 19:59:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:59:51 --> company/index called
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 19:59:51 --> store/index called
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 19:59:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 19:59:51 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 19:59:51 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 19:59:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 19:59:51 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 19:59:51 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 19:59:52 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 23:49:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:49:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:49:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:49:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 23:49:09 --> company/index called
INFO - 2016-06-30 23:49:09 --> brand/index called
INFO - 2016-06-30 23:49:09 --> user/index called
INFO - 2016-06-30 23:49:09 --> store/index called
DEBUG - 2016-06-30 23:50:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:09 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 23:50:09 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 23:50:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 23:50:09 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 23:50:09 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 23:50:10 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 23:50:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:28 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 23:50:28 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 23:50:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 23:50:28 --> Model_User->checkAuthorityCompanyId(402) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-06-30 23:50:28 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 23:50:28 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 23:50:28 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 23:50:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 23:50:31 --> store/index called
INFO - 2016-06-30 23:50:31 --> brand/index called
INFO - 2016-06-30 23:50:31 --> company/index called
DEBUG - 2016-06-30 23:50:31 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 23:50:31 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 23:50:31 --> user/index called
DEBUG - 2016-06-30 23:50:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 23:50:31 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 23:50:31 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 23:50:32 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 23:50:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:50:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 23:50:58 --> company/index called
DEBUG - 2016-06-30 23:50:58 --> Api\Controller_Information->index(46) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-30 23:50:58 --> Api\Controller_Information->setParams(210) - 【INFORMATION API】:SET PARAM
INFO - 2016-06-30 23:50:58 --> brand/index called
INFO - 2016-06-30 23:50:58 --> store/index called
DEBUG - 2016-06-30 23:50:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 23:50:58 --> Api\Controller_Information->index(133) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-30 23:51:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:51:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:51:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:51:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:51:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 23:51:06 --> store/index called
INFO - 2016-06-30 23:51:06 --> company/index called
DEBUG - 2016-06-30 23:51:06 --> Api\Controller_Coupon->index(45) - 【COUPON LIST API】:START
DEBUG - 2016-06-30 23:51:06 --> Api\Controller_Coupon->setParams(198) - 【COUPON API】:SET PARAM
INFO - 2016-06-30 23:51:06 --> brand/index called
DEBUG - 2016-06-30 23:51:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 23:51:06 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 23:51:06 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 23:51:06 --> Api\Controller_Coupon->index(122) - 【COUPON LIST API】:END
DEBUG - 2016-06-30 23:51:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:51:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:51:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:51:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:51:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:51:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:51:19 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 23:51:19 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-06-30 23:51:19 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 23:51:19 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 23:51:19 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 23:51:19 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 23:55:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:55:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:55:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:55:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:55:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:55:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 23:55:30 --> user/index called
INFO - 2016-06-30 23:55:30 --> company/index called
INFO - 2016-06-30 23:55:30 --> brand/index called
DEBUG - 2016-06-30 23:55:30 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 23:55:30 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 23:55:30 --> store/index called
DEBUG - 2016-06-30 23:55:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 23:55:30 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 23:55:30 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 23:55:31 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
DEBUG - 2016-06-30 23:56:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:56:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:56:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:56:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:56:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-30 23:56:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-30 23:56:46 --> store/index called
INFO - 2016-06-30 23:56:46 --> brand/index called
INFO - 2016-06-30 23:56:46 --> company/index called
DEBUG - 2016-06-30 23:56:46 --> Api\Controller_Daily_Store->index(23) - 【DAILY STORE LIST API】:START
DEBUG - 2016-06-30 23:56:46 --> Api\Controller_Daily_Store->setParams(72) - 【DAILY STORE API】:SET PARAM
INFO - 2016-06-30 23:56:46 --> user/index called
DEBUG - 2016-06-30 23:56:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-30 23:56:46 --> Model_User->checkAuthorityBrandIds(411) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-06-30 23:56:46 --> Model_User->checkAuthorityStoreIds(433) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-06-30 23:56:47 --> Api\Controller_Daily_Store->index(64) - 【DAILY STORE API】:END
