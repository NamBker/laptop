<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-06-29 00:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-29 00:11:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-29 00:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:11:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:11:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:12:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:12:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:12:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:22:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:22:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:22:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:23:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:23:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:23:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:23:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:23:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:24:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:24:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:24:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:25:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:25:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:25:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:25:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:25:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:25:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:25:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:28:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:28:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:28:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:28:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:29:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:29:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:29:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:31:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:31:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:31:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:31:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:31:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:31:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:31:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:31:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:31:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:31:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:31:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:31:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:32:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:32:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:32:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:32:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:32:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:32:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:32:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:32:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:32:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:32:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:32:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:32:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:35:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:35:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:35:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:36:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:36:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:36:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:36:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:41:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:41:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:41:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:41:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:41:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:41:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:41:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:41:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:41:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:41:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:49:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:49:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:49:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:51:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:51:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:51:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:51:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:51:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:51:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:51:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:51:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:51:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:51:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:51:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:58:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 00:58:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:58:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 00:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 00:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:03:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:03:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:03:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:03:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:03:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:03:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:03:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:03:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:03:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:03:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:13:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:13:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:13:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:13:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:13:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:13:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:14:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:14:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:14:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:16:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:16:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:16:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:16:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:17:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:17:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:17:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:17:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:22:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:22:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:24:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:24:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:24:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:24:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:25:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:26:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:27:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:27:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:27:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:27:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:27:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:27:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:29:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:29:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:29:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:29:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:29:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:29:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:29:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:29:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:29:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:29:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:29:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:29:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:29:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:32:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:32:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:32:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:33:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:33:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:33:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:33:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:33:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:33:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:33:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:33:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:33:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:47:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:47:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:47:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:47:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:48:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:48:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:48:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:48:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:48:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:48:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:48:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:50:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:50:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:51:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:51:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:51:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:51:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:53:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:53:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:54:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:54:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:54:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:54:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:54:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:54:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:54:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:54:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:57:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:57:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:57:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:57:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:57:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:57:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:57:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:57:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:57:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:57:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:57:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:57:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:58:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 01:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:58:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:58:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 01:58:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 01:58:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 01:58:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:00:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:05:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:05:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:05:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:05:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:05:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:05:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:05:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:05:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:05:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:05:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:06:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:06:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:08:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:08:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:08:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:11:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:11:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:11:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:11:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:12:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:12:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:12:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:13:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:13:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:13:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:13:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:13:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:13:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:14:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:14:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:14:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:14:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:14:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:22:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:22:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:25:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:25:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:25:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:25:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:28:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:28:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:28:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:28:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:28:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:28:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:28:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:28:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:28:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:28:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:28:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:29:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:29:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:29:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:30:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:30:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:30:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:30:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:30:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:30:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:30:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:30:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:30:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:30:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:30:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:31:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:31:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:31:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:31:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:31:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:31:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:31:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:31:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:31:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:31:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:31:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:31:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:31:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:31:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:31:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:31:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:31:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:31:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:44:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:44:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:45:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:45:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:46:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:46:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:46:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:46:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:46:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:50:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:50:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:50:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:50:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:50:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:50:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:51:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:51:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:53:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:53:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:53:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:54:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:54:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:55:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:55:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:55:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:55:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:57:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:57:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:57:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:57:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:57:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 02:57:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:57:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:57:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:57:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:57:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:57:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:57:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:57:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:57:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:57:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 02:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 02:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 02:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 02:58:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:58:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 02:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 02:59:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 02:59:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:00:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:00:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:00:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:00:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:00:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:00:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:00:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:00:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:00:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:00:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:00:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:00:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:00:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 03:09:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:09:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:09:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:09:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 03:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:17:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 03:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 03:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 03:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:20:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:20:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:20:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:20:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 03:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:21:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 03:21:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 03:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:21:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 03:21:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 03:21:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 03:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 03:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 03:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-29 10:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:39:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-29 10:39:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:39:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:39:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 10:39:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:39:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:40:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 10:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 10:41:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 10:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 10:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 10:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 10:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 10:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:04:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:04:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:04:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:04:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:04:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:04:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:06:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:06:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:06:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:06:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:06:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:07:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:08:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:08:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:08:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:08:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:08:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:36:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:36:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:37:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:37:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:37:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:38:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:38:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:38:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:38:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:38:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:38:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:38:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:38:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:38:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:38:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:38:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:39:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:39:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:39:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:39:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:39:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:39:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:40:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:40:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:40:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:40:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:40:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:40:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:42:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:42:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:42:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:44:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:48:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:48:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:48:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:48:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:48:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:48:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:48:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:48:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:48:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:48:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:48:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:48:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:48:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:48:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:48:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:48:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:48:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:48:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:50:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:50:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:50:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:51:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:51:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:51:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:51:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:51:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:51:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:55:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 11:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:55:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 11:55:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:55:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:55:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 11:55:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:55:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 11:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:00:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:00:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:00:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:00:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:00:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:00:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:00:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:00:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:01:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:01:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:02:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:02:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:02:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:03:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:03:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:03:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:03:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:03:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:03:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:08:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:08:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:08:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:08:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:08:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:08:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:10:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:10:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:10:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:10:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:10:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:10:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:12:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:12:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:12:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:12:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:12:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:12:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:12:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:22:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:22:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:22:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:22:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:22:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:22:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:22:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:22:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:24:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:24:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:24:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:24:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:28:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:28:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:28:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:28:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:31:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:31:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:31:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:34:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:34:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:34:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:34:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:34:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:34:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:34:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:34:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:34:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:34:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:34:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:34:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:34:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:34:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:34:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:34:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:34:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:35:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:35:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:35:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:36:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:36:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:36:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:36:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:36:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:36:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:36:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:36:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:36:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:43:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:43:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:43:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:43:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:43:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:43:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:43:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:49:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:49:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:49:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:49:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:49:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:49:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:50:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:50:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:50:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:52:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:52:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:52:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:52:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:52:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:56:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 12:56:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:56:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:56:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 12:56:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:56:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 12:56:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 12:56:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 12:56:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:22:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:22:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:22:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:22:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:22:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:22:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:22:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:22:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:22:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:22:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:22:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:22:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:22:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:23:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:23:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:23:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:23:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:23:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:25:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:25:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:25:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:25:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:25:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:25:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:26:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:26:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:26:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:26:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:27:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:27:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:27:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:27:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:34:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:34:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:34:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:35:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:35:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:37:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:37:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:38:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:38:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:38:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:38:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:38:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:38:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:38:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:38:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:38:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:38:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:38:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-29 13:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:42:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:42:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:42:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:42:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:44:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:44:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:44:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:45:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:45:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:45:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:45:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:45:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:45:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:45:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:45:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:45:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:45:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:45:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:45:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:45:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:45:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:47:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:47:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:47:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:47:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:47:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:47:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:48:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:48:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:49:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:50:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:50:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:50:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:50:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:50:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:53:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:53:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:53:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:53:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:53:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:53:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:53:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:53:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:53:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:53:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:53:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:53:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:53:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:53:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:53:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:54:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:54:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:54:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:58:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:59:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 13:59:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:59:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:59:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 13:59:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 13:59:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:59:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 13:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 13:59:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:59:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:59:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:59:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 13:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 13:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 13:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:00:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:00:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:00:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:00:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:41:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:41:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:42:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:42:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:42:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:42:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:42:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:42:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:42:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:42:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:42:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:42:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:42:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:44:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:44:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:45:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:45:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:45:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:45:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:45:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:45:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:45:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:45:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:45:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:45:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:45:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:45:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:45:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:45:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:45:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:45:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:45:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:45:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:46:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:46:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:47:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:47:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:52:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:52:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:52:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:53:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:53:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:53:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:55:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 14:55:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:55:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 14:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 14:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 14:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 14:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 14:56:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:05:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:21:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:21:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:21:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:22:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:22:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:22:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:22:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:22:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:25:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:25:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:25:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:27:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:27:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:27:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:27:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:33:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:33:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:33:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:33:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:38:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:38:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:38:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:38:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:38:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:38:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:38:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:38:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:38:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:38:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:38:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:38:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:38:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:39:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:39:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:39:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:41:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:41:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:41:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:41:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:41:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:41:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:41:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:41:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:41:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:41:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:45:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:49:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:49:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:49:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:49:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:49:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:49:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:49:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:49:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:49:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:49:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:49:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:49:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:52:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:52:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:53:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:53:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:53:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 15:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 15:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 15:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 15:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:00:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:00:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:00:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:00:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:00:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:00:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:04:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:04:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:04:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:20:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:20:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:20:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:20:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:20:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:20:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:20:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:20:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:20:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:20:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:20:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:20:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:20:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:20:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:20:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:20:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:22:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:22:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:22:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:22:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:22:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:22:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:22:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:22:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:24:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:24:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:37:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:37:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:37:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:37:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:37:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:38:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:39:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:39:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:39:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:39:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:40:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:41:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:41:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:41:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:41:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:41:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:42:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:51:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:51:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:51:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:51:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:51:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:51:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:51:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:51:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:51:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:51:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:51:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:52:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:52:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:52:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:52:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:52:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:52:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:52:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:52:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:55:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:55:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:55:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:55:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:55:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:55:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:55:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:55:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:55:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:56:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:56:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:56:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:56:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 16:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 16:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 16:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 16:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:01:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:01:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:01:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:01:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:01:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:01:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:01:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:01:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:06:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:06:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:06:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:08:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:08:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:08:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:08:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:08:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:08:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:08:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:08:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:08:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:08:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:08:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:08:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:08:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:08:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:08:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:12:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:12:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:12:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:12:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:12:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:12:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:12:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:12:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:14:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:14:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:18:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:18:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:18:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:18:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:18:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:18:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:18:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:18:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:19:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:19:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:19:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:19:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:19:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:19:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:19:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:19:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:19:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:19:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:19:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:19:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:19:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:19:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:19:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:20:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:20:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:20:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:20:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:20:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:20:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:20:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:20:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:20:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:20:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:24:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:24:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:24:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:25:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:25:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:25:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:25:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:25:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:25:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:26:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:26:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:26:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:26:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:26:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:26:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:26:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:26:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:26:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:26:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:29:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:29:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:29:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:29:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:29:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:30:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:30:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:30:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:30:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:30:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:30:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:38:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:38:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:38:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:38:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:38:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:39:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:39:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:39:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:40:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:40:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:43:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:43:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:43:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:43:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:43:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:43:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:43:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:44:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:44:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:44:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:44:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:44:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:45:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:45:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:45:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:49:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:49:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:49:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:49:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:49:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:49:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:49:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:50:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:50:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:50:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:50:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:50:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:50:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:50:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:50:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:50:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:50:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:50:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:51:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:51:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:51:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:51:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:51:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:51:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:51:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:51:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:51:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:51:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:51:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:51:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:51:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:52:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:52:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:52:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:52:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:52:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:52:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:55:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:55:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:55:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:56:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:56:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:56:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:56:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 17:56:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:56:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:56:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:56:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:56:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:58:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 17:58:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:58:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 17:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 17:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:00:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:00:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:00:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:01:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:02:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:02:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:02:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:02:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:06:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:06:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:06:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:06:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:06:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:06:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:09:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:09:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:09:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:09:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:09:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:09:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:09:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:09:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:09:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:09:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:10:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:10:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:10:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:10:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:10:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:10:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:10:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:10:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:10:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:10:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:10:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:10:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:10:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:11:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:11:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:11:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:11:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:11:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:11:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:11:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:14:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:16:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:16:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:16:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:16:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:16:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:16:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:16:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:16:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:16:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:16:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:16:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:16:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:16:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:16:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:16:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:16:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:17:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:17:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:17:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:19:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:19:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:20:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:20:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:21:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:21:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:21:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:21:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:21:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:21:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:22:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:22:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:22:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:22:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:28:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:28:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:42:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:43:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:43:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:43:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:43:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:46:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:46:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:46:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:49:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:49:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:50:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:50:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:50:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:50:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:50:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:50:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:51:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:51:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:51:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:51:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:51:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:51:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:52:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:54:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:54:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:54:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:57:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 18:57:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:57:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 18:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 18:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 18:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:57:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 18:57:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 18:57:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 18:57:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:02:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:02:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:02:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:02:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:03:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:03:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:03:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:03:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:03:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:03:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:06:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:06:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:06:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:06:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:06:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:06:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:06:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:12:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:12:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:12:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:14:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:14:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:14:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:14:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:14:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:15:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:15:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:15:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:16:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:16:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:16:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:19:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:19:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:19:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:19:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:19:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:19:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:19:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:20:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:20:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:20:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:20:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:20:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:29:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:29:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:29:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:30:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:30:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:30:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:30:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:30:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:30:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:32:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:32:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:32:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:32:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:32:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:32:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:33:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:33:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:33:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:34:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:34:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:34:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:36:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:36:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:36:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:36:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:36:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:43:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:43:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:43:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:43:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:43:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:43:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:51:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:51:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:51:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:51:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:51:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:51:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:51:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:51:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:51:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 19:59:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 19:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 19:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 20:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:01:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:01:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:02:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 20:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:04:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:05:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:05:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:05:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:05:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:05:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:05:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:05:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:05:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:05:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 20:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 20:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 20:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 20:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 20:07:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:07:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 20:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 20:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 20:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 20:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:07:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:07:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:07:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:07:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:08:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-29 20:08:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:08:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-29 20:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-29 20:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-06-29 20:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-29 20:08:43 --> Fuel\Core\Request::execute - Setting main Request
