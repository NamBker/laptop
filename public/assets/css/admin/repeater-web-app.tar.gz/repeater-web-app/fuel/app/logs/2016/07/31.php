<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-31 22:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 22:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-31 22:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-31 22:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 22:27:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 22:27:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 22:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 22:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 22:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:10:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:10:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:10:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:14:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:15:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:15:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:15:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:40:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:40:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:40:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:40:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:40:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:40:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:42:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:42:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:42:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:46:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:46:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:47:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:47:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:54:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-31 23:54:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:54:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-31 23:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-31 23:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-31 23:54:19 --> Fuel\Core\Request::execute - Setting main Request
