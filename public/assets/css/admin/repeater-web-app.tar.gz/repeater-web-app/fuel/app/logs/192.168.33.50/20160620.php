<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

DEBUG - 2016-06-20 10:47:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 10:47:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 10:47:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 10:47:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 10:47:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 10:47:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 10:47:54 --> user/index called
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 10:48:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 10:48:01 --> brand/index called
INFO - 2016-06-20 10:48:01 --> section/index called
INFO - 2016-06-20 10:48:01 --> company/index called
INFO - 2016-06-20 10:48:01 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 10:48:01 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [id] => 1
        )

)

DEBUG - 2016-06-20 10:49:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 10:49:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 10:49:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 10:49:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 10:49:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 10:49:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 10:49:29 --> company/index called
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 10:59:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 10:59:14 --> brand/index called
INFO - 2016-06-20 10:59:14 --> company/index called
INFO - 2016-06-20 10:59:14 --> store/index called
INFO - 2016-06-20 10:59:14 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 10:59:14 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:15:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:15:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:15:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:15:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:15:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:15:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:15:47 --> user/index called
DEBUG - 2016-06-20 11:15:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:15:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:15:48 --> brand/index called
INFO - 2016-06-20 11:15:48 --> store/index called
INFO - 2016-06-20 11:15:48 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:15:48 --> company/index called
INFO - 2016-06-20 11:15:48 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:31:29 --> user/index called
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:31:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:31:29 --> brand/index called
INFO - 2016-06-20 11:31:29 --> company/index called
INFO - 2016-06-20 11:31:29 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:31:29 --> store/index called
INFO - 2016-06-20 11:31:29 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:32:32 --> user/index called
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:32:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:32:32 --> company/index called
INFO - 2016-06-20 11:32:32 --> brand/index called
INFO - 2016-06-20 11:32:32 --> store/index called
INFO - 2016-06-20 11:32:32 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:32:32 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:33:54 --> user/index called
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:33:54 --> store/index called
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:33:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:33:54 --> brand/index called
INFO - 2016-06-20 11:33:54 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:33:54 --> company/index called
INFO - 2016-06-20 11:33:54 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:42:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:42:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:42:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:42:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:42:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:42:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:42:11 --> user/index called
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:42:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:42:12 --> brand/index called
INFO - 2016-06-20 11:42:12 --> store/index called
INFO - 2016-06-20 11:42:12 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:42:12 --> company/index called
INFO - 2016-06-20 11:42:12 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:44:11 --> user/index called
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:44:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:44:11 --> company/index called
INFO - 2016-06-20 11:44:11 --> store/index called
INFO - 2016-06-20 11:44:11 --> brand/index called
INFO - 2016-06-20 11:44:11 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:44:11 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:49:57 --> user/index called
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:49:57 --> store/index called
INFO - 2016-06-20 11:49:57 --> brand/index called
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:49:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:49:57 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:49:57 --> company/index called
INFO - 2016-06-20 11:49:57 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:51:03 --> user/index called
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:51:03 --> company/index called
INFO - 2016-06-20 11:51:03 --> brand/index called
INFO - 2016-06-20 11:51:03 --> store/index called
INFO - 2016-06-20 11:51:03 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:51:03 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:51:37 --> brand/index called
INFO - 2016-06-20 11:51:37 --> company/index called
INFO - 2016-06-20 11:51:37 --> user/index called
INFO - 2016-06-20 11:51:37 --> store/index called
INFO - 2016-06-20 11:51:37 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:51:37 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:51:59 --> user/index called
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 11:51:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 11:51:59 --> company/index called
INFO - 2016-06-20 11:51:59 --> brand/index called
INFO - 2016-06-20 11:51:59 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 11:51:59 --> store/index called
INFO - 2016-06-20 11:51:59 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 12:30:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:30:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:30:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:30:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:30:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:30:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:30:29 --> Api\Controller_Coupon->index(40) - 【COUPON LIST API】:START
DEBUG - 2016-06-20 12:30:29 --> Api\Controller_Coupon->setParams(158) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-20 12:30:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 12:30:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 12:30:29 --> Api\Controller_Coupon->index(89) - 【COUPON LIST API】:END
DEBUG - 2016-06-20 12:30:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:30:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:30:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:30:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:30:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:30:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:30:40 --> store/index called
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:35:16 --> user/index called
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:35:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:35:16 --> store/index called
INFO - 2016-06-20 12:35:16 --> brand/index called
INFO - 2016-06-20 12:35:16 --> company/index called
INFO - 2016-06-20 12:35:16 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 12:35:16 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:35:31 --> user/index called
DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:35:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
INFO - 2016-06-20 12:35:32 --> store/index called
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:35:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:35:32 --> brand/index called
INFO - 2016-06-20 12:35:32 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 12:35:32 --> company/index called
INFO - 2016-06-20 12:35:32 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:47:22 --> user/index called
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
INFO - 2016-06-20 12:47:22 --> store/index called
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:47:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:47:22 --> brand/index called
INFO - 2016-06-20 12:47:22 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 12:47:22 --> company/index called
INFO - 2016-06-20 12:47:22 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:47:44 --> user/index called
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:47:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:47:44 --> brand/index called
INFO - 2016-06-20 12:47:44 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 12:47:44 --> company/index called
INFO - 2016-06-20 12:47:44 --> store/index called
INFO - 2016-06-20 12:47:45 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:48:03 --> user/index called
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:48:03 --> store/index called
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:48:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:48:03 --> brand/index called
INFO - 2016-06-20 12:48:03 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 12:48:03 --> company/index called
INFO - 2016-06-20 12:48:03 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 12:53:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:53:59 --> user/index called
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:53:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:53:59 --> company/index called
INFO - 2016-06-20 12:53:59 --> brand/index called
INFO - 2016-06-20 12:53:59 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 12:53:59 --> store/index called
INFO - 2016-06-20 12:53:59 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:56:20 --> user/index called
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:56:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:56:20 --> store/index called
INFO - 2016-06-20 12:56:20 --> company/index called
INFO - 2016-06-20 12:56:20 --> brand/index called
INFO - 2016-06-20 12:56:20 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 12:56:20 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:56:52 --> user/index called
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 12:56:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 12:56:52 --> company/index called
INFO - 2016-06-20 12:56:52 --> brand/index called
INFO - 2016-06-20 12:56:52 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 12:56:52 --> store/index called
INFO - 2016-06-20 12:56:52 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:02:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:02:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:02:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:02:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:02:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:02:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:02:26 --> user/index called
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:02:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:02:27 --> brand/index called
INFO - 2016-06-20 13:02:27 --> company/index called
INFO - 2016-06-20 13:02:27 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:02:27 --> store/index called
INFO - 2016-06-20 13:02:27 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:03:46 --> user/index called
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:03:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:03:46 --> store/index called
INFO - 2016-06-20 13:03:46 --> company/index called
INFO - 2016-06-20 13:03:46 --> brand/index called
INFO - 2016-06-20 13:03:46 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:03:46 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:05:47 --> user/index called
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:05:47 --> store/index called
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:05:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:05:47 --> brand/index called
INFO - 2016-06-20 13:05:47 --> company/index called
INFO - 2016-06-20 13:05:47 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:05:47 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:07:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:07:35 --> brand/index called
INFO - 2016-06-20 13:07:35 --> section/index called
INFO - 2016-06-20 13:07:35 --> company/index called
INFO - 2016-06-20 13:07:35 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:07:35 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [id] => 1
        )

)

DEBUG - 2016-06-20 13:07:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:07:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:07:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:07:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:07:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:07:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:07:59 --> user/index called
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:08:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:08:13 --> brand/index called
INFO - 2016-06-20 13:08:13 --> company/index called
INFO - 2016-06-20 13:08:13 --> area/index called
INFO - 2016-06-20 13:08:13 --> store/index called
INFO - 2016-06-20 13:08:13 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:08:13 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [id] => 1
        )

)

DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:10:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:10:32 --> brand/index called
INFO - 2016-06-20 13:10:32 --> company/index called
INFO - 2016-06-20 13:10:32 --> store/index called
INFO - 2016-06-20 13:10:32 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:10:32 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:17:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:17:16 --> user/index called
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:17:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:17:16 --> company/index called
INFO - 2016-06-20 13:17:16 --> brand/index called
INFO - 2016-06-20 13:17:16 --> store/index called
INFO - 2016-06-20 13:17:16 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:17:16 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:17:45 --> brand/index called
INFO - 2016-06-20 13:17:45 --> store/index called
INFO - 2016-06-20 13:17:45 --> user/index called
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:17:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:17:45 --> company/index called
INFO - 2016-06-20 13:17:45 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:17:46 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-20 13:18:33 --> user/index called
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
INFO - 2016-06-20 13:18:33 --> store/index called
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:18:33 --> brand/index called
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:18:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:18:33 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:18:34 --> company/index called
INFO - 2016-06-20 13:18:34 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:19:41 --> company/index called
INFO - 2016-06-20 13:19:41 --> brand/index called
INFO - 2016-06-20 13:19:41 --> store/index called
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:19:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:19:41 --> user/index called
INFO - 2016-06-20 13:19:41 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:19:41 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:20:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:20:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:20:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:20:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:20:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:20:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:20:38 --> user/index called
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:20:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:20:44 --> brand/index called
INFO - 2016-06-20 13:20:44 --> company/index called
INFO - 2016-06-20 13:20:44 --> store/index called
INFO - 2016-06-20 13:20:44 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:20:44 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:21:08 --> user/index called
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:21:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:21:08 --> brand/index called
INFO - 2016-06-20 13:21:08 --> store/index called
INFO - 2016-06-20 13:21:08 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:21:08 --> company/index called
INFO - 2016-06-20 13:21:09 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:23:02 --> user/index called
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:23:02 --> store/index called
INFO - 2016-06-20 13:23:02 --> company/index called
INFO - 2016-06-20 13:23:02 --> brand/index called
INFO - 2016-06-20 13:23:02 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:23:02 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
INFO - 2016-06-20 13:23:20 --> company/index called
INFO - 2016-06-20 13:23:20 --> area/index called
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:23:20 --> brand/index called
INFO - 2016-06-20 13:23:20 --> store/index called
INFO - 2016-06-20 13:23:20 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:23:20 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [id] => 1
        )

)

DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:23:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:23:29 --> store/index called
INFO - 2016-06-20 13:23:29 --> brand/index called
INFO - 2016-06-20 13:23:29 --> company/index called
INFO - 2016-06-20 13:23:29 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:23:29 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:26:27 --> user/index called
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:26:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:26:27 --> company/index called
INFO - 2016-06-20 13:26:27 --> brand/index called
INFO - 2016-06-20 13:26:27 --> store/index called
INFO - 2016-06-20 13:26:27 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:26:27 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:30:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:30:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:30:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:30:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:30:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:30:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:30:39 --> user/index called
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:30:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:30:40 --> store/index called
INFO - 2016-06-20 13:30:40 --> brand/index called
INFO - 2016-06-20 13:30:40 --> company/index called
INFO - 2016-06-20 13:30:40 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:30:40 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:31:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:31:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:31:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:31:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:31:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:31:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:31:42 --> user/index called
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
INFO - 2016-06-20 13:31:43 --> store/index called
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
INFO - 2016-06-20 13:31:43 --> brand/index called
DEBUG - 2016-06-20 13:31:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:31:43 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:31:43 --> company/index called
INFO - 2016-06-20 13:31:43 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:33:06 --> user/index called
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:33:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:33:06 --> store/index called
INFO - 2016-06-20 13:33:06 --> brand/index called
INFO - 2016-06-20 13:33:06 --> company/index called
INFO - 2016-06-20 13:33:06 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:33:06 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:49:13 --> user/index called
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:49:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:49:13 --> company/index called
INFO - 2016-06-20 13:49:13 --> brand/index called
INFO - 2016-06-20 13:49:13 --> store/index called
INFO - 2016-06-20 13:49:13 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:49:13 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:49:34 --> user/index called
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:49:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:49:34 --> company/index called
INFO - 2016-06-20 13:49:34 --> brand/index called
INFO - 2016-06-20 13:49:34 --> store/index called
INFO - 2016-06-20 13:49:34 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:49:34 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:51:02 --> user/index called
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:51:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:51:02 --> brand/index called
INFO - 2016-06-20 13:51:02 --> company/index called
INFO - 2016-06-20 13:51:02 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:51:02 --> store/index called
INFO - 2016-06-20 13:51:02 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:53:27 --> user/index called
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 13:53:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 13:53:27 --> company/index called
INFO - 2016-06-20 13:53:27 --> store/index called
INFO - 2016-06-20 13:53:27 --> brand/index called
INFO - 2016-06-20 13:53:27 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 13:53:27 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 14:00:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:00:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:00:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:00:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:00:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:00:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:00:28 --> user/index called
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:00:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:00:34 --> section/index called
INFO - 2016-06-20 14:00:34 --> brand/index called
INFO - 2016-06-20 14:00:34 --> company/index called
INFO - 2016-06-20 14:00:34 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 14:00:34 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [id] => 1
        )

)

DEBUG - 2016-06-20 14:01:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:01:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:01:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:01:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:01:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:01:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:01:02 --> user/index called
INFO - 2016-06-20 14:01:02 --> Controller_Api->action_index(108) - exception 'Fuel\Core\Database_Exception' with message 'Unknown column 't0.company_id' in 'where clause' [ SELECT `t0`.`brand_id` AS `t0_c0`, `t0`.`section_id` AS `t0_c1`, `t0`.`store_code` AS `t0_c2`, `t0`.`store_name` AS `t0_c3`, `t0`.`store_status` AS `t0_c4`, `t0`.`store_prefectures` AS `t0_c5`, `t0`.`store_address` AS `t0_c6`, `t0`.`store_building` AS `t0_c7`, `t0`.`store_access` AS `t0_c8`, `t0`.`store_location` AS `t0_c9`, `t0`.`store_phone_no` AS `t0_c10`, `t0`.`store_fax_no` AS `t0_c11`, `t0`.`store_manager_name` AS `t0_c12`, `t0`.`store_business_hours_from` AS `t0_c13`, `t0`.`store_business_hours_to` AS `t0_c14`, `t0`.`store_regular_holiday` AS `t0_c15`, `t0`.`store_parking_lot` AS `t0_c16`, `t0`.`store_seat` AS `t0_c17`, `t0`.`store_kids_room` AS `t0_c18`, `t0`.`store_signature_block` AS `t0_c19`, `t0`.`store_terms_of_use` AS `t0_c20`, `t0`.`store_privacy_policy` AS `t0_c21`, `t0`.`store_freeword` AS `t0_c22`, `t0`.`store_area_L_id` AS `t0_c23`, `t0`.`store_area_M_id` AS `t0_c24`, `t0`.`store_area_S_id` AS `t0_c25`, `t0`.`store_sort_index` AS `t0_c26`, `t0`.`store_seo_key1` AS `t0_c27`, `t0`.`store_seo_key2` AS `t0_c28`, `t0`.`store_seo_key3` AS `t0_c29`, `t0`.`twitter_access_token` AS `t0_c30`, `t0`.`twitter_access_token_secret` AS `t0_c31`, `t0`.`facebook_id` AS `t0_c32`, `t0`.`store_first_open_date` AS `t0_c33`, `t0`.`created_at` AS `t0_c34`, `t0`.`updated_at` AS `t0_c35`, `t0`.`id` AS `t0_c36` FROM `stores` AS `t0` WHERE `t0`.`company_id` = 0 AND `t0`.`brand_id` = 0 AND `t0`.`section_id` = 0 AND `t0`.`id` = 0 LIMIT 1 ]' in /var/www/local.gmorepeater.jp/fuel/core/classes/database/mysqli/connection.php:292
Stack trace:
#0 /var/www/local.gmorepeater.jp/fuel/core/classes/database/query.php(314): Fuel\Core\Database_MySQLi_Connection->query(1, 'SELECT `t0`.`br...', false)
#1 /var/www/local.gmorepeater.jp/fuel/packages/orm/classes/query.php(1304): Fuel\Core\Database_Query->execute('master')
#2 /var/www/local.gmorepeater.jp/fuel/packages/orm/classes/query.php(1381): Orm\Query->get()
#3 /var/www/local.gmorepeater.jp/fuel/packages/orm/classes/belongsto.php(72): Orm\Query->get_one()
#4 /var/www/local.gmorepeater.jp/fuel/packages/orm/classes/model.php(1144): Orm\BelongsTo->get(Object(Model_User), Array)
#5 /var/www/local.gmorepeater.jp/fuel/packages/orm/classes/model.php(980): Orm\Model->get('store')
#6 /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/user.php(88): Orm\Model->__get('store')
#7 /var/www/local.gmorepeater.jp/fuel/app/classes/controller/api.php(91): Api\Controller_User->index()
#8 /var/www/local.gmorepeater.jp/fuel/core/base.php(461): Controller_Api->action_index()
#9 /var/www/local.gmorepeater.jp/fuel/core/classes/controller/rest.php(153): call_fuel_func_array(Array, Array)
#10 [internal function]: Fuel\Core\Controller_Rest->router('index', Array)
#11 /var/www/local.gmorepeater.jp/fuel/core/classes/request.php(454): ReflectionMethod->invokeArgs(Object(Api\Controller_User), Array)
#12 /var/www/local.gmorepeater.jp/public/index.php(71): Fuel\Core\Request->execute()
#13 /var/www/local.gmorepeater.jp/public/index.php(92): {closure}()
#14 {main}
DEBUG - 2016-06-20 14:01:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:01:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:01:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:01:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:01:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:01:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:01:13 --> store/index called
DEBUG - 2016-06-20 14:01:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:01:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:01:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:01:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:01:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:01:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:01:24 --> brand/index called
INFO - 2016-06-20 14:01:24 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 14:01:24 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:01:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:01:49 --> company/index called
INFO - 2016-06-20 14:01:49 --> section/index called
INFO - 2016-06-20 14:01:49 --> brand/index called
INFO - 2016-06-20 14:01:49 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 14:01:49 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [id] => 1
        )

)

DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:29:17 --> user/index called
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:29:17 --> brand/index called
INFO - 2016-06-20 14:29:17 --> store/index called
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:29:17 --> Api\Controller_Information->index(52) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-20 14:29:17 --> Api\Controller_Information->setParams(175) - 【INFORMATION API】:SET PARAM
INFO - 2016-06-20 14:29:17 --> company/index called
INFO - 2016-06-20 14:29:17 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-20 14:29:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 14:29:17 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 14:29:17 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 14:29:17 --> Api\Controller_Information->index(120) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-20 14:29:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:29:38 --> Api\Controller_Information->index(52) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-20 14:29:38 --> Api\Controller_Information->setParams(175) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-20 14:29:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 14:29:38 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 14:29:38 --> Api\Controller_Information->index(120) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:29:49 --> user/index called
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:29:49 --> company/index called
DEBUG - 2016-06-20 14:29:49 --> Api\Controller_Information->index(52) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-20 14:29:49 --> Api\Controller_Information->setParams(175) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:29:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:29:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 14:29:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 14:29:50 --> brand/index called
INFO - 2016-06-20 14:29:50 --> store/index called
INFO - 2016-06-20 14:29:50 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 14:29:50 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 14:29:50 --> Api\Controller_Information->index(120) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-20 14:30:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:30:21 --> user/index called
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:30:22 --> company/index called
DEBUG - 2016-06-20 14:30:22 --> Api\Controller_Information->index(52) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-20 14:30:22 --> Api\Controller_Information->setParams(175) - 【INFORMATION API】:SET PARAM
INFO - 2016-06-20 14:30:22 --> brand/index called
DEBUG - 2016-06-20 14:30:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 14:30:22 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:30:22 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 14:30:22 --> store/index called
INFO - 2016-06-20 14:30:22 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 14:30:22 --> Api\Controller_Information->index(120) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-20 14:30:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:42 --> Api\Controller_Information->index(52) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-20 14:30:42 --> Api\Controller_Information->setParams(175) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-20 14:30:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 14:30:42 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 14:30:42 --> Api\Controller_Information->index(120) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:30:46 --> store/index called
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
INFO - 2016-06-20 14:30:46 --> company/index called
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 14:30:46 --> area/index called
INFO - 2016-06-20 14:30:46 --> brand/index called
INFO - 2016-06-20 14:30:46 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 14:30:46 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [id] => 1
        )

)

DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
INFO - 2016-06-20 14:30:53 --> company/index called
DEBUG - 2016-06-20 14:30:53 --> Api\Controller_Information->index(52) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-20 14:30:53 --> Api\Controller_Information->setParams(175) - 【INFORMATION API】:SET PARAM
INFO - 2016-06-20 14:30:53 --> brand/index called
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:30:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 14:30:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:30:53 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 14:30:53 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 14:30:53 --> store/index called
INFO - 2016-06-20 14:30:54 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 14:30:54 --> Api\Controller_Information->index(120) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-20 14:31:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:31:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:31:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:31:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:31:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:31:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:31:51 --> Api\Controller_Information->index(52) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-20 14:31:51 --> Api\Controller_Information->setParams(175) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-20 14:31:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 14:31:51 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 14:31:51 --> Api\Controller_Information->index(120) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-20 14:32:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 14:32:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 14:32:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 14:32:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 14:32:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 14:32:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 14:32:27 --> Api\Controller_Information->index(52) - 【INFORMATION LIST API】:START
DEBUG - 2016-06-20 14:32:27 --> Api\Controller_Information->setParams(175) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-06-20 14:32:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 14:32:27 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 14:32:27 --> Api\Controller_Information->index(120) - 【INFORMATION LIST API】:END
DEBUG - 2016-06-20 15:50:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 15:50:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 15:50:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 15:50:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 15:50:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 15:50:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 15:50:54 --> user/index called
DEBUG - 2016-06-20 16:20:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 16:20:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 16:20:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 16:20:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 16:20:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 16:20:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 16:20:37 --> user/index called
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 16:20:51 --> user/index called
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
INFO - 2016-06-20 16:20:51 --> store/index called
INFO - 2016-06-20 16:20:51 --> brand/index called
INFO - 2016-06-20 16:20:51 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 16:20:51 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 16:20:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 16:20:51 --> company/index called
DEBUG - 2016-06-20 17:03:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:03:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:03:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:03:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:03:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:03:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:03:54 --> user/index called
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:04:30 --> user/index called
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:04:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:04:30 --> brand/index called
INFO - 2016-06-20 17:04:30 --> store/index called
INFO - 2016-06-20 17:04:30 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 17:04:30 --> company/index called
INFO - 2016-06-20 17:04:30 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 17:05:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:05:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:05:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:05:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:05:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:05:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:05:28 --> user/index called
DEBUG - 2016-06-20 17:06:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:06:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:06:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:06:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:06:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:06:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:06:12 --> user/index called
DEBUG - 2016-06-20 17:07:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:07:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:07:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:07:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:07:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:07:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:07:32 --> user/index called
DEBUG - 2016-06-20 17:08:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:08:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:08:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:08:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:08:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:08:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:08:43 --> user/index called
DEBUG - 2016-06-20 17:10:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:10:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:10:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:10:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:10:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:10:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:10:42 --> user/index called
DEBUG - 2016-06-20 17:13:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:13:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:13:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:13:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:13:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:13:58 --> user/index called
DEBUG - 2016-06-20 17:20:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:20:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:20:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:20:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:20:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:20:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:20:11 --> user/index called
DEBUG - 2016-06-20 17:20:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:20:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:20:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:20:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:20:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:20:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:20:58 --> user/index called
DEBUG - 2016-06-20 17:21:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:21:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:21:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:21:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:21:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:21:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:21:21 --> user/index called
DEBUG - 2016-06-20 17:23:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:23:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:23:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:23:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:23:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:23:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 17:23:11 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 17:23:11 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 17:23:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 17:23:11 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 17:23:11 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 17:23:11 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 17:23:11 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 17:25:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:25:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:25:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:25:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:25:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:25:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 17:25:25 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 17:25:25 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 17:25:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 17:25:25 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 17:25:25 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 17:25:25 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 17:25:25 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 17:25:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:25:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:25:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:25:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:25:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:25:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:25:42 --> user/index called
DEBUG - 2016-06-20 17:26:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:26:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:26:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:26:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:26:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:26:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:26:05 --> user/index called
DEBUG - 2016-06-20 17:27:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:27:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:27:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:27:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:27:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:27:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:27:05 --> user/index called
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:27:06 --> store/index called
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:27:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:27:06 --> company/index called
INFO - 2016-06-20 17:27:06 --> brand/index called
INFO - 2016-06-20 17:27:06 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 17:27:06 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 17:46:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:46:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:46:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:46:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:46:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:46:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:46:25 --> user/index called
DEBUG - 2016-06-20 17:46:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:46:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:46:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:46:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:46:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:46:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:46:33 --> user/index called
DEBUG - 2016-06-20 17:46:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:46:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:46:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:46:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:46:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:46:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:46:48 --> user/index called
DEBUG - 2016-06-20 17:47:19 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:47:19 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:47:19 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:47:19 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:47:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:47:19 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:47:19 --> user/index called
DEBUG - 2016-06-20 17:47:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:47:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:47:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:47:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:47:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:47:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:47:25 --> user/index called
DEBUG - 2016-06-20 17:47:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:47:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:47:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:47:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:47:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:47:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:47:28 --> user/index called
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 17:47:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 17:47:32 --> brand/index called
INFO - 2016-06-20 17:47:32 --> store/index called
INFO - 2016-06-20 17:47:32 --> company/index called
INFO - 2016-06-20 17:47:32 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 17:47:32 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:01:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:01:28 --> user/index called
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:01:39 --> company/index called
INFO - 2016-06-20 18:01:39 --> brand/index called
INFO - 2016-06-20 18:01:39 --> store/index called
INFO - 2016-06-20 18:01:39 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 18:01:39 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:01:42 --> user/index called
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:01:42 --> brand/index called
INFO - 2016-06-20 18:01:42 --> company/index called
INFO - 2016-06-20 18:01:42 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 18:01:42 --> store/index called
INFO - 2016-06-20 18:01:42 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:01:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:01:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:01:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:01:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:01:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:01:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:01:59 --> user/index called
DEBUG - 2016-06-20 18:03:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:03:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:03:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:03:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:03:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:03:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:03:38 --> user/index called
DEBUG - 2016-06-20 18:04:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:04:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:04:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:04:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:04:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:04:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:04:10 --> user/index called
DEBUG - 2016-06-20 18:05:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:05:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:05:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:05:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:05:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:05:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:05:32 --> user/index called
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:05:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:05:33 --> company/index called
DEBUG - 2016-06-20 18:05:33 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:05:33 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
INFO - 2016-06-20 18:05:33 --> store/index called
INFO - 2016-06-20 18:05:33 --> brand/index called
DEBUG - 2016-06-20 18:05:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:05:33 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 18:05:33 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 18:05:33 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:05:33 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:05:33 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:05:33 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:07:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:07:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:07:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:07:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:07:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:07:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:07:28 --> user/index called
DEBUG - 2016-06-20 18:07:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:07:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:07:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:07:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:07:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:07:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:07:32 --> user/index called
DEBUG - 2016-06-20 18:18:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:18:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:18:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:18:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:18:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:18:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:18:28 --> user/index called
DEBUG - 2016-06-20 18:18:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:18:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:18:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:18:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:18:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:18:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:18:46 --> user/index called
DEBUG - 2016-06-20 18:20:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:20:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:20:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:20:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:20:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:20:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:20:04 --> user/index called
DEBUG - 2016-06-20 18:24:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:24:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:24:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:24:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:24:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:24:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:24:29 --> user/index called
DEBUG - 2016-06-20 18:24:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:24:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:24:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:24:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:24:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:24:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:24:33 --> user/index called
DEBUG - 2016-06-20 18:26:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:26:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:26:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:26:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:26:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:26:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:26:54 --> user/index called
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:27:16 --> user/index called
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:27:16 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:27:16 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:27:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:27:16 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 18:27:16 --> brand/index called
INFO - 2016-06-20 18:27:16 --> company/index called
INFO - 2016-06-20 18:27:16 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:27:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:27:16 --> store/index called
INFO - 2016-06-20 18:27:17 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:27:17 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:27:17 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:27:17 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:28:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:28:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:28:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:28:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:28:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:28:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:28:22 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:28:22 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:28:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:28:22 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:28:22 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:28:22 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:28:22 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:28:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:28:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:28:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:28:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:28:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:28:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:28:23 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:28:23 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:28:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:28:23 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:28:23 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:28:23 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:28:23 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:30:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:30:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:30:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:30:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:30:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:30:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:30:44 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:30:44 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:30:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:30:44 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:30:44 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:30:44 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:30:44 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:30:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:30:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:30:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:30:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:30:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:30:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:30:46 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:30:46 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:30:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:30:46 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:30:46 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:30:46 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:30:46 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:35:42 --> user/index called
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:35:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:35:42 --> user/index called
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:35:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:35:58 --> store/index called
INFO - 2016-06-20 18:35:58 --> company/index called
INFO - 2016-06-20 18:35:58 --> brand/index called
DEBUG - 2016-06-20 18:35:58 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:35:58 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:35:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:35:58 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 18:35:58 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 18:35:58 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:35:58 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:35:58 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:35:58 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:37:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:37:41 --> store/index called
INFO - 2016-06-20 18:37:41 --> company/index called
INFO - 2016-06-20 18:37:41 --> brand/index called
INFO - 2016-06-20 18:37:41 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 18:37:41 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:40:12 --> brand/index called
INFO - 2016-06-20 18:40:12 --> store/index called
INFO - 2016-06-20 18:40:12 --> company/index called
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:40:12 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-20 18:40:12 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:12 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:12 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 18:40:12 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:40:12 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:12 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:12 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:40:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:33 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:33 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:33 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:40:33 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:33 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:33 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:40:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:34 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:34 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:34 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:40:34 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:34 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:34 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:40:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:45 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:45 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:45 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:40:45 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:45 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:45 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:40:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:50 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:50 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:40:50 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:50 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:50 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:51 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:51 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:51 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:52 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:40:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:40:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:40:52 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:40:52 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:41:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:41:09 --> brand/index called
INFO - 2016-06-20 18:41:09 --> company/index called
INFO - 2016-06-20 18:41:09 --> store/index called
INFO - 2016-06-20 18:41:09 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 18:41:09 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:44:30 --> user/index called
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:44:30 --> store/index called
INFO - 2016-06-20 18:44:30 --> company/index called
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:44:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:44:30 --> brand/index called
INFO - 2016-06-20 18:44:30 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 18:44:30 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:44:35 --> company/index called
INFO - 2016-06-20 18:44:35 --> brand/index called
DEBUG - 2016-06-20 18:44:35 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:44:35 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:44:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:44:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 18:44:35 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:44:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:44:35 --> store/index called
DEBUG - 2016-06-20 18:44:35 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
INFO - 2016-06-20 18:44:35 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:44:35 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:44:35 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:46:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:46:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:46:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:46:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:46:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:46:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:46:41 --> user/index called
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:46:42 --> store/index called
INFO - 2016-06-20 18:46:42 --> brand/index called
INFO - 2016-06-20 18:46:42 --> company/index called
INFO - 2016-06-20 18:46:42 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:46:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:46:42 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 18:46:42 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 18:46:42 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 18:46:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 18:46:42 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 18:46:42 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 18:46:42 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 18:46:42 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 18:46:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 18:46:54 --> company/index called
INFO - 2016-06-20 18:46:54 --> brand/index called
INFO - 2016-06-20 18:46:54 --> store/index called
INFO - 2016-06-20 18:46:54 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 18:46:54 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:05:42 --> user/index called
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:05:42 --> company/index called
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:05:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:05:42 --> store/index called
INFO - 2016-06-20 19:05:42 --> brand/index called
INFO - 2016-06-20 19:05:42 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 19:05:42 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:06:48 --> user/index called
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:06:48 --> brand/index called
INFO - 2016-06-20 19:06:48 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 19:06:48 --> store/index called
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:06:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:06:48 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

INFO - 2016-06-20 19:06:48 --> company/index called
DEBUG - 2016-06-20 19:07:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:07:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:07:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:07:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:07:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:07:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:07:34 --> user/index called
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:07:56 --> user/index called
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:07:56 --> store/index called
INFO - 2016-06-20 19:07:56 --> brand/index called
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:07:56 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:07:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:07:56 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 19:07:56 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
INFO - 2016-06-20 19:07:56 --> company/index called
DEBUG - 2016-06-20 19:07:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 19:07:56 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-20 19:07:56 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 19:07:56 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 19:07:56 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
DEBUG - 2016-06-20 19:07:56 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:08:43 --> user/index called
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:08:43 --> company/index called
DEBUG - 2016-06-20 19:08:43 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 19:08:43 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
DEBUG - 2016-06-20 19:08:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 19:08:43 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:08:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:08:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:08:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:08:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:08:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:08:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:08:44 --> store/index called
DEBUG - 2016-06-20 19:08:44 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 19:08:44 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
INFO - 2016-06-20 19:08:44 --> brand/index called
DEBUG - 2016-06-20 19:08:44 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
INFO - 2016-06-20 19:08:44 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-20 19:08:44 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:43:48 --> user/index called
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:43:48 --> Api\Controller_Questionnaire->index(32) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-06-20 19:43:48 --> Api\Controller_Questionnaire->setParams(134) - 【QUESTIONNAIRE API】:SET PARAM
INFO - 2016-06-20 19:43:48 --> company/index called
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-20 19:43:48 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-20 19:43:48 --> brand/index called
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-20 19:43:48 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-20 19:43:48 --> Api\Controller_Questionnaire->index(65) - 【QUESTIONNAIRE LIST API】:GET LIST
DEBUG - 2016-06-20 19:43:48 --> Api\Controller_Questionnaire->index(68) - 【QUESTIONNAIRE LIST API】:SET RESULT
INFO - 2016-06-20 19:43:48 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-20 19:43:48 --> Api\Controller_Questionnaire->index(70) - 【QUESTIONNAIRE LIST API】:END
INFO - 2016-06-20 19:43:48 --> store/index called
INFO - 2016-06-20 19:43:48 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

