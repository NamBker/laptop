<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-08-02 10:38:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:38:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 10:38:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 10:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:38:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:38:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:51:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:51:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:51:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:55:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 10:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 10:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:01:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:04:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:05:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:05:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:05:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:06:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:07:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:07:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:07:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:07:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:08:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:09:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:09:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:09:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:19:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:19:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:20:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:21:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:21:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:21:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:21:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:21:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:21:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:22:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:22:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:22:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:22:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:22:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:22:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:23:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:23:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:23:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:23:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:23:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:23:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:26:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:26:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:26:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:26:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:26:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:27:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:27:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:27:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:28:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 11:28:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:28:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 11:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:29:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 11:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-02 11:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:29:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:29:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:29:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:29:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 11:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 11:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/4"
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 11:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 11:55:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-08-02 12:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/random/coupons"
INFO - 2016-08-02 12:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:18:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-02 12:18:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-02 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:18:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:18:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:18:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:19:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:19:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:19:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:19:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/5"
INFO - 2016-08-02 12:19:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:19:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/4"
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:19:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:19:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:19:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:19:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:20:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:21:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/random/coupons"
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-02 12:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-02 12:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/random/coupons"
INFO - 2016-08-02 12:21:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:21:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:21:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-02 12:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:22:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:35:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:35:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:35:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:35:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:35:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:35:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:35:56 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2016-08-02 12:35:56 --> Error: Session cookie with ID "df1b8bb8254a6353bbd90484c7ba330b" present but corresponding record is missing
INFO - 2016-08-02 12:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 12:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 12:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:37:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:37:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:38:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:38:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:39:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:39:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:39:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:39:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 12:39:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:39:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:40:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:40:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:40:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-02 12:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-08-02 12:42:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-08-02 12:42:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-08-02 12:42:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-08-02 12:42:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-08-02 12:42:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-08-02 12:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/analysis"
INFO - 2016-08-02 12:42:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-08-02 12:42:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-08-02 12:42:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/pictures"
INFO - 2016-08-02 12:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-08-02 12:42:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-08-02 12:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:42:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/pictures"
INFO - 2016-08-02 12:42:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:42:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:43:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/members"
INFO - 2016-08-02 12:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:45:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:45:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:45:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:49:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:49:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:49:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 12:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 12:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 13:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:11:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 13:11:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:11:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:11:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:11:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:11:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:11:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:16:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:16:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:16:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:16:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:17:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:17:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:17:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:23:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:23:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:23:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:23:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:23:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:25:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:26:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:26:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:26:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:27:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:27:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:27:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:30:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:30:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:31:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:31:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:31:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:34:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:34:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:34:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:42:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:42:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:42:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:43:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:43:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:43:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:43:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:43:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:43:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:43:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:46:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:46:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:46:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:46:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 13:46:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:46:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:47:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:47:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 13:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 13:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:48:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-02 13:48:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:48:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-02 13:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:48:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-08-02 13:48:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:48:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 13:49:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:49:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:49:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:49:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 13:49:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 13:49:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 13:49:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 15:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 15:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 15:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 15:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 15:52:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 15:52:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:52:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:52:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:52:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 15:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 15:53:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 15:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:57:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 15:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 15:57:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 15:57:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 15:57:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:03:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:03:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:11:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:11:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:11:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:17:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:17:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:17:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:17:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:17:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:19:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:19:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:19:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:19:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:19:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:19:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:19:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:22:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:22:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:22:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:22:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:24:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:24:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:24:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:24:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:24:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:25:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:25:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:28:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:28:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:28:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:28:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:28:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:28:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:29:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:29:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:29:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:29:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:32:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:32:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:32:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:32:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:35:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:35:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:35:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 16:38:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 16:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:38:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:38:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:38:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:38:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:39:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:39:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:39:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:41:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:41:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:41:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 16:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 16:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:49:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:49:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:49:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:49:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:49:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:49:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:49:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:49:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:49:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:49:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:49:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:49:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:49:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:49:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:49:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:50:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:50:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:50:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:50:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 16:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 16:53:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 16:55:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 16:55:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 16:55:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:55:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 16:55:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:55:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 16:58:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 16:58:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 16:58:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:00:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:00:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:00:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 17:00:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:00:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 17:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:01:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 17:01:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:01:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:05:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:05:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:05:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 17:06:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:06:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:06:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 17:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 17:06:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:07:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:07:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:07:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:08:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/7"
INFO - 2016-08-02 17:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:09:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:09:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:09:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:09:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:09:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 17:09:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:09:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:10:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:10:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:10:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:11:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 17:11:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:11:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:12:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:12:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:12:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-08-02 17:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 17:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 17:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:15:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:15:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:22:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:22:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:22:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:40:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:49:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:49:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:51:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:51:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:51:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:51:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-08-02 17:51:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/random/coupons"
INFO - 2016-08-02 17:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:52:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:53:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:56:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:56:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:56:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:56:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:56:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:56:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:57:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 17:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 17:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 17:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 17:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 17:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:00:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:03:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:03:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:04:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 18:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 18:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-08-02 18:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:06:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:10:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 18:14:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 18:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 18:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 18:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 18:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:01:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:02:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:02:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:04:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:07:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:22:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:22:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:22:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:22:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:23:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:23:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:23:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:23:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:23:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:25:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:27:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:27:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:27:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:27:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:27:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:29:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:30:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:30:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:30:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:30:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:34:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:35:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:37:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:38:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:38:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:39:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:44:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:45:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 19:45:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:45:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:45:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-08-02 19:45:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:45:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:45:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:46:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:50:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:52:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:53:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:56:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:57:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-08-02 19:57:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:57:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:57:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-08-02 19:57:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:57:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:57:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:57:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:57:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:58:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:58:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:58:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:59:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 19:59:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 19:59:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 20:00:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 20:08:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 20:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 20:09:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:09:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/8"
INFO - 2016-08-02 20:09:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:09:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:09:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:09:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-08-02 20:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:11:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:11:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:11:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-08-02 20:11:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-08-02 20:11:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-02 20:11:44 --> Fuel\Core\Request::execute - Setting main Request
