<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-05 10:37:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-05 10:37:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:37:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-05 10:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:38:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:40:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:40:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:40:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:40:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:40:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:41:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:41:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:41:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:50:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:50:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:50:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:54:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:54:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:54:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:55:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:56:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:56:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:59:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 10:59:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:59:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 10:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:03:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:03:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:05:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:08:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:08:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:08:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:08:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:10:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:10:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:10:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:22:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:22:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:25:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:26:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:26:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:26:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:27:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:27:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:27:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:28:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:29:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:29:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:29:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:30:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:30:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:32:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:32:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:32:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:32:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:32:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:32:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:33:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:33:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:33:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:33:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:33:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:33:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:33:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:33:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:33:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:33:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:34:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:34:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:34:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:37:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:37:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:37:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:37:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:39:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:39:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:39:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:39:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:40:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:40:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 11:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:46:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 11:46:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:46:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 11:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 11:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 11:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:06:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:09:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:09:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:09:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:23:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:23:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:23:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:24:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:24:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:24:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:24:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:24:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:24:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:25:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:25:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:25:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:25:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:25:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:25:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:26:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:26:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:26:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:27:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:27:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:27:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:29:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:29:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:29:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:29:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:29:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:29:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:29:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:29:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:29:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:29:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:34:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:34:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:35:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:35:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:35:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:36:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:36:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:36:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:36:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:37:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:37:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:37:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:40:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:40:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:40:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:41:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:41:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:41:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:41:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:45:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:45:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:45:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:49:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:49:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:49:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:51:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:51:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:51:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:51:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:51:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:51:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:52:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:52:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:52:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:53:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:53:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:53:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:55:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:55:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:55:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:55:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:55:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:55:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:57:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 12:57:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:57:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 12:57:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 12:57:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 12:57:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:08:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:08:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:08:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:18:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:19:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:20:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:20:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:20:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:22:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:22:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:22:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:22:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:23:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:23:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:23:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:23:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:23:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:23:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:23:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:23:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:23:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:23:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:24:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:24:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:24:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:24:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:24:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:29:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:29:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:29:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:29:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:29:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:29:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:30:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:30:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:30:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:31:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:31:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:31:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:31:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:31:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:31:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:47:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:47:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:47:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:47:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:47:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:47:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:48:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:52:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:52:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:52:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:55:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:55:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:55:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:55:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:57:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:57:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:57:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:57:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:57:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:57:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:57:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 13:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 13:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 13:59:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 13:59:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 13:59:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:00:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 14:00:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:00:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:00:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 14:00:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:00:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 14:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:00:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 14:00:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:00:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 14:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 14:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:50:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 15:50:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:50:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 15:50:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:50:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 15:56:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 15:56:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 15:56:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 15:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:02:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:02:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:02:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:02:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:03:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:09:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:09:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:09:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:10:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:15:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:15:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:15:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:18:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:18:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:18:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:19:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:19:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:19:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:22:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:25:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:28:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:28:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:29:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:29:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:29:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:30:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:32:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:34:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:34:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:34:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:34:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:34:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:34:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:34:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:34:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:34:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:35:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:35:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:35:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:35:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:35:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:35:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:37:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:37:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:37:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:45:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:45:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:45:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:45:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:45:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:45:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:45:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:55:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:55:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:56:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:56:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:56:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:56:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:56:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:56:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:56:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:56:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:56:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:56:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:56:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:56:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:56:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:56:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:56:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:56:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:56:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:57:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:57:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:57:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 16:57:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:58:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:58:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 16:58:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:58:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 16:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 16:58:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 16:58:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:07:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:07:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:12:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:12:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:12:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:12:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:12:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:12:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:13:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:13:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:13:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:14:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:14:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:16:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:16:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:16:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:26:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:26:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:26:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:27:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:27:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:27:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:32:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:32:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:33:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:33:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:39:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:39:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:39:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:52:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:52:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-05 17:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:57:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:59:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 17:59:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:59:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 17:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:14:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:18:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:18:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:18:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:24:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:24:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:26:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:26:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:26:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:26:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:26:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:28:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:28:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:28:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:28:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:28:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:28:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:30:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:30:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:30:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:36:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:36:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:36:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:37:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:37:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:37:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:37:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:38:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:38:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:40:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:40:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:40:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:41:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:41:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:45:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:45:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:45:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:47:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:47:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:47:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:48:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:48:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:48:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:50:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:50:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:50:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:51:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:51:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:51:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:52:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:52:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:53:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:53:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:53:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:54:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 18:54:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:54:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 18:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:11:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:11:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:11:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:14:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:16:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:21:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:21:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:21:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:25:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:25:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:26:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:26:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:26:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:33:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:33:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:33:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:33:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:33:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:33:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:33:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:36:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:36:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:47:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:47:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:49:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:49:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:51:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:53:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:54:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:54:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:57:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:57:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:57:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:57:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:58:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:59:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/monthlystore"
INFO - 2016-07-05 19:59:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:59:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:59:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 19:59:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 19:59:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 19:59:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 19:59:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 19:59:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 19:59:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 19:59:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:00:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:00:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:00:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:00:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:00:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:00:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:00:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:00:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:00:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:02:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 20:02:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:02:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-05 20:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:10:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:10:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:10:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:12:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:12:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:12:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-05 20:13:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/dailystore"
INFO - 2016-07-05 20:13:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-05 20:13:02 --> Fuel\Core\Request::execute - Setting main Request
