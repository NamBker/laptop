<?php
echo $search;
echo $table;
?>