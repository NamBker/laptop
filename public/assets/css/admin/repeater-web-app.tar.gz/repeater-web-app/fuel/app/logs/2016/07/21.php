<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-21 10:35:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:35:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:35:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-21 10:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-21 10:36:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:36:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:36:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:36:08 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-21 10:48:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 10:48:57 --> Migrate class initialized
INFO - 2016-07-21 10:48:57 --> Migrating to version: 35
INFO - 2016-07-21 10:48:57 --> Migrated to 35 successfully.
INFO - 2016-07-21 10:50:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:50:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:53:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:53:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:56:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:56:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:57:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:57:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:57:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:59:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:59:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:59:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 10:59:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 10:59:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 10:59:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 10:59:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:01:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:01:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:01:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:07:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:09:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:09:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:09:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:16:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:16:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:16:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:16:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/100/store/0"
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/100"
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:18:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/100/store/0"
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/100"
INFO - 2016-07-21 11:18:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:18:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:18:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/2"
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:19:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/undefined"
INFO - 2016-07-21 11:19:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:19:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:19:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-21 11:19:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:19:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:20:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:20:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:20:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/2"
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:21:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 11:21:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:21:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:28:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 11:28:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:28:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:29:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:29:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:29:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:29:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:29:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 11:29:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:29:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:29:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/2"
INFO - 2016-07-21 11:29:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:29:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:31:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:31:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:31:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:31:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:31:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:31:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:31:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:31:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:31:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:31:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:31:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:31:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:31:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:31:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:31:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:31:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:31:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:31:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:31:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:31:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:31:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:31:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:31:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:31:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:36:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:36:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:36:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:36:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:41:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:42:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:42:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:42:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:45:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:45:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:45:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:45:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:45:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:52:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 11:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 11:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:03:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:03:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:04:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:04:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:04:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:10:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:10:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:10:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:10:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:12:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:12:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:12:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:12:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:12:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:12:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:12:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:12:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:12:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:12:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:12:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:12:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:13:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:13:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:13:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:23:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:23:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:23:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/3/store/0"
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/3"
INFO - 2016-07-21 12:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:25:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/2"
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 12:25:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 12:25:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 12:25:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 12:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/2"
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 12:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/2"
INFO - 2016-07-21 12:26:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:26:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:26:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:26:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:27:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:28:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:28:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:28:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:28:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:34:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:40:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:40:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:40:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:40:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:40:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:41:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/100/store/0"
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/100"
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:54:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:54:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:54:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:54:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:54:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:54:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:54:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:55:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:55:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/0"
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/2"
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:56:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 12:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 12:57:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 12:57:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 12:57:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:20:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:20:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:20:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:22:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:22:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:22:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:23:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:23:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:23:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/3/store/0"
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/3"
INFO - 2016-07-21 13:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/3/store/0"
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/3"
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:30:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:30:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:30:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:30:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:30:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:32:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:33:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:33:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:33:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:33:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:33:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-21 13:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:34:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:42:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:42:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:43:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:43:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:43:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:49:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:49:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:49:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:49:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:52:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:54:05 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-21 13:55:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:11 --> Migrate class initialized
WARNING - 2016-07-21 13:55:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:30 --> Migrate class initialized
INFO - 2016-07-21 13:55:30 --> Migrating to version: 35
INFO - 2016-07-21 13:55:30 --> Migrated to 35 successfully.
WARNING - 2016-07-21 13:55:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:31 --> Migrate class initialized
INFO - 2016-07-21 13:55:31 --> Migrating to version: 34
INFO - 2016-07-21 13:55:32 --> Migrated to 34 successfully.
WARNING - 2016-07-21 13:55:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:32 --> Migrate class initialized
INFO - 2016-07-21 13:55:32 --> Migrating to version: 33
INFO - 2016-07-21 13:55:32 --> Migrated to 33 successfully.
WARNING - 2016-07-21 13:55:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:33 --> Migrate class initialized
INFO - 2016-07-21 13:55:33 --> Migrating to version: 32
INFO - 2016-07-21 13:55:33 --> Migrated to 32 successfully.
WARNING - 2016-07-21 13:55:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:34 --> Migrate class initialized
INFO - 2016-07-21 13:55:34 --> Migrating to version: 31
INFO - 2016-07-21 13:55:34 --> Migrated to 31 successfully.
WARNING - 2016-07-21 13:55:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:39 --> Migrate class initialized
INFO - 2016-07-21 13:55:39 --> Migrating to version: 0
INFO - 2016-07-21 13:55:39 --> Migrated to 0 successfully.
WARNING - 2016-07-21 13:55:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:41 --> Migrate class initialized
INFO - 2016-07-21 13:55:41 --> Migrating to version: 0
INFO - 2016-07-21 13:55:41 --> Migrated to 0 successfully.
WARNING - 2016-07-21 13:55:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:41 --> Migrate class initialized
INFO - 2016-07-21 13:55:41 --> Migrating to version: 0
INFO - 2016-07-21 13:55:41 --> Migrated to 0 successfully.
WARNING - 2016-07-21 13:55:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:42 --> Migrate class initialized
INFO - 2016-07-21 13:55:42 --> Migrating to version: 0
INFO - 2016-07-21 13:55:42 --> Migrated to 0 successfully.
WARNING - 2016-07-21 13:55:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:42 --> Migrate class initialized
INFO - 2016-07-21 13:55:42 --> Migrating to version: 0
INFO - 2016-07-21 13:55:42 --> Migrated to 0 successfully.
WARNING - 2016-07-21 13:55:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-21 13:55:47 --> Migrate class initialized
INFO - 2016-07-21 13:56:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:56:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:56:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:56:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:56:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:56:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:56:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:58:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:58:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:58:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:58:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 13:59:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 13:59:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 13:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 13:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 13:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 14:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 14:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 14:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 14:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:33:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 15:33:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:33:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 15:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:33:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 15:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:33:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 15:37:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:37:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 15:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 15:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 15:38:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-21 15:38:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-21 15:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 15:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 15:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 15:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 15:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 15:39:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/4/store/0"
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/4"
INFO - 2016-07-21 15:39:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 15:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:39:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:44:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 15:44:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:44:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 15:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:06:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:06:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:07:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:07:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:07:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:07:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:08:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:08:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:08:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:08:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:11:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:11:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:11:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:13:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:13:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:13:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:13:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:13:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:13:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:15:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:15:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:15:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:23:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:23:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:23:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:23:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:23:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:23:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:23:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:23:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:23:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:24:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:26:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:27:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:27:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:43:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:44:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:44:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:44:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:45:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:45:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:45:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:45:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:45:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:46:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:47:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:49:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:49:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:49:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:50:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:50:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:50:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:51:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:51:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:51:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:51:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:52:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:52:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:52:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:52:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:52:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:52:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:53:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:54:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:54:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:54:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:54:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:54:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:54:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:54:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:55:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:55:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:55:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:55:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:55:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:55:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:55:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:55:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:55:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 16:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 16:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:56:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 16:56:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 16:56:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:03:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:04:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:04:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:04:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:04:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:05:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:06:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:06:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:06:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:09:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:09:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:09:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:12:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:13:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:13:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:13:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:14:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:14:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:14:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:15:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:15:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:17:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 17:18:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 17:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 17:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 17:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 17:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-21 19:35:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-21 19:35:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-21 19:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-21 19:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-21 19:35:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-21 19:35:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:35:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:35:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-21 19:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-21 19:36:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:36:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-07-21 19:36:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-07-21 19:36:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-21 19:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:36:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-07-21 19:36:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 19:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 19:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:40:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:40:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 19:40:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:40:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:42:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 19:42:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:42:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:42:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 19:42:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:42:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:43:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:48:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-21 19:48:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:48:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-21 19:48:36 --> Fuel\Core\Request::execute - Setting main Request
