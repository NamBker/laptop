<center><img src="<?php echo \Model_Picture::getMbPictureUrl($header_footer->sitemap_picture_id) ?>" style="margin-top:10px;max-width:80%;" /></center>
