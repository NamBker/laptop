<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-15 12:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 12:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 12:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 12:52:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1"
INFO - 2016-07-15 13:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-15 13:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:02:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:02:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:02:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:03:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:03:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:03:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:05:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:05:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:05:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:07:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:07:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:07:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:07:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:07:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:07:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:08:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:08:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:08:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:08:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:08:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:08:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:08:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:08:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:08:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:08:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:11:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:11:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:11:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:12:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:12:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:14:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:14:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:14:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:21:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:21:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:21:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:24:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:24:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:25:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:25:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:25:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:25:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:29:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:29:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:34:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:34:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:34:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:38:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:38:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:38:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:38:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:41:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:43:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:44:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:44:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:44:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:45:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:58:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 13:58:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:58:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 13:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:35:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:35:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:35:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:37:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:40:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:40:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:40:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:42:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:43:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:43:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:43:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:43:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:43:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:43:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:44:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:45:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:45:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:46:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:46:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:46:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:46:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:46:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:46:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:46:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:52:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:53:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:53:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:53:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:58:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 14:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 14:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:01:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 15:01:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:01:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 15:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 15:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 15:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:12:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/icon-garbage-ov"
INFO - 2016-07-15 15:12:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:12:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:12:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-15 15:12:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:12:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:12:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 15:12:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:12:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 15:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:13:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 15:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:25:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:57:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 15:57:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:57:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 15:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 15:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 15:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:03:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:03:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:03:11 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-15 16:04:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-07-15 16:04:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-15 16:04:59 --> Migrate class initialized
INFO - 2016-07-15 16:04:59 --> Migrating to version: 32
INFO - 2016-07-15 16:05:00 --> Migrating to version: 33
INFO - 2016-07-15 16:05:00 --> Migrated to 33 successfully.
WARNING - 2016-07-15 16:05:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-15 16:05:10 --> Migrate class initialized
INFO - 2016-07-15 16:05:10 --> Migrating to version: 33
INFO - 2016-07-15 16:05:10 --> Migrated to 33 successfully.
WARNING - 2016-07-15 16:05:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-15 16:05:12 --> Migrate class initialized
INFO - 2016-07-15 16:05:12 --> Migrating to version: 32
INFO - 2016-07-15 16:05:12 --> Migrated to 32 successfully.
WARNING - 2016-07-15 16:05:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-15 16:05:14 --> Migrate class initialized
INFO - 2016-07-15 16:05:14 --> Migrating to version: 31
INFO - 2016-07-15 16:05:14 --> Migrated to 31 successfully.
WARNING - 2016-07-15 16:05:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-15 16:05:18 --> Migrate class initialized
INFO - 2016-07-15 16:05:18 --> Migrating to version: 0
INFO - 2016-07-15 16:05:18 --> Migrated to 0 successfully.
WARNING - 2016-07-15 16:05:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-15 16:05:19 --> Migrate class initialized
INFO - 2016-07-15 16:05:19 --> Migrating to version: 0
INFO - 2016-07-15 16:05:20 --> Migrated to 0 successfully.
WARNING - 2016-07-15 16:05:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-15 16:05:21 --> Migrate class initialized
INFO - 2016-07-15 16:05:21 --> Migrating to version: 0
INFO - 2016-07-15 16:05:21 --> Migrated to 0 successfully.
WARNING - 2016-07-15 16:05:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-15 16:05:23 --> Migrate class initialized
INFO - 2016-07-15 16:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:06:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:06:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:06:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:16:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:16:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:16:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:18:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:18:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:19:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:19:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:19:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:19:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:19:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:19:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:22:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:22:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:22:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:22:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:22:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:22:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:23:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:23:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:23:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:24:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:24:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:24:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/2/site"
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-15 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-07-15 16:24:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-07-15 16:24:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-15 16:24:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-07-15 16:24:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/deliveries"
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/delivery/count"
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questions"
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-07-15 16:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-07-15 16:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/headers/footer"
INFO - 2016-07-15 16:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-07-15 16:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:25:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:25:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:25:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:32:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:32:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:32:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:45:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1"
INFO - 2016-07-15 16:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/2"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/2/site"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:57:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:58:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 16:58:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:58:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 16:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:19:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:19:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:19:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:20:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:20:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:20:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:25:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:25:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:25:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:27:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:27:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:27:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:28:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:28:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:28:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:45:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:45:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:45:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:49:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:49:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:49:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:54:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:54:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:54:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 17:57:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 17:57:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 17:57:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:07:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:12:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:12:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:16:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:16:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:16:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:17:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:17:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:17:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:19:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:19:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:19:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:19:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:19:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:19:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:20:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:20:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:20:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:20:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:20:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:20:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:20:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 18:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 18:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:10:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:10:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:10:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:10:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:10:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:10:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:10:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:12:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:12:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:13:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:13:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:13:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:13:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:14:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:15:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:15:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:15:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:15:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:15:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:15:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:16:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:16:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:17:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:17:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:17:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:20:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:20:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:20:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:20:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:21:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:21:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:21:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:21:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:21:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:21:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:21:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:21:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:21:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:25:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:25:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:25:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:25:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:25:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:26:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:26:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:26:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:29:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:29:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:29:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:29:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:29:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:30:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:39:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:39:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:40:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:40:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:40:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:40:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:40:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:41:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:44:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:44:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:47:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:47:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:47:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:48:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:48:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:48:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:48:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:48:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:48:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:49:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:49:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:49:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:52:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:52:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:53:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:53:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:53:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:53:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:53:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:54:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:54:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:55:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:55:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:55:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:56:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 19:56:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:56:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 19:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:02:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:02:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:03:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:03:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:03:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:03:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:04:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:04:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:04:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:12:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:12:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:14:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:14:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:14:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:18:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:18:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:18:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:18:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:18:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:19:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:19:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:19:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:20:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-15 20:20:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:20:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/1/site"
INFO - 2016-07-15 20:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:20:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-15 20:20:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-15 20:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-15 20:20:29 --> Fuel\Core\Request::execute - Setting main Request
