<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-20 10:37:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:37:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:37:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-20 10:37:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-20 10:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:42:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 10:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:46:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:56:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:58:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 10:58:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 11:00:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 11:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 11:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:05:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:05:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:05:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:07:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:07:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:08:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:09:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:13:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:17:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:17:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:17:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:18:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store//site"
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store"
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:18:27 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-20 12:23:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
DEBUG - 2016-07-20 12:23:30 --> Migrate class initialized
INFO - 2016-07-20 12:23:30 --> Migrating to version: 34
INFO - 2016-07-20 12:23:30 --> Migrated to 34 successfully.
INFO - 2016-07-20 12:24:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:24:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:24:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:24:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:31:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/store"
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:31:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:32:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/store"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/store"
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 12:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 14:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 14:34:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 14:34:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 14:34:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 14:34:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 14:34:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-20 15:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-20 15:37:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:37:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/store"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:37:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:39:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/store"
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-20 15:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/store"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:43:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/store"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 15:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 15:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:07:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 16:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:09:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:14:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:14:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:14:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 16:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:02:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-20 17:02:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:02:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:02:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:02:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:02:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:02:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/detail/brand/undefined/store/undefined"
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:22:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:22:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:28:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:28:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:30:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:33:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:33:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:33:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 17:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:01:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:01:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:01:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:01:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:01:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:01:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:01:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:02:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:05:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/0/store/0"
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:07:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information/1"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:11:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:11:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:11:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:13:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:13:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:16:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:16:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:21:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:21:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:21:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:21:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:22:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:23:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:23:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:26:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:26:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:26:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:26:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:26:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:28:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:28:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:28:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:28:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:28:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:28:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:30:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:31:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:32:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/store/1/site"
INFO - 2016-07-20 18:32:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:32:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:32:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:32:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:32:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 18:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 18:34:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 18:34:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 18:34:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:34:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:35:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:45:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 18:45:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:45:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:45:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 18:45:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:45:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 18:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:48:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:48:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:50:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:57:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 18:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:00:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 19:01:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 19:01:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 19:01:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 19:01:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-20 19:01:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:01:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:01:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:02:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:10:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:15:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:15:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:15:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:16:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:16:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:20:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:21:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:23:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:26:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:26:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:42:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:42:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:45:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:45:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:50:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:51:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:51:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:51:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:51:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 19:53:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 19:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:02:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 20:02:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:02:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:02:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 20:02:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:02:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 20:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 20:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:13:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:13:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:13:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 20:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 20:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 20:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:18:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:18:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 20:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:18:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:18:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 20:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 20:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-20 20:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/img-dell@2x"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-20 20:21:19 --> Fuel\Core\Request::execute - Setting main Request
