<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

DEBUG - 2016-06-21 17:41:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:41:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:41:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:41:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:41:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:41:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:41:32 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:41:32 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:41:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:41:32 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:41:32 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:41:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:41:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:41:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:41:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:41:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:41:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:41:59 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:41:59 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:41:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:41:59 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:41:59 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:42:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:42:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:42:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:42:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:42:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:42:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:42:03 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:42:03 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:42:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:42:03 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:42:03 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:43:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:43:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:43:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:43:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:43:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:43:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:43:12 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:43:12 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:43:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:43:12 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:43:12 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:43:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:43:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:43:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:43:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:43:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:43:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:43:21 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:43:21 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:43:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:43:21 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:43:21 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:43:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:43:23 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:43:23 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:43:23 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:43:23 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:43:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:43:23 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:43:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:43:23 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:43:23 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:43:23 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:43:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:43:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:43:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:43:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:43:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:43:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:43:27 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:43:27 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:43:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:43:27 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:43:27 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:43:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:43:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:43:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:43:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:43:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:43:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:43:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:43:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:43:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:43:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:43:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:43:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:43:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:43:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:43:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:43:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:43:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:43:40 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:43:40 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:43:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:43:40 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:43:40 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:43:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:43:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:43:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:43:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:43:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:43:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:43:46 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:43:46 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:43:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:43:46 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:43:46 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:46:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:46:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:46:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:46:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:46:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:46:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:46:05 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:46:05 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:46:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:46:05 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:46:05 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:46:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:46:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:46:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:46:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:46:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:46:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:46:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:46:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:46:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:46:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:46:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:46:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:46:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:46:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:46:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:46:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:46:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:46:39 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:46:39 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:46:39 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:46:39 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:46:39 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:47:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:47:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:47:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:47:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:47:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:47:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:47:25 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:47:25 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:47:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:47:25 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:47:25 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:48:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:48:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:48:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:48:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:48:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:48:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:48:03 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:48:03 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:48:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:48:03 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:48:03 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:50:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:50:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:50:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:50:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:50:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:50:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:50:20 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:50:20 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:50:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:50:20 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:50:20 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:51:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:51:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:51:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:51:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:51:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:51:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:51:26 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:51:26 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:51:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:51:26 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:51:26 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:51:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:51:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:51:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:51:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:51:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:51:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:51:42 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:51:42 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:51:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:51:42 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:51:42 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:51:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:51:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:51:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:51:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:51:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:51:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:51:55 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:51:55 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:51:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:51:55 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:51:55 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:54:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:54:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:54:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:54:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:54:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:54:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:54:09 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:54:09 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:54:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:54:09 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:54:09 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:54:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:54:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:54:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:54:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:54:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:54:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:54:23 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:54:23 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:54:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:54:23 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:54:23 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:57:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:57:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:57:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:57:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:57:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:57:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:57:50 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:57:50 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:57:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:57:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:57:51 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:57:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:57:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:57:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:57:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:57:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:57:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:57:56 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:57:56 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:57:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:57:56 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:57:56 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:58:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:58:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:58:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:58:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:58:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:58:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:58:04 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:58:04 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:58:04 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:58:04 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:58:04 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:59:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:59:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:59:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:59:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:59:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:59:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:59:05 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:59:05 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:59:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:59:05 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:59:05 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:59:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:59:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:59:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:59:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:59:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:59:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:59:09 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:59:09 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:59:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:59:09 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:59:09 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:59:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:59:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:59:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:59:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:59:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:59:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:59:11 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:59:11 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:59:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:59:11 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:59:11 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:59:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:59:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:59:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:59:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:59:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:59:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:59:14 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:59:14 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:59:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:59:14 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:59:14 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 17:59:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 17:59:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 17:59:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 17:59:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 17:59:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 17:59:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 17:59:15 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 17:59:15 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 17:59:15 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 17:59:15 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 17:59:15 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:00:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:00:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:00:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:00:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:00:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:00:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:00:08 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:00:08 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:00:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:00:08 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:00:08 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:00:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:00:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:00:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:00:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:00:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:00:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:00:11 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:00:11 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:00:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:00:11 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:00:11 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:00:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:00:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:00:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:00:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:00:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:00:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:00:15 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:00:15 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:00:15 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:00:15 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:00:15 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:00:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:00:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:00:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:00:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:00:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:00:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:00:32 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:00:32 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:00:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:00:32 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:00:32 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:01:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:01:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:01:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:01:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:01:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:01:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:01:01 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:01:01 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:01:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:01:01 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:01:01 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:01:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:01:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:01:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:01:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:01:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:01:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:01:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:01:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:01:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:01:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:01:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:02:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:02:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:02:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:02:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:02:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:02:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:02:10 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:02:10 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:02:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:02:10 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:02:10 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:02:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:02:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:02:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:02:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:02:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:02:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:02:32 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:02:32 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:02:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:02:32 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:02:32 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:02:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:02:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:02:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:02:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:02:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:02:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:02:34 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:02:34 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:02:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:02:34 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:02:34 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:02:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:02:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:02:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:02:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:02:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:02:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:02:37 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:02:37 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:02:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:02:37 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:02:37 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:03:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:03:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:03:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:03:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:03:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:03:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:03:04 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:03:04 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:03:04 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:03:04 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:03:04 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:03:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:03:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:03:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:03:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:03:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:03:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:03:36 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:03:36 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:03:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:03:36 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:03:36 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:03:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:03:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:03:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:03:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:03:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:03:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:03:44 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:03:44 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:03:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:03:44 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:03:44 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:03:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:03:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:03:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:03:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:03:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:03:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:03:59 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:03:59 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:03:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:03:59 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:03:59 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:04:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:04:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:04:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:04:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:04:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:04:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:04:02 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:04:02 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:04:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:04:02 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:04:02 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:04:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:04:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:04:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:04:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:04:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:04:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:04:08 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:04:08 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:04:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:04:08 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:04:08 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:04:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:04:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:04:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:04:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:04:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:04:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:04:22 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:04:22 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:04:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:04:22 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:04:22 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:04:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:04:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:04:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:04:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:04:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:04:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:04:26 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:04:26 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:04:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:04:26 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:04:26 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:04:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:04:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:04:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:04:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:04:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:04:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:04:30 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:04:30 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:04:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:04:30 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:04:30 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:04:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:04:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:04:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:04:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:04:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:04:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:04:32 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:04:32 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:04:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:04:32 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:04:32 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:04:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:04:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:04:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:04:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:04:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:04:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:04:36 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:04:36 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:04:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:04:36 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:04:36 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:05:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:05:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:05:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:05:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:05:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:05:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:05:38 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:05:38 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:05:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:05:38 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:05:38 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:07:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:07:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:07:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:07:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:07:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:07:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:07:35 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:07:35 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:07:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:07:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:07:35 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:08:10 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:08:10 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:08:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:08:10 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:08:10 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:08:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:08:10 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:08:10 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:08:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:08:10 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:08:10 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:08:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:08:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:08:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:08:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:08:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:08:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:08:13 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:08:13 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:08:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:08:13 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:08:13 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:09:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:09:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:09:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:09:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:09:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:09:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:09:26 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:09:26 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:09:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:09:26 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:09:26 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:09:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:09:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:09:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:09:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:09:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:09:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:09:35 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:09:35 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:09:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:09:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:09:35 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:09:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:09:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:09:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:09:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:09:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:09:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:09:38 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:09:38 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:09:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:09:38 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:09:38 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:09:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:09:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:09:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:09:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:09:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:09:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:09:39 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:09:39 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:09:39 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:09:39 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:09:39 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:10:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:10:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:10:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:10:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:10:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:10:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:10:09 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:10:09 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:10:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:10:09 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:10:09 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:10:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:10:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:10:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:10:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:10:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:10:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:10:13 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:10:13 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:10:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:10:13 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:10:13 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:10:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:10:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:10:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:10:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:10:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:10:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:10:36 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:10:36 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:10:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:10:36 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:10:36 --> Controller_Api->action_index(108) - exception 'Fuel\Core\PhpErrorException' with message 'Undefined index: coupon_status' in /var/www/local.gmorepeater.jp/fuel/app/classes/model/coupon.php:408
Stack trace:
#0 /var/www/local.gmorepeater.jp/fuel/core/bootstrap.php(103): Fuel\Core\Errorhandler::error_handler(8, 'Undefined index...', '/var/www/local....', 408)
#1 /var/www/local.gmorepeater.jp/fuel/app/classes/model/coupon.php(408): {closure}(8, 'Undefined index...', '/var/www/local....', 408, Array)
#2 /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/coupon.php(53): Model_Coupon::makeConditions(Array)
#3 /var/www/local.gmorepeater.jp/fuel/app/classes/controller/api.php(91): Api\Controller_Coupon->index()
#4 /var/www/local.gmorepeater.jp/fuel/core/base.php(461): Controller_Api->action_index()
#5 /var/www/local.gmorepeater.jp/fuel/core/classes/controller/rest.php(153): call_fuel_func_array(Array, Array)
#6 [internal function]: Fuel\Core\Controller_Rest->router('index', Array)
#7 /var/www/local.gmorepeater.jp/fuel/core/classes/request.php(454): ReflectionMethod->invokeArgs(Object(Api\Controller_Coupon), Array)
#8 /var/www/local.gmorepeater.jp/public/index.php(71): Fuel\Core\Request->execute()
#9 /var/www/local.gmorepeater.jp/public/index.php(92): {closure}()
#10 {main}
DEBUG - 2016-06-21 18:10:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:10:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:10:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:10:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:10:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:10:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:10:47 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:10:47 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:10:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:10:47 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:10:47 --> Controller_Api->action_index(108) - exception 'Fuel\Core\PhpErrorException' with message 'Undefined index: coupon_status' in /var/www/local.gmorepeater.jp/fuel/app/classes/model/coupon.php:408
Stack trace:
#0 /var/www/local.gmorepeater.jp/fuel/core/bootstrap.php(103): Fuel\Core\Errorhandler::error_handler(8, 'Undefined index...', '/var/www/local....', 408)
#1 /var/www/local.gmorepeater.jp/fuel/app/classes/model/coupon.php(408): {closure}(8, 'Undefined index...', '/var/www/local....', 408, Array)
#2 /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/coupon.php(53): Model_Coupon::makeConditions(Array)
#3 /var/www/local.gmorepeater.jp/fuel/app/classes/controller/api.php(91): Api\Controller_Coupon->index()
#4 /var/www/local.gmorepeater.jp/fuel/core/base.php(461): Controller_Api->action_index()
#5 /var/www/local.gmorepeater.jp/fuel/core/classes/controller/rest.php(153): call_fuel_func_array(Array, Array)
#6 [internal function]: Fuel\Core\Controller_Rest->router('index', Array)
#7 /var/www/local.gmorepeater.jp/fuel/core/classes/request.php(454): ReflectionMethod->invokeArgs(Object(Api\Controller_Coupon), Array)
#8 /var/www/local.gmorepeater.jp/public/index.php(71): Fuel\Core\Request->execute()
#9 /var/www/local.gmorepeater.jp/public/index.php(92): {closure}()
#10 {main}
DEBUG - 2016-06-21 18:10:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:10:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:10:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:10:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:10:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:10:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:10:49 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:10:49 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:10:49 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:10:49 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:10:49 --> Controller_Api->action_index(108) - exception 'Fuel\Core\PhpErrorException' with message 'Undefined index: coupon_status' in /var/www/local.gmorepeater.jp/fuel/app/classes/model/coupon.php:408
Stack trace:
#0 /var/www/local.gmorepeater.jp/fuel/core/bootstrap.php(103): Fuel\Core\Errorhandler::error_handler(8, 'Undefined index...', '/var/www/local....', 408)
#1 /var/www/local.gmorepeater.jp/fuel/app/classes/model/coupon.php(408): {closure}(8, 'Undefined index...', '/var/www/local....', 408, Array)
#2 /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/coupon.php(53): Model_Coupon::makeConditions(Array)
#3 /var/www/local.gmorepeater.jp/fuel/app/classes/controller/api.php(91): Api\Controller_Coupon->index()
#4 /var/www/local.gmorepeater.jp/fuel/core/base.php(461): Controller_Api->action_index()
#5 /var/www/local.gmorepeater.jp/fuel/core/classes/controller/rest.php(153): call_fuel_func_array(Array, Array)
#6 [internal function]: Fuel\Core\Controller_Rest->router('index', Array)
#7 /var/www/local.gmorepeater.jp/fuel/core/classes/request.php(454): ReflectionMethod->invokeArgs(Object(Api\Controller_Coupon), Array)
#8 /var/www/local.gmorepeater.jp/public/index.php(71): Fuel\Core\Request->execute()
#9 /var/www/local.gmorepeater.jp/public/index.php(92): {closure}()
#10 {main}
DEBUG - 2016-06-21 18:10:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:10:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:10:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:10:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:10:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:10:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:10:57 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:10:57 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:10:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:10:57 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:10:57 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:11:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:11:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:11:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:11:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:11:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:11:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:11:25 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:11:25 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:11:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:11:25 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:11:25 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:11:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:11:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:11:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:11:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:11:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:11:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:11:42 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:11:42 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:11:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:11:42 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:11:42 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:11:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:11:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:11:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:11:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:11:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:11:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:11:55 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:11:55 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:11:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:11:55 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:11:55 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:12:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:12:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:12:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:12:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:12:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:12:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:12:00 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:12:00 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:12:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:12:00 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:12:00 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:12:12 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:12:12 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:12:12 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:12:12 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:12:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:12:12 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:12:12 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:12:12 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:12:12 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:12:12 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:12:12 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:13:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:13:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:13:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:13:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:13:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:13:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:13:55 --> user/index called
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
INFO - 2016-06-21 18:13:56 --> store/index called
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:13:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:13:56 --> brand/index called
INFO - 2016-06-21 18:13:56 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 18:13:56 --> company/index called
INFO - 2016-06-21 18:13:56 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:14:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:14:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:14:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:14:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:14:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:14:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:14:25 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:14:25 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:14:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:14:25 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:14:25 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:15:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:15:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:15:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:15:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:15:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:15:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:15:51 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:15:51 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:15:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:15:51 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:15:51 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:15:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:15:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:15:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:15:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:15:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:15:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:15:57 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:15:57 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:15:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:15:57 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:15:57 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:16:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:03 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:16:03 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:16:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:16:03 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:16:03 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:16:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:08 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:16:08 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:16:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:16:08 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:16:08 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:16:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:28 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:16:28 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:16:28 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:16:28 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:16:28 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:16:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:33 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:16:33 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:16:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:16:33 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:16:33 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:16:38 --> user/index called
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:16:38 --> brand/index called
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:16:38 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:16:38 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:16:38 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:16:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:16:38 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:16:38 --> store/index called
INFO - 2016-06-21 18:16:38 --> company/index called
DEBUG - 2016-06-21 18:16:38 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:16:38 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:16:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:44 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:16:44 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:16:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:16:44 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:16:44 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:16:50 --> user/index called
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:50 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:16:50 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 18:16:50 --> store/index called
INFO - 2016-06-21 18:16:50 --> company/index called
INFO - 2016-06-21 18:16:50 --> brand/index called
DEBUG - 2016-06-21 18:16:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:16:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:16:50 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:16:50 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:16:50 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:16:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:16:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:16:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:16:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:16:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:16:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:16:57 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:16:57 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:16:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:16:57 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:16:57 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:17:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:14 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:17:14 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:17:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:17:14 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:17:14 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:17:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:20 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:17:20 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:17:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:17:20 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:17:20 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:17:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:23 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:17:23 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:17:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:17:23 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:17:23 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:17:50 --> user/index called
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:17:50 --> brand/index called
INFO - 2016-06-21 18:17:50 --> company/index called
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:50 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:17:50 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 18:17:50 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 18:17:50 --> store/index called
DEBUG - 2016-06-21 18:17:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:17:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:17:50 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:17:50 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:17:52 --> user/index called
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:53 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:17:53 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:53 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:17:53 --> brand/index called
DEBUG - 2016-06-21 18:17:53 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:17:53 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:17:53 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 18:17:53 --> company/index called
INFO - 2016-06-21 18:17:53 --> store/index called
DEBUG - 2016-06-21 18:17:53 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:17:53 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:17:55 --> brand/index called
INFO - 2016-06-21 18:17:55 --> store/index called
INFO - 2016-06-21 18:17:55 --> user/index called
DEBUG - 2016-06-21 18:17:55 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:17:55 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:17:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:17:55 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:17:55 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:17:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:17:55 --> company/index called
DEBUG - 2016-06-21 18:17:55 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:17:55 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:18:02 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:18:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:18:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:18:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:18:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:18:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:18:02 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:18:02 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:18:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:18:02 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:18:02 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:18:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:18:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:18:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:18:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:18:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:18:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:18:04 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:18:04 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:18:04 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:18:04 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:18:04 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:18:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:18:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:18:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:18:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:18:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:18:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:18:06 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:18:06 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:18:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:18:06 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:18:06 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:19:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:19:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:19:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:19:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:19:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:19:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:19:41 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:19:41 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:19:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:19:41 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:19:41 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:20:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:20:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:20:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:20:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:20:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:20:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:20:06 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:20:06 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:20:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:20:06 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:20:06 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:20:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:20:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:20:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:20:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:20:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:20:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:20:17 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:20:17 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:20:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:20:17 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:20:17 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:20:20 --> store/index called
INFO - 2016-06-21 18:20:20 --> brand/index called
INFO - 2016-06-21 18:20:20 --> user/index called
INFO - 2016-06-21 18:20:20 --> company/index called
INFO - 2016-06-21 18:20:20 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:20:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:20:20 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:20:20 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:20:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:20:20 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:20:20 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:20:20 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:21:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:21:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:21:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:21:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:21:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:21:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:21:21 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:21:21 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:21:21 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:21:21 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:21:21 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:23:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:23:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:23:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:23:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:23:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:23:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:23:17 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:23:17 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:23:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:23:17 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:23:17 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:23:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:23:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:23:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:23:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:23:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:23:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:23:20 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:23:20 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:23:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:23:20 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:23:21 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:23:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:23:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:23:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:23:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:23:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:23:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:23:24 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:23:24 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:23:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:23:24 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:23:24 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:25:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:25:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:25:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:25:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:25:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:25:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:25:47 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:25:47 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:25:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:25:47 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:25:47 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:25:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:25:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:25:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:25:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:25:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:25:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:25:50 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:25:50 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:25:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:25:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:25:50 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:25:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:25:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:25:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:25:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:25:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:25:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:25:52 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:25:52 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:25:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:25:52 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:25:52 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:26:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:26:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:26:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:26:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:26:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:26:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:26:43 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:26:43 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:26:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:26:43 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:26:43 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:26:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:26:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:26:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:26:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:26:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:26:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:26:55 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:26:55 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:26:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:26:55 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:26:55 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:27:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:00 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:27:00 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:27:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:27:00 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:27:00 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:27:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:04 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:27:04 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:27:04 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:27:04 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:27:04 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:18 --> user/index called
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:18 --> brand/index called
INFO - 2016-06-21 18:27:18 --> store/index called
INFO - 2016-06-21 18:27:18 --> company/index called
INFO - 2016-06-21 18:27:18 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:27:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:27:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:27:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:27:18 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:27:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:22 --> user/index called
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:22 --> company/index called
INFO - 2016-06-21 18:27:22 --> store/index called
DEBUG - 2016-06-21 18:27:22 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:27:22 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:22 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:22 --> brand/index called
INFO - 2016-06-21 18:27:22 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 18:27:22 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:27:22 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:33 --> user/index called
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:33 --> company/index called
INFO - 2016-06-21 18:27:33 --> brand/index called
INFO - 2016-06-21 18:27:33 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 18:27:33 --> store/index called
INFO - 2016-06-21 18:27:33 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:33 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:27:33 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:27:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:27:33 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:27:33 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:37 --> user/index called
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:37 --> brand/index called
DEBUG - 2016-06-21 18:27:37 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:27:37 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:27:37 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:27:37 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 18:27:37 --> store/index called
INFO - 2016-06-21 18:27:37 --> company/index called
DEBUG - 2016-06-21 18:27:37 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:27:37 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:45 --> user/index called
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:45 --> brand/index called
INFO - 2016-06-21 18:27:45 --> store/index called
INFO - 2016-06-21 18:27:45 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:27:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:27:45 --> company/index called
DEBUG - 2016-06-21 18:27:45 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:27:45 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:27:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:27:45 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:27:45 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:27:45 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:28:17 --> user/index called
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:28:17 --> store/index called
INFO - 2016-06-21 18:28:17 --> brand/index called
INFO - 2016-06-21 18:28:17 --> company/index called
INFO - 2016-06-21 18:28:17 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:28:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:28:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:28:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:28:18 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:28:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:28:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:26 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:28:26 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:28:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:28:26 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:28:26 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:28:33 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:33 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:33 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:33 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:33 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:33 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:28:33 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:28:33 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:28:33 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:28:33 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:28:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:36 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:28:36 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:28:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:28:36 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:28:36 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:28:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:50 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:28:50 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:28:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:28:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:28:50 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:28:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:52 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:28:52 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:28:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:28:52 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:28:52 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:59 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:28:59 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:28:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:28:59 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:28:59 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:28:59 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:28:59 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:28:59 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:28:59 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:28:59 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:28:59 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:02 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:02 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:02 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:02 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:02 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:02 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:02 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:02 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:02 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:03 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:03 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:03 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:03 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:05 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:05 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:05 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:05 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:07 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:07 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:07 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:07 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:07 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:07 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:07 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:07 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:07 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:07 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:29:10 --> user/index called
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:29:10 --> company/index called
INFO - 2016-06-21 18:29:10 --> brand/index called
INFO - 2016-06-21 18:29:10 --> store/index called
INFO - 2016-06-21 18:29:10 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:10 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:10 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:10 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:29:10 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:29:10 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:29:36 --> user/index called
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:29:36 --> brand/index called
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:29:36 --> company/index called
DEBUG - 2016-06-21 18:29:36 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:36 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 18:29:36 --> store/index called
INFO - 2016-06-21 18:29:36 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:29:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:36 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:29:36 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:29:36 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:42 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:42 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:42 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:42 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:44 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:44 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:44 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:44 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:47 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:47 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:47 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:47 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:55 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:55 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:55 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:55 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:55 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:55 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:55 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:55 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:55 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:29:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:29:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:29:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:29:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:29:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:29:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:29:58 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:29:58 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:29:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:29:58 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:29:58 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:30:04 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:30:04 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:30:04 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:30:04 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:30:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:30:04 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:30:04 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:30:04 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:30:04 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:30:04 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:30:04 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:33:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:33:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:33:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:33:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:33:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:33:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:33:51 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:33:51 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:33:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:33:51 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:33:51 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:33:52 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:33:52 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:33:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:33:52 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:33:52 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:33:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:33:52 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:33:52 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:33:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:33:52 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:33:52 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:33:55 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:33:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:33:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:33:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:33:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:33:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:33:56 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:33:56 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:33:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:33:56 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:33:56 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:34:03 --> user/index called
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:34:03 --> brand/index called
DEBUG - 2016-06-21 18:34:03 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:03 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:03 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:03 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:03 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:34:03 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 18:34:03 --> store/index called
INFO - 2016-06-21 18:34:03 --> company/index called
DEBUG - 2016-06-21 18:34:03 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:34:03 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:34:05 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:05 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:05 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:05 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:05 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:05 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:05 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:05 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:05 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:05 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:23 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:23 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:23 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:23 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:35 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:35 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:35 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:36 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:36 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:36 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:36 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:39 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:39 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:39 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:39 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:39 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:45 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:45 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:45 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:45 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:50 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:50 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:50 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:52 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:52 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:52 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:52 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:34:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:34:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:34:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:34:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:34:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:34:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:34:58 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:34:58 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:34:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:34:58 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:34:58 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:35:46 --> user/index called
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
INFO - 2016-06-21 18:35:46 --> store/index called
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:35:46 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:35:46 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 18:35:46 --> company/index called
DEBUG - 2016-06-21 18:35:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:35:46 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:35:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:35:46 --> brand/index called
INFO - 2016-06-21 18:35:46 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:35:46 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:35:46 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:36:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:36:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:36:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:36:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:36:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:36:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:36:24 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:36:24 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:36:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:36:24 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:36:24 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:36:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:36:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:36:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:36:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:36:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:36:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:36:49 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:36:49 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:36:49 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:36:49 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:36:49 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:36:54 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:36:54 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:36:54 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:36:54 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:36:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:36:54 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:36:54 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:36:54 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:36:54 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:36:54 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:36:54 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:42:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:42:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:42:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:42:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:42:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:42:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:42:39 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:42:39 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:42:39 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:42:39 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:42:39 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:43:25 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:43:25 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:43:25 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:43:25 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:43:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:43:25 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:43:25 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:43:25 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:43:25 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:43:25 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:43:25 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:43:31 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:43:31 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:43:31 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:43:31 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:43:31 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:43:31 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:43:31 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:43:31 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:43:31 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:43:31 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:43:31 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:43:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:43:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:43:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:43:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:43:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:43:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:43:41 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:43:41 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:43:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:43:41 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:43:41 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:44:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:44:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:44:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:44:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:44:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:44:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:44:43 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:44:43 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:44:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:44:43 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:44:43 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:45:28 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:28 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:28 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:28 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:28 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:45:28 --> user/index called
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:45:29 --> company/index called
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:45:29 --> brand/index called
DEBUG - 2016-06-21 18:45:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:45:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 18:45:29 --> store/index called
DEBUG - 2016-06-21 18:45:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
INFO - 2016-06-21 18:45:29 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:45:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:45:29 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:45:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:45:32 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:32 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:32 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:32 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:32 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:32 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:45:32 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:45:32 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:45:32 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:45:32 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:45:32 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:45:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:49 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:49 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:45:49 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:45:49 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:45:49 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:45:49 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:45:49 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:45:52 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:52 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:52 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:52 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:52 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:52 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:45:52 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:45:52 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:45:52 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:45:52 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:45:53 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:45:58 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:45:58 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:45:58 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:45:58 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:45:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:45:58 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:45:58 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:45:58 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:45:58 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:45:58 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:45:58 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:46:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:46:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:46:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:46:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:46:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:46:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:46:00 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:46:00 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:46:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:46:00 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 18:46:00 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:51:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:51:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:51:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:51:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:51:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:51:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:51:09 --> user/index called
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:51:09 --> store/index called
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
INFO - 2016-06-21 18:51:09 --> company/index called
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:51:09 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:51:09 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:51:09 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 18:51:09 --> brand/index called
DEBUG - 2016-06-21 18:51:09 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:51:09 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:51:09 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 18:51:09 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:51:09 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:56:14 --> user/index called
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:56:14 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:56:14 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:56:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:56:14 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:56:14 --> brand/index called
INFO - 2016-06-21 18:56:14 --> store/index called
INFO - 2016-06-21 18:56:14 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:56:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:56:14 --> company/index called
DEBUG - 2016-06-21 18:56:14 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:56:14 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:57:37 --> user/index called
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:57:37 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:57:37 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:57:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:57:37 --> company/index called
DEBUG - 2016-06-21 18:57:37 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:57:37 --> brand/index called
INFO - 2016-06-21 18:57:37 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:57:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:57:37 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
INFO - 2016-06-21 18:57:37 --> store/index called
INFO - 2016-06-21 18:57:37 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:58:50 --> user/index called
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 18:58:50 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 18:58:50 --> brand/index called
INFO - 2016-06-21 18:58:50 --> company/index called
INFO - 2016-06-21 18:58:50 --> store/index called
INFO - 2016-06-21 18:58:50 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 18:58:50 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 18:58:50 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 18:58:50 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 18:58:50 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 18:58:50 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 18:58:50 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:00:11 --> user/index called
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:00:11 --> store/index called
INFO - 2016-06-21 19:00:11 --> company/index called
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:11 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:00:11 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:00:11 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 19:00:11 --> brand/index called
DEBUG - 2016-06-21 19:00:11 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:00:11 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:00:11 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 19:00:11 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:00:11 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:00:41 --> user/index called
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:00:41 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:00:41 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 19:00:41 --> brand/index called
INFO - 2016-06-21 19:00:41 --> store/index called
DEBUG - 2016-06-21 19:00:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:00:41 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:00:41 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:00:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:00:41 --> company/index called
INFO - 2016-06-21 19:00:41 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:00:41 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:04:57 --> user/index called
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:04:57 --> store/index called
INFO - 2016-06-21 19:04:57 --> brand/index called
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:04:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:04:57 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:04:57 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 19:04:57 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 19:04:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:04:57 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:04:57 --> company/index called
INFO - 2016-06-21 19:04:57 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:04:57 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:05:22 --> user/index called
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
INFO - 2016-06-21 19:05:22 --> brand/index called
DEBUG - 2016-06-21 19:05:22 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:05:22 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:05:22 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:05:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:05:22 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:05:22 --> store/index called
INFO - 2016-06-21 19:05:22 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 19:05:22 --> company/index called
INFO - 2016-06-21 19:05:22 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:05:22 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:08:10 --> user/index called
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:08:10 --> store/index called
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:08:10 --> company/index called
DEBUG - 2016-06-21 19:08:10 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:08:10 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 19:08:10 --> brand/index called
DEBUG - 2016-06-21 19:08:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:08:10 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:08:10 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 19:08:10 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:08:10 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:08:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:08:16 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:08:16 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:08:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:08:16 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:08:16 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:08:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:08:17 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:08:17 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:08:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:08:17 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:08:17 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:08:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:08:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:08:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:08:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:08:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:08:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:08:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:08:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:08:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:08:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:08:24 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:24 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:24 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:24 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:24 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:08:24 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:08:24 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:08:24 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:08:24 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:08:24 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:08:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:08:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:08:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:08:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:08:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:08:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:08:30 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:08:30 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:08:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:08:30 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:08:30 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:09:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:09:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:09:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:09:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:09:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:09:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:09:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:09:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:09:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:09:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:09:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:09:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:09:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:09:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:09:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:09:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:09:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:09:27 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:09:27 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:09:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:09:27 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:09:27 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:11:26 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:11:26 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:11:26 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:11:26 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:11:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:11:26 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:11:26 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:11:26 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:11:26 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:11:26 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:11:26 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:12:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:12:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:12:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:12:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:12:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:12:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:12:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:12:35 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:12:36 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:12:36 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:12:36 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:12:36 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:12:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:12:36 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:12:36 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:12:36 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:12:36 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:12:36 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:12:36 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:15:57 --> user/index called
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:15:57 --> company/index called
INFO - 2016-06-21 19:15:57 --> brand/index called
DEBUG - 2016-06-21 19:15:57 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:15:57 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:15:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:15:57 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:15:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:15:57 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 19:15:57 --> store/index called
INFO - 2016-06-21 19:15:57 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:15:57 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:16 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:16 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:16 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:16 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:16 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:16 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:16 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:16 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:16 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:16 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:17 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:17 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:17 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:17 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:17 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:17 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:17 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:17 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:18 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:18 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:18 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:18 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:18 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:18 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:18 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:18 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:18 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:18 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:18 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:21 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:21 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:21 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:21 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:21 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:21 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:21 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:22 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:22 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:22 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:22 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:29 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:29 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:29 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:16:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:16:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:16:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:16:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:16:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:16:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:16:30 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:16:30 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:16:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:16:30 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:16:30 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:19:37 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:19:37 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:19:37 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:19:37 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:19:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:19:37 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:19:37 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:19:37 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:19:37 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:19:37 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:19:37 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:21:15 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:21:15 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:21:15 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:21:15 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:21:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:21:15 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:21:15 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:21:15 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:21:15 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:21:15 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:21:15 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:21:30 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:21:30 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:21:30 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:21:30 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:21:30 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:21:30 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:21:30 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:21:30 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:21:30 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:21:30 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:21:30 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:21:47 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:21:47 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:21:47 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:21:47 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:21:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:21:47 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:21:47 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:21:47 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:21:47 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:21:47 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:21:47 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:22:01 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:22:01 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:22:01 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:22:01 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:22:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:22:01 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:22:01 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:22:01 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:22:01 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:22:01 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:22:01 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:22:10 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:22:10 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:22:10 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:22:10 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:22:10 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:22:10 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:22:10 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:22:10 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:22:10 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:22:10 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:22:10 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:22:20 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:22:20 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:22:20 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:22:20 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:22:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:22:20 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:22:20 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:22:20 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:22:20 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:22:20 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:22:20 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:24:00 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:24:00 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:24:00 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:24:00 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:24:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:24:00 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:24:00 --> Api\Controller_Coupon->index(42) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:24:00 --> Api\Controller_Coupon->setParams(160) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:24:00 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:24:00 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:24:00 --> Api\Controller_Coupon->index(91) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:24:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:24:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:24:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:24:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:24:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:24:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:24:35 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:24:35 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:24:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:24:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:24:35 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:24:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:24:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:24:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:24:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:24:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:24:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:24:40 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:24:40 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:24:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:24:40 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:24:40 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:24:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:24:46 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:24:46 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:24:46 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:24:46 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:24:46 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:24:46 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:24:46 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:24:46 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:24:46 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:24:46 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:24:51 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:24:51 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:24:51 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:24:51 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:24:51 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:24:51 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:24:51 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:24:51 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:24:51 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:24:51 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:24:51 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:24:56 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:24:56 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:24:56 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:24:56 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:24:56 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:24:56 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:24:56 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:24:56 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:24:56 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:24:56 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:24:56 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:25:08 --> user/index called
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:25:08 --> store/index called
DEBUG - 2016-06-21 19:25:08 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:25:08 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:25:08 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:25:08 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:25:08 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:25:08 --> company/index called
INFO - 2016-06-21 19:25:08 --> brand/index called
INFO - 2016-06-21 19:25:08 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 19:25:08 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:25:08 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:25:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:25:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:25:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:25:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:25:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:25:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:25:13 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:25:13 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:25:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:25:13 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:25:13 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:25:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:25:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:25:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:25:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:25:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:25:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:25:17 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:25:17 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:25:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:25:17 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:25:17 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:27:13 --> user/index called
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:13 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:27:13 --> company/index called
INFO - 2016-06-21 19:27:13 --> brand/index called
INFO - 2016-06-21 19:27:13 --> store/index called
INFO - 2016-06-21 19:27:13 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 19:27:13 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:27:13 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:27:13 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:27:13 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:27:13 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:27:13 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:27:27 --> user/index called
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:27:27 --> company/index called
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:27 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:27:27 --> store/index called
INFO - 2016-06-21 19:27:27 --> brand/index called
DEBUG - 2016-06-21 19:27:27 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:27:27 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:27:27 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:27:27 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:27:27 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 19:27:27 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
INFO - 2016-06-21 19:27:27 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:27:34 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:34 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:34 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:34 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:34 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:27:34 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:27:34 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:27:34 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:27:34 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:27:34 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:27:39 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:39 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:39 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:39 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:39 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:27:39 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:27:39 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:27:39 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:27:39 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:27:39 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:27:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:27:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:27:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:27:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:27:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:27:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:27:43 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:27:43 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:27:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:27:43 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:27:43 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:29:06 --> user/index called
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:29:06 --> store/index called
INFO - 2016-06-21 19:29:06 --> company/index called
INFO - 2016-06-21 19:29:06 --> brand/index called
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:06 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:29:06 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
DEBUG - 2016-06-21 19:29:06 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:29:06 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:29:06 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:29:06 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:29:06 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:29:06 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:29:35 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:35 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:35 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:35 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:35 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:29:35 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:29:35 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:29:35 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:29:35 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:29:35 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:29:38 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:38 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:38 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:38 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:38 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:29:38 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:29:38 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:29:38 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:29:38 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:29:38 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:29:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:29:40 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:29:40 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:29:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:29:40 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:29:40 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:29:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:29:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:29:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:29:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:29:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:29:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:29:43 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:29:43 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:29:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:29:43 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:29:43 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:33:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:33:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:33:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:33:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
INFO - 2016-06-21 19:33:40 --> Controller_Api->before(81) - exception 'Fuel\Core\HttpBadRequestException' with message 'id is required' in /var/www/local.gmorepeater.jp/fuel/app/classes/controller/api.php:183
Stack trace:
#0 /var/www/local.gmorepeater.jp/fuel/app/classes/controller/api.php(78): Controller_Api->checkParameters()
#1 [internal function]: Controller_Api->before()
#2 /var/www/local.gmorepeater.jp/fuel/core/classes/request.php(452): ReflectionMethod->invoke(Object(Api\Controller_Coupon))
#3 /var/www/local.gmorepeater.jp/public/index.php(71): Fuel\Core\Request->execute()
#4 /var/www/local.gmorepeater.jp/public/index.php(92): {closure}()
#5 {main}
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:34:45 --> user/index called
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:34:45 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:34:45 --> store/index called
INFO - 2016-06-21 19:34:45 --> brand/index called
DEBUG - 2016-06-21 19:34:45 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:34:45 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:34:45 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:34:45 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:34:45 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 19:34:45 --> company/index called
INFO - 2016-06-21 19:34:45 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:34:45 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:34:49 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:34:49 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:34:49 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:34:49 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
INFO - 2016-06-21 19:34:49 --> Controller_Api->before(81) - exception 'Fuel\Core\HttpBadRequestException' with message 'id is required' in /var/www/local.gmorepeater.jp/fuel/app/classes/controller/api.php:183
Stack trace:
#0 /var/www/local.gmorepeater.jp/fuel/app/classes/controller/api.php(78): Controller_Api->checkParameters()
#1 [internal function]: Controller_Api->before()
#2 /var/www/local.gmorepeater.jp/fuel/core/classes/request.php(452): ReflectionMethod->invoke(Object(Api\Controller_Coupon))
#3 /var/www/local.gmorepeater.jp/public/index.php(71): Fuel\Core\Request->execute()
#4 /var/www/local.gmorepeater.jp/public/index.php(92): {closure}()
#5 {main}
DEBUG - 2016-06-21 19:42:40 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:42:40 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:42:40 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:42:40 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:42:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:42:40 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:42:40 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:42:40 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:42:40 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:42:40 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:42:40 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:42:41 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:42:41 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:42:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:42:41 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:42:41 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:42:41 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:42:41 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:42:41 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:42:41 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:42:41 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:42:41 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:42:42 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:42:42 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:42:42 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:42:42 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:42:42 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:42:42 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:42:42 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:42:42 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:42:42 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:42:42 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:42:42 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:42:43 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:42:43 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:42:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:42:43 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:42:43 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:42:43 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:42:43 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:42:43 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:42:43 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:42:43 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:42:43 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:42:44 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:42:44 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:42:44 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:42:44 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:42:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:42:44 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:42:44 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:42:44 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:42:44 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:42:44 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:42:44 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:43:14 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:43:14 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:43:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:43:14 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:43:14 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:43:14 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:43:14 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:43:14 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:43:14 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:43:14 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:43:14 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:43:17 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:43:17 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:43:17 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:43:17 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:43:17 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:43:17 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:43:17 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:43:17 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
DEBUG - 2016-06-21 19:43:17 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:43:17 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
DEBUG - 2016-06-21 19:43:17 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:51:23 --> user/index called
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:51:23 --> company/index called
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:51:23 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:51:23 --> brand/index called
DEBUG - 2016-06-21 19:51:23 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:51:23 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 19:51:23 --> store/index called
DEBUG - 2016-06-21 19:51:23 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:51:23 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:51:23 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 19:51:23 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:51:23 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:52:57 --> user/index called
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(60) - 【BEFORE API PROCESS】:START
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(67) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(74) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(77) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-06-21 19:52:57 --> Controller_Api->before(85) - 【BEFORE API PROCESS】:END
INFO - 2016-06-21 19:52:57 --> company/index called
DEBUG - 2016-06-21 19:52:57 --> Api\Controller_Coupon->index(44) - 【COUPON LIST API】:START
DEBUG - 2016-06-21 19:52:57 --> Api\Controller_Coupon->setParams(162) - 【COUPON API】:SET PARAM
INFO - 2016-06-21 19:52:57 --> store/index called
INFO - 2016-06-21 19:52:57 --> brand/index called
DEBUG - 2016-06-21 19:52:57 --> Model_User->checkAuthority(387) - 【USER AUTHORITY CHECK】
DEBUG - 2016-06-21 19:52:57 --> Model_User->checkAuthority(390) - 【USER AUTHORITY CHECK】:ADMIN
INFO - 2016-06-21 19:52:57 --> SELECT `t0`.`company_id` AS `t0_c0`, `t0`.`brand_code` AS `t0_c1`, `t0`.`brand_name` AS `t0_c2`, `t0`.`brand_status` AS `t0_c3`, `t0`.`brand_address` AS `t0_c4`, `t0`.`brand_phone_no` AS `t0_c5`, `t0`.`brand_regular_holiday` AS `t0_c6`, `t0`.`brand_signature_block` AS `t0_c7`, `t0`.`brand_terms_of_use` AS `t0_c8`, `t0`.`brand_privacy_policy` AS `t0_c9`, `t0`.`brand_freeword` AS `t0_c10`, `t0`.`store_display_type` AS `t0_c11`, `t0`.`google_analytics_id` AS `t0_c12`, `t0`.`google_analytics_pass` AS `t0_c13`, `t0`.`brand_first_open_date` AS `t0_c14`, `t0`.`member_registration_form_text_up` AS `t0_c15`, `t0`.`member_registration_form_text_down` AS `t0_c16`, `t0`.`created_at` AS `t0_c17`, `t0`.`updated_at` AS `t0_c18`, `t0`.`id` AS `t0_c19` FROM `brands` AS `t0`
INFO - 2016-06-21 19:52:57 --> Array
(
    [0] => Array
        (
            [company_id] => 1
            [brand_code] => 1
            [brand_name] => brand1
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 1
            [company_name] => company1
            [brand_status_name] => 準備中
            [store_count] => 1
        )

    [1] => Array
        (
            [company_id] => 2
            [brand_code] => 2
            [brand_name] => brand2
            [brand_status] => 2
            [brand_address] => 
            [brand_phone_no] => 
            [id] => 2
            [company_name] => company2
            [brand_status_name] => 準備中
            [store_count] => 1
        )

)

DEBUG - 2016-06-21 19:52:57 --> Api\Controller_Coupon->index(93) - 【COUPON LIST API】:END
