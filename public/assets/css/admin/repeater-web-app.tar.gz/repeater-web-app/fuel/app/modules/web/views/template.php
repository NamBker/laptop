<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-type" value="text/html; charset=UTF-8" />
    <meta name="description" content="">
    <meta name="author" content="GMOコマース">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $title; ?></title>

    <link rel="stylesheet" href="/assets/css/style.css"/>
    <link rel="stylesheet" href="/assets/css/style2.css"/>

    <link rel="shortcut icon" href="/assets/img/favicon/favicon.ico" type="image/vnd.microsoft.icon">
    <link rel="icon" href="/assets/img/favicon/favicon.ico" type="image/vnd.microsoft.icon">
    <link rel="apple-touch-icon" sizes="57x57" href="/assets/img/favicon/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/assets/img/favicon/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/assets/img/favicon/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/assets/img/favicon/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/assets/img/favicon/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/assets/img/favicon/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/assets/img/favicon/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/assets/img/favicon/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/img/favicon/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/assets/img/favicon/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="/assets/img/favicon/favicon-48x48.png" sizes="48x48">
    <link rel="icon" type="image/png" href="/assets/img/favicon/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/assets/img/favicon/favicon-16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="/assets/img/favicon/favicon-32x32.png" sizes="32x32">
    <link rel="manifest" href="/assets/img/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#2d88ef">
    <meta name="msapplication-TileImage" content="img/favicon/mstile-144x144.png">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
    <script>
        var apiHost = '<?php echo isset($apiHost) ? $apiHost : '' ?>';
        var accessToken = '<?php echo isset($apiToken) ? $apiToken : '' ?>';
    </script>
</head>
<body>

    <nav  role="navigation">
        <div class="container-fluid">
            <!--
            <div class="navbar-header">
                <--?php echo \Html::anchor('web', 'GMOリピーター', array('class' => 'navbar-brand'), \Util::isSecure()) ?>
            </div>
            -->
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <?php
                    if (\Auth::check()) {
                        $username = \Auth::instance()->get_screen_name();
                        if (isset($username)) {
                            echo "<li>" . \Html::anchor('web', '<span class="glyphicon glyphicon-user"></span>' . $username, array(), \Util::isSecure()) . "</li>";
                            echo "<li>" . \Html::anchor('web/user/logout', '<span class="glyphicon glyphicon-log-out"></span>ログアウト', array(), \Util::isSecure()) . "</li>";
                        } else {
                            echo "<li>" . \Html::anchor('web/user/login', '<span class="glyphicon glyphicon-log-in"></span>ログイン', array(), \Util::isSecure()) . "</li>";
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>
    </nav>

    <?php if (Session::get_flash('success')): ?>
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p>
                <?php echo implode('</p><p>', (array)Session::get_flash('success')); ?>
            </p>
        </div>
    <?php endif; ?>
    <?php if (Session::get_flash('error')): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p>
                <?php echo implode('</p><p>', (array)Session::get_flash('error')); ?>
            </p>
        </div>
    <?php endif; ?>
    <?php echo $content; ?>

</body>
</html>
