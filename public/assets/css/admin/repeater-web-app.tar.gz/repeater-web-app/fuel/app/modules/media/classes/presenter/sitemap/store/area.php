<?php
namespace Media;
class Presenter_Sitemap_Store_Area extends Presenter_Sitemap
{

	public function view()
	{
		\Additional_Log::debug("start.");
		parent::view();
	}
}
