<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Daily_Store->index(26) - 【DAILY STORE LIST API】:START
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Daily_Store->setParams(87) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-08-11 12:11:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Daily_Store->index(79) - 【DAILY STORE API】:END
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:39 --> Api\Controller_Analysis_Delivery->index(21) - daily/delivery called
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:48 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:48 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:48 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:11:48 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:11:48 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:48 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:11:48 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:11:48 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
DEBUG - 2016-08-11 12:11:48 --> Api\Controller_Site_Map->index(27) - site map index/ called
INFO - 2016-08-11 12:11:48 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:11:48 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:11:48 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:11:48 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:11:48 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:11:48 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:11:48 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:13:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:14 --> Model_User->checkAuthorityCompanyId(424) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-08-11 12:13:14 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:14 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 12:13:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:14 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:13:14 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [id] => 27
    [company_id] => 1
    [brand_id] => 1
    [store_id] => 1
    [sitemap_name] => sitemap1
    [sitemap_url] => example
    [linkage_site_id] => 0
    [title_picture_id] => 1
    [organize_type] => 1
    [page_type] => 4
    [organize_parts] => Array
        (
            [free_text] => dasda
            [menu_list] => Array
                (
                    [0] => Array
                        (
                            [id] => 1
                            [menu] => 
                        )

                )

        )

    [free_input] => example
    [header] => NULL
    [footer] => NULL
    [memo] => example
    [site_hierarchy] => 2
    [parents_site_id] => 1
    [display_flg] => 1
    [display_order] => 0
    [api_version] => 1
    [site_id] => 
)

DEBUG - 2016-08-11 12:13:14 --> Api\Controller_Site_Store_Free->update(131) - 【SITE_STORE_FREE UPDATE API】:END
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:13:19 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:13:19 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:19 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:19 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:20 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:13:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:20 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:13:20 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:13:20 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:20 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:22 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:22 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:22 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:22 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:22 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:22 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:13:22 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:13:22 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:23 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:23 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:23 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:23 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:13:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:23 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:23 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:13:23 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:13:23 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:13:34 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:34 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:13:34 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:13:58 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:13:58 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:13:58 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:13:59 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:14:14 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:14 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:14 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:14 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:14:16 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:16 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:16 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:16 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:16 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:16 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:16 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:16 --> Model_User->checkAuthorityCompanyId(424) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-08-11 12:14:16 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:16 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 12:14:16 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:16 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:16 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:14:16 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [id] => 27
    [company_id] => 1
    [brand_id] => 1
    [store_id] => 1
    [sitemap_name] => sitemap1
    [sitemap_url] => example
    [linkage_site_id] => 0
    [title_picture_id] => 1
    [organize_type] => 1
    [page_type] => 4
    [organize_parts] => Array
        (
            [free_text] => dasda
            [menu_list] => Array
                (
                    [0] => Array
                        (
                            [id] => 1
                            [menu] => 
                        )

                )

        )

    [free_input] => example
    [header] => NULL
    [footer] => NULL
    [memo] => example
    [site_hierarchy] => 2
    [parents_site_id] => 1
    [display_flg] => 1
    [display_order] => 0
    [api_version] => 1
    [site_id] => 
)

DEBUG - 2016-08-11 12:14:16 --> Api\Controller_Site_Store_Free->update(131) - 【SITE_STORE_FREE UPDATE API】:END
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:38 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:38 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:14:38 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:14:38 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:39 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:14:39 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:39 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:14:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:39 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:14:39 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:14:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:39 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:40 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:40 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:40 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:40 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:40 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:40 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:40 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:40 --> Model_User->checkAuthorityCompanyId(424) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-08-11 12:14:40 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:40 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 12:14:40 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:40 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:40 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:14:40 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [id] => 27
    [company_id] => 1
    [brand_id] => 1
    [store_id] => 1
    [sitemap_name] => sitemap1
    [sitemap_url] => example
    [linkage_site_id] => 0
    [title_picture_id] => 1
    [organize_type] => 1
    [page_type] => 4
    [organize_parts] => Array
        (
            [free_text] => dasda
            [menu_list] => Array
                (
                    [0] => Array
                        (
                            [id] => 1
                            [menu] => 
                        )

                )

        )

    [free_input] => example
    [header] => NULL
    [footer] => NULL
    [memo] => example
    [site_hierarchy] => 2
    [parents_site_id] => 1
    [display_flg] => 1
    [display_order] => 0
    [api_version] => 1
    [site_id] => 
)

DEBUG - 2016-08-11 12:14:40 --> Api\Controller_Site_Store_Free->update(131) - 【SITE_STORE_FREE UPDATE API】:END
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:14:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:14:54 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:54 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:55 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:14:55 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:14:55 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:55 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:14:55 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:55 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:14:55 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:14:55 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:14:55 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:14:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:14:55 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:14:55 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:14:55 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:14:55 --> Model_User->checkAuthorityCompanyId(424) - 【USER AUTHORITY CHECK - COMPANY_ID】
DEBUG - 2016-08-11 12:14:55 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:14:55 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 12:14:55 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:14:55 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:14:55 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:14:55 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [id] => 27
    [company_id] => 1
    [brand_id] => 1
    [store_id] => 1
    [sitemap_name] => sitemap1
    [sitemap_url] => example
    [linkage_site_id] => 0
    [title_picture_id] => 1
    [organize_type] => 1
    [page_type] => 4
    [organize_parts] => Array
        (
            [free_text] => dasda
            [menu_list] => Array
                (
                    [0] => Array
                        (
                            [id] => 1
                            [menu] => 
                        )

                )

        )

    [free_input] => example
    [header] => NULL
    [footer] => NULL
    [memo] => example
    [site_hierarchy] => 2
    [parents_site_id] => 1
    [display_flg] => 1
    [display_order] => 0
    [api_version] => 1
    [site_id] => 
)

DEBUG - 2016-08-11 12:14:55 --> Api\Controller_Site_Store_Free->update(131) - 【SITE_STORE_FREE UPDATE API】:END
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
INFO - 2016-08-11 12:15:24 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:15:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:15:24 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:15:24 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:25 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:28:25 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 1
)

DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:25 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:28:25 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:32 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 12:28:33 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:28:33 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:28:33 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 12:28:33 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:02 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:02 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:02 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:02 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:54:02 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 12:54:02 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:03 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:03 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:03 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:03 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:03 --> Api\Controller_Section->index(37) - section/index called
DEBUG - 2016-08-11 12:54:03 --> Api\Controller_Section->setParams(147) - 【SECTION API】:SET PARAM
DEBUG - 2016-08-11 12:54:03 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:04 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:04 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:04 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:04 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:04 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 12:54:04 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 12:54:05 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:05 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:05 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:05 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:05 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:05 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:05 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:05 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:05 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:05 --> Api\Controller_Daily_Store->index(26) - 【DAILY STORE LIST API】:START
DEBUG - 2016-08-11 12:54:05 --> Api\Controller_Daily_Store->setParams(87) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-08-11 12:54:05 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:05 --> Api\Controller_Daily_Store->index(79) - 【DAILY STORE API】:END
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:06 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:06 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:06 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:06 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
INFO - 2016-08-11 12:54:06 --> Api\Controller_Member->index(70) - member/index called
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:07 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:07 --> Api\Controller_Coupon->index(64) - 【COUPON LIST API】:START
DEBUG - 2016-08-11 12:54:07 --> Api\Controller_Coupon->index(116) - 【COUPON LIST API】:END
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:07 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:07 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:07 --> Api\Controller_Questionnaire->index(38) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-08-11 12:54:07 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-08-11 12:54:12 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:12 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:12 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:12 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:12 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:12 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:12 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:12 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:12 --> Api\Controller_Coupon->index(64) - 【COUPON LIST API】:START
DEBUG - 2016-08-11 12:54:12 --> Api\Controller_Coupon->index(116) - 【COUPON LIST API】:END
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:34 --> Api\Controller_Delivery_Count->index(11) - 【DELIVERY COUNT API】:START
DEBUG - 2016-08-11 12:54:34 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:54:34 --> Api\Controller_Delivery->index(55) - 【DELIVERY LIST API】:START
DEBUG - 2016-08-11 12:54:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:34 --> Api\Controller_Delivery->index(144) - 【DELIVERY LIST API】:SET RESULT
DEBUG - 2016-08-11 12:54:34 --> Api\Controller_Delivery->index(146) - 【DELIVERY LIST API】:END
DEBUG - 2016-08-11 12:54:34 --> Api\Controller_Delivery_Count->index(59) - 【DELIVERY COUNT API】:END
DEBUG - 2016-08-11 12:54:35 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:35 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:35 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:35 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:35 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:35 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:35 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:35 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:35 --> Api\Controller_Information->index(47) - 【INFORMATION LIST API】:START
DEBUG - 2016-08-11 12:54:35 --> Api\Controller_Information->setParams(189) - 【INFORMATION API】:SET PARAM
DEBUG - 2016-08-11 12:54:35 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:35 --> Api\Controller_Information->index(112) - 【INFORMATION LIST API】:END
DEBUG - 2016-08-11 12:54:36 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:36 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:36 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:36 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:36 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:36 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:36 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:36 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:36 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:36 --> Api\Controller_Questionnaire->index(38) - 【QUESTIONNAIRE LIST API】:START
DEBUG - 2016-08-11 12:54:36 --> Api\Controller_Questionnaire->index(86) - 【QUESTIONNAIRE LIST API】:END
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:37 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:37 --> Api\Controller_Daily_Store->index(26) - 【DAILY STORE LIST API】:START
DEBUG - 2016-08-11 12:54:37 --> Api\Controller_Daily_Store->setParams(87) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-08-11 12:54:37 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:37 --> Api\Controller_Daily_Store->index(79) - 【DAILY STORE API】:END
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:37 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:37 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:37 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:37 --> Api\Controller_User_Private->index(14) - user/index called
INFO - 2016-08-11 12:54:37 --> Api\Controller_Member->index(70) - member/index called
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:39 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 12:54:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 12:54:39 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 12:54:39 --> Api\Controller_Section->index(37) - section/index called
DEBUG - 2016-08-11 12:54:39 --> Api\Controller_Section->setParams(147) - 【SECTION API】:SET PARAM
DEBUG - 2016-08-11 12:54:39 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:11 --> Api\Controller_Analysis_Delivery->index(21) - daily/delivery called
DEBUG - 2016-08-11 15:37:12 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:12 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:12 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:12 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:12 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:12 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:12 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:12 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:12 --> Api\Controller_Daily_Store->index(26) - 【DAILY STORE LIST API】:START
DEBUG - 2016-08-11 15:37:12 --> Api\Controller_Daily_Store->setParams(87) - 【DAILY STORE API】:SET PARAM
DEBUG - 2016-08-11 15:37:12 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:12 --> Api\Controller_Daily_Store->index(79) - 【DAILY STORE API】:END
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:20 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:20 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:20 --> Api\Controller_Site_Store_Detail->index(16) - site store private info/index called
DEBUG - 2016-08-11 15:37:20 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:37:20 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 2
    [site_id] => 
    [organize_type] => 0
    [site_hierarchy] => 1
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:37:20 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
ERROR - 2016-08-11 15:37:20 --> Fatal Error - Call to a member function toArray() on a non-object in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/detail.php on line 22
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:37:38 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 2
    [site_id] => 
    [organize_type] => 0
    [site_hierarchy] => 1
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:37:38 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:37:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:37:38 --> Api\Controller_Site_Store_Detail->index(16) - site store private info/index called
ERROR - 2016-08-11 15:37:39 --> Fatal Error - Call to a member function toArray() on a non-object in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/detail.php on line 22
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:47 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:47 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:47 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:38:47 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:38:47 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:38:47 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:47 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:47 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:38:47 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:38:47 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:38:47 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:38:47 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:48 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:48 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:48 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:38:48 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 2
    [site_id] => 
    [organize_type] => 0
    [site_hierarchy] => 1
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:38:48 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:48 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:48 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:48 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:48 --> Api\Controller_Site_Store_Detail->index(16) - site store private info/index called
ERROR - 2016-08-11 15:38:48 --> Fatal Error - Call to a member function toArray() on a non-object in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/detail.php on line 22
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:38:58 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 2
    [site_id] => 
    [organize_type] => 0
    [site_hierarchy] => 1
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:38:58 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:38:58 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:38:58 --> Api\Controller_Site_Store_Detail->index(16) - site store private info/index called
ERROR - 2016-08-11 15:38:58 --> Fatal Error - Call to a member function toArray() on a non-object in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/detail.php on line 22
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:43:44 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:43:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:43:44 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 2
    [site_id] => 
    [organize_type] => 0
    [site_hierarchy] => 1
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Site_Store_Detail->index(16) - site store private info/index called
ERROR - 2016-08-11 15:43:44 --> Fatal Error - Call to a member function toArray() on a non-object in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/detail.php on line 22
DEBUG - 2016-08-11 15:43:44 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:44:15 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:44:15 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:44:15 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:44:15 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:44:15 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:44:15 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:44:15 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:44:15 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:44:15 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:44:15 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:44:15 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:44:15 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:44:28 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:44:28 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:44:28 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:44:28 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:44:28 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:44:28 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:44:28 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 1
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 1
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:44:28 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 15:44:28 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 15:44:28 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:44:28 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:47:01 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 1
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 1
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:47:01 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:47:01 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 15:47:01 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 15:48:55 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:48:55 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:48:55 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:48:55 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:48:55 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:48:55 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:48:55 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:48:55 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:48:55 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 15:48:55 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:48:55 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:48:55 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:48:55 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 1
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 1
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 1
)

DEBUG - 2016-08-11 15:48:55 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:48:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:48:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:48:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:48:59 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:48:59 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:48:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:48:59 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 3
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 1
)

DEBUG - 2016-08-11 15:48:59 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:50:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:50:11 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:50:11 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:50:11 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:50:12 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:12 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:50:12 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 4
    [site_id] => 
    [organize_type] => 1
    [site_hierarchy] => 2
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:50:12 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:12 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:50:12 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Site_Map->index(27) - site map index/ called
DEBUG - 2016-08-11 15:50:12 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:50:12 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:50:12 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:50:12 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Site_Store_Url->index(19) - 【SITE_STORE_FREE URL GET API】:START
DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Site_Store_Url->index(20) - Array
(
    [pattern] => 3
    [per_page] => 10
    [page] => 1
    [page_type] => 5
    [api_version] => 1
    [brand_id] => 1
)

DEBUG - 2016-08-11 15:50:12 --> Api\Controller_Site_Store_Url->index(55) - 【SITE_STORE_FREE URL GET API】:END
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:55:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:55:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:55:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:55:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:55:34 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:55:34 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:55:34 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:55:34 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:55:34 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:55:34 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 16
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 1
)

INFO - 2016-08-11 15:55:34 --> Controller_Api->action_index(104) - [1330] Site is not exist
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:00 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:56:00 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:00 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:56:00 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 16
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 1
)

INFO - 2016-08-11 15:56:00 --> Controller_Api->action_index(104) - [1330] Site is not exist
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:24 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:24 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:56:24 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:24 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:56:24 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 15:56:24 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:38 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:38 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:38 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:56:38 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 15:56:38 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:56:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:56:54 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:56:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:56:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:56:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

INFO - 2016-08-11 15:56:54 --> Controller_Api->action_index(104) - [1330] Site is not exist
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:57:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:57:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:57:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Area->index(37) - 【AREA LIST API】:START
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Area->index(81) - 【AREA LIST API】:END
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 15:57:00 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 15:57:00 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 15:57:00 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 15:57:00 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 15:57:00 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 15:57:00 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:03:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:03:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:03:59 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:03:59 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:03:59 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:03:59 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:03:59 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:03:59 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:20 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:20 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:20 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:04:20 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 0
)

DEBUG - 2016-08-11 16:04:20 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:04:35 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:04:35 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:04:35 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:04:35 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:04:35 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:04:35 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:05:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:05:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:05:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:05:54 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:05:54 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:05:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:05:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:05:54 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:06:53 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:06:53 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:06:53 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:06:53 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:06:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:06:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:06:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:06:54 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:06:54 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:06:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:06:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:06:54 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:07:26 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:07:26 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:07:26 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:07:26 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:07:26 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:07:26 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:07:26 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:07:26 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:07:26 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:07:27 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:08:47 --> Controller_Media->before(29) - start.
DEBUG - 2016-08-11 16:08:47 --> Controller_Media->setThreeMasterIdAndCodeForURL(150) - start.
DEBUG - 2016-08-11 16:08:47 --> Controller_Media->setThreeMasterIdAndCodeForURL(161) - end.
DEBUG - 2016-08-11 16:08:47 --> Controller_Media->before(66) - 3Master CID:1 BCODE:brand_code_1 SCODE:xvbgnghh
DEBUG - 2016-08-11 16:08:47 --> Controller_Media->setThreeMasterDataForStore(229) - start.
DEBUG - 2016-08-11 16:08:47 --> Controller_Media->setThreeMasterDataForStore(245) - store_status is not STATUS_OPEN(3). store_id[3], store_status[2]
INFO - 2016-08-11 16:08:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "media/welcome/404"
INFO - 2016-08-11 16:08:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:08:47 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2016-08-11 16:08:47 --> Media\Controller_Welcome->before(12) - start.
DEBUG - 2016-08-11 16:08:47 --> Media\Controller_Welcome->action_404(26) - start.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:09:50 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:09:50 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:09:50 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:09:50 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:09:50 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:09:50 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:09:50 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:09:50 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:09:50 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:09:50 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:09:50 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:09:53 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:09:53 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:09:53 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:09:53 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:09:53 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:09:53 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:09:53 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:09:53 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:09:53 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:09:53 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:09:53 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:09:53 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:09:53 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:09:54 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:10:05 --> Media\Controller_Coupon->before(20) - 【COUPON】 start.
ERROR - 2016-08-11 16:10:05 --> Media\Controller_Coupon->before(39) - media: "key" is null
INFO - 2016-08-11 16:10:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "media/welcome/404"
INFO - 2016-08-11 16:10:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-08-11 16:10:05 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2016-08-11 16:10:05 --> Media\Controller_Welcome->before(12) - start.
DEBUG - 2016-08-11 16:10:05 --> Media\Controller_Welcome->action_404(26) - start.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:10:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:10:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:10:23 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:10:23 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:10:23 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:10:23 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:10:23 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:10:23 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:19:43 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:19:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:19:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:19:44 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:19:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:19:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:19:44 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:19:44 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
INFO - 2016-08-11 16:19:44 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:19:44 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:19:44 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:37:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:37:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:37:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Store->index(100) - 【STORE LIST API】:START
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_User_Private->index(14) - user/index called
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Brand->index(57) - 【BRAND LIST API】:START
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Area->index(35) - 【AREA LIST API】:START
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Company->index(15) - company/index called
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Area->index(79) - 【AREA LIST API】:END
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Brand->index(106) - 【BRAND LIST API】:END
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Store->index(172) - 【STORE LIST API】:END
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(61) - 【BEFORE API PROCESS】:START
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(68) - 【BEFORE API PROCESS】:CHECK TOKEN OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(72) - 【BEFORE API PROCESS】:CHECK AUTHORITY OK.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(79) - 【BEFORE API PROCESS】:PARSE JSON.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(82) - 【BEFORE API PROCESS】:GET PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(84) - 【BEFORE API PROCESS】:CHECK PARAMETERS.
DEBUG - 2016-08-11 16:37:54 --> Model_User->checkAuthority(409) - 【USER AUTHORITY CHECK】
DEBUG - 2016-08-11 16:37:54 --> Model_User->checkAuthorityBrandIds(433) - 【USER AUTHORITY CHECK - BRAND_IDS】
DEBUG - 2016-08-11 16:37:54 --> Model_User->checkAuthorityStoreIds(455) - 【USER AUTHORITY CHECK - STORE_IDS】
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(87) - 【BEFORE API PROCESS】:CHECK USER AUTHORITY.
DEBUG - 2016-08-11 16:37:54 --> Controller_Api->before(93) - 【BEFORE API PROCESS】:END
DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(136) - 【SITE_STORE_FREE GET API】:START
INFO - 2016-08-11 16:37:54 --> Api\Controller_Site_Store_Free->checkExistedBrandStore(141) - Array
(
    [pattern] => 3
    [page_type] => 5
    [site_id] => 21
    [organize_type] => 1
    [site_hierarchy] => 3
    [api_version] => 1
    [brand_id] => 1
    [store_id] => 3
)

DEBUG - 2016-08-11 16:37:54 --> Api\Controller_Site_Store_Free->index(72) - 【SITE_STORE_FREE GET API】:END
