<div class="freeContents clearfix">
	<h1><?php echo $sitemap_name ?></h1>
	<div class="freeText">
<?php echo $free_text ?>
	</div>
</div>
