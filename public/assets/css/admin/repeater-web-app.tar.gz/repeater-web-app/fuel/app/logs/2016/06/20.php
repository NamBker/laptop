<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-06-20 10:47:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-20 10:47:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:47:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-20 10:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 10:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 10:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:49:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 10:49:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:49:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 10:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:15:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:15:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:15:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:26:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:26:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:26:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:26:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:26:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:26:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:28:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:28:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:28:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:30:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:30:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:30:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:33:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:33:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:33:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:33:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:42:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:42:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:42:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:42:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:42:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:42:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:42:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:44:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:44:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:44:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:49:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:49:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:49:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:50:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:51:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 11:51:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 11:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:04:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:04:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:30:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/coupons"
INFO - 2016-06-20 12:30:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:30:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:33:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:33:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:33:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:35:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:35:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:47:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 12:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:56:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 12:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:03:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:05:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:07:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:07:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:07:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:08:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:18:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:18:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:18:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:19:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:19:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:19:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:19:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:19:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:19:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:19:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:20:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-20 13:20:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:20:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:20:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:20:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:20:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:20:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:20:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:20:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:20:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:21:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:23:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:23:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:23:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:23:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:23:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:23:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:26:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:26:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:26:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:26:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:31:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:31:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:31:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:31:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:31:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:31:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:31:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:31:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:31:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:51:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:51:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:51:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:53:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 13:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 13:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:00:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:01:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users"
INFO - 2016-06-20 14:01:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:01:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 14:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:01:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 14:01:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:01:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/sections"
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 14:29:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-20 14:29:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:29:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 14:30:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 14:30:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-20 14:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:31:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-20 14:31:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:31:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/information"
INFO - 2016-06-20 14:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 14:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 14:39:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 14:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 14:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 15:50:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 15:50:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 15:50:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 15:50:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 15:50:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 15:50:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 16:20:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 16:20:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 16:20:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 16:20:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 16:20:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 16:20:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 16:20:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 16:20:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 16:20:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 16:20:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 16:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:03:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:03:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:03:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:05:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:05:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:05:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:06:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:06:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:06:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:06:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:06:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:06:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:08:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:08:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:10:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:10:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:10:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:10:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:10:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:10:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:23:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 17:23:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:23:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:25:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 17:25:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:25:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:25:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:25:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:25:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:25:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:25:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:25:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:27:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:27:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:27:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:27:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:27:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:27:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:27:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:44:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:44:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:44:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:46:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:46:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:46:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:46:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:46:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:46:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:46:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:46:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:46:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:46:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:46:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:46:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:46:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:46:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:46:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:47:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:47:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 17:47:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:47:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 17:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 17:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 17:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:01:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:03:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:03:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:03:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:04:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:04:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:05:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:05:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:05:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:07:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:07:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:07:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:07:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:07:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:07:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:07:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:07:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:09:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:09:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:09:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-06-20 18:18:27 --> Session update failed, session record recovered using previous id. Lost rotation data?
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:20:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:20:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:20:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:24:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:24:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:24:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:26:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:26:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:26:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:27:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:28:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:28:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:28:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:28:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:30:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:30:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:30:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:30:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:35:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:35:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:35:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:35:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:37:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:41:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:44:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 18:46:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 18:46:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 18:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 19:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 19:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 19:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 19:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:07:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 19:07:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:07:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-06-20 19:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/questionnaires"
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-06-20 19:43:48 --> Fuel\Core\Request::execute - Setting main Request
