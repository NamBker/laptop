<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2016-07-25 10:39:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-25 10:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-25 10:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 10:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 10:39:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/2"
INFO - 2016-07-25 10:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 10:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 10:39:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 10:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 10:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:33:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:33:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:33:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:51:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:52:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:52:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:53:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 11:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:22:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:23:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:23:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:23:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:23:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:23:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:23:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:23:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:23:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:23:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:24:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:24:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:24:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:25:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:25:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:25:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:43:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:43:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:43:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:44:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:44:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:44:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:44:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:45:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:45:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:45:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:46:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:46:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:49:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:49:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:49:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:50:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:50:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:50:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:51:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:51:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:51:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 12:52:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:04:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/2"
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:05:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/2"
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:05:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:05:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/2"
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/2"
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/2"
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 13:06:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:06:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:06:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:06:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:07:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:07:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-25 13:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:09:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/2/store/1"
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:10:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:10:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:10:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:13:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:13:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:14:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:14:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:14:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:14:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:14:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:32:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:39:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:39:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:39:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:39:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:39:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:41:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 13:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:41:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:41:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:43:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell"
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 13:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell"
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 13:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 14:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell"
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:27:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 14:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell"
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 14:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 14:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 14:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 14:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 14:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 14:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:33:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:33:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:33:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:35:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:35:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:35:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:35:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:37:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:37:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:37:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:37:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:38:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:43:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 15:43:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:11:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:12:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:15:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
ERROR - 2016-07-25 16:15:40 --> Parsing Error - syntax error, unexpected '=>' (T_DOUBLE_ARROW) in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/free.php on line 123
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
ERROR - 2016-07-25 16:15:50 --> Parsing Error - syntax error, unexpected '=>' (T_DOUBLE_ARROW) in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/free.php on line 123
INFO - 2016-07-25 16:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:16:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:16:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
ERROR - 2016-07-25 16:16:18 --> Parsing Error - syntax error, unexpected '=>' (T_DOUBLE_ARROW) in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/free.php on line 123
INFO - 2016-07-25 16:16:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:16:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:16:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:16:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:16:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:16:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
ERROR - 2016-07-25 16:17:12 --> Parsing Error - syntax error, unexpected '=>' (T_DOUBLE_ARROW) in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/free.php on line 123
INFO - 2016-07-25 16:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:19:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:19:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:19:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
ERROR - 2016-07-25 16:19:56 --> Parsing Error - syntax error, unexpected '=>' (T_DOUBLE_ARROW) in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/free.php on line 123
INFO - 2016-07-25 16:19:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:19:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:19:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:19:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:19:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:19:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:22:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:22:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:22:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
ERROR - 2016-07-25 16:22:58 --> Parsing Error - syntax error, unexpected ';' in /var/www/local.gmorepeater.jp/fuel/app/modules/api/classes/controller/site/store/free.php on line 128
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:23:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:23:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:23:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:23:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:23:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:24:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:24:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:24:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:24:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:26:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:26:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:26:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:26:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:27:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:27:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:28:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:28:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:28:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:29:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:29:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:29:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:29:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:35:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:39:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:39:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:39:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:44:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:44:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:44:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:44:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:46:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:46:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:46:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:47:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:47:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:47:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 16:48:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:48:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:48:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:48:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:48:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/2"
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/200"
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 16:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 16:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:49:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/logout"
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-25 16:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/user/login"
INFO - 2016-07-25 16:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:54:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:54:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 16:54:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 16:54:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 16:54:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:04:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:05:25 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:05:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/0"
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell"
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 17:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:27:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:27:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell"
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/assets/img/img-dell@2x"
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:27:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:56:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:56:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:56:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:56:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:56:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:56:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:56:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 17:56:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:56:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:57:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:57:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:57:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:58:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 17:58:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:58:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:58:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 17:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 17:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 17:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 17:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 18:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:15:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 18:15:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:15:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:15:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 18:15:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:15:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:20:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 18:20:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:20:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 18:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 18:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 18:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:25:37 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-07-25 18:25:37 --> Session update failed, session record recovered using previous id. Lost rotation data?
INFO - 2016-07-25 18:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 18:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 18:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 18:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 18:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:25:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:33:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 18:33:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:33:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:33:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:34:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 18:34:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:34:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 18:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:35:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 18:35:57 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:35:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 18:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 18:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 18:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:36:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 19:36:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:36:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:36:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:36:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 19:36:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:36:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 19:50:17 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 19:50:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 19:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 19:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:56:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 19:56:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:56:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 19:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:05:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:05:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:07:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:07:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:09:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/url/brand/1"
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:09:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:10:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:10:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:11:02 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:11:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:11:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:11:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:12:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:13:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:14:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:15:01 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:15:48 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 20:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:16:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:16:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:16:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:16:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 20:16:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:16:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "web/home"
INFO - 2016-07-25 20:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/companies"
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/users/me"
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/brands"
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/areas"
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/stores"
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2016-07-25 20:18:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "1/site/brand/1/store/1"
INFO - 2016-07-25 20:18:15 --> Fuel\Core\Request::execute - Called
INFO - 2016-07-25 20:18:15 --> Fuel\Core\Request::execute - Setting main Request
