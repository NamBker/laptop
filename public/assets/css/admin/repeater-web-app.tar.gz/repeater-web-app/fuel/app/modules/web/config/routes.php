<?php
return array(
    'web' => 'web/home',
    'web/index' => 'web/home',

    // account
    'web/user/list' => 'web/user/index',
    'web/user/create' => 'web/user/create',

    //brand
    'web/brand/list' => 'web/brand/index',
    'web/brand/create' => 'web/brand/create',
    'web/brand/edit' => 'web/brand/edit',

    //store
    'web/store/export' => 'web/store/export',

    // member
    'web/member/export' => 'web/member/export',

);
